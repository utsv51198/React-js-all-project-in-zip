import React from "react";
import Chart from "../../components/chart/Chart";
import FeatureInfo from "../../components/FeatureInfo/FeatureInfo";
import "./Home.css";
import { userData } from "../../dummyData";
import WidgetSm from "../../components/WidgetSm/WidgetSm";
import WidgetLg from "../../components/WidgetLg/WidgetLg";

export default function Home() {
  return (
    <div className="home">
      <FeatureInfo />
      <Chart data={userData} title="User Anual" grid dataKey="Active User" />
      <div className="homeWidget">
        <WidgetSm />
        <WidgetLg />
      </div>
    </div>
  );
}
