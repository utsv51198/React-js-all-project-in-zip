import React, { useState, useEffect } from "react";
import axios from "axios";
import jsPDF from "jspdf";
import "jspdf-autotable";

export const CustomPdf = () => {
  const [exportData, setExportData] = useState([]);
  useEffect(() => {
    const getData = async () => {
      const { data } = await axios
        .get(`https://fakestoreapi.com/products`)
        .catch((err) => {
          console.log("Error", err);
        });
      console.log(data);
      setExportData(data);
    };
    getData();
  }, []);

  const handlerPrtint = () => {
    var pdfsize = "a4";
    const doc = new jsPDF("p", "px", pdfsize);
    doc.setLineWidth(2);
    doc.text("Export Data in PDF using React Js", 35, 10);
    doc.autoTable({
      html: "#my-table",
      startY: 25,
      tableWidth: "auto",
      columnWidth: "auto",
      styles: {
        overflow: "linebreak",
      },
    });
    doc.save("table.pdf");
  };
  return (
    <>
      <React.Fragment>
        <div className="container">
          <h4 className="mt-3 mb-3">Export Data in PDF using React Js </h4>
          <button className="btn btn-info" onClick={handlerPrtint}>
            Print Here
          </button>
          <div
            className="container"
            style={{ width: "100%", height: window.innerHeight }}
          >
            <div className="row">
              <div className="col-sm-8">
                <h4 className="mt-3 mb-3">
                  Export Data in PDF using React Js{" "}
                </h4>

                <table className="table table-bordered my-3" id="my-table">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Name</th>
                      <th>Price</th>
                      <th>Category</th>
                      <th>Description</th>
                    </tr>
                  </thead>
                  <tbody>
                    <>
                      {exportData.map((data) => (
                        <tr key={data.id}>
                          <td>{data.id}</td>
                          <td>{data.title}</td>
                          <td>${data.price}</td>
                          <td>{data.category}</td>
                          <td>{data.description}</td>
                        </tr>
                      ))}
                    </>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    </>
  );
};
