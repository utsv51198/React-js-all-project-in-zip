import "./App.css";
import { CustomPdf } from "./components/CustomPdf";

function App() {
  return (
    <div className="App">
      <CustomPdf />
    </div>
  );
}

export default App;
