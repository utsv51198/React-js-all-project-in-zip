import './App.css';
import { AddMoney } from './components/AddMoney';
import { Navbar } from './components/Navbar';

function App() {
  return (
    <>
      <Navbar />
      <div className="container my-4 text-center">
        <AddMoney />
      </div>
    </>
  );
}

export default App;
