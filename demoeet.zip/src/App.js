//import { BrowserRouter as Routes, Route } from "react-router-dom";
import UsersList from "./container/Getdata";
import UpdateDetails from "./container/EditData";
import ViewDetails from "./container/DataFeatch";
import AddUser from "./container/AddData";
import "./App.css";
import { Route, Routes } from "react-router-dom";

function App() {
  return (
    <Routes>
      <Route exact path="/" element={<UsersList />} />
      <Route exact path="/defaultPath" element={<UsersList />} />
      <Route exact path="/update/:id" element={<UpdateDetails />} />
      <Route exact path="/details/:id" element={<ViewDetails />} />
      <Route exact path="/add" element={<AddUser />} />
    </Routes>
  );
}

export default App;
