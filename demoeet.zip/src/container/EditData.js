import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate, useParams } from "react-router-dom";
import { getUserAction,updateUserAction } from "../redux/action/creators";
import swal from "sweetalert";
 const UpdateDetails = () => {
   let dispatch = useDispatch();
   let navigate = useNavigate();
   let { id } = useParams();
   const [state, setState] = useState({
     name: "",
     email: "",
     occupation: "",
     bio: "",
   });
  const { user } = useSelector((state) => state.user);

  useEffect(() => {
    dispatch(getUserAction(id));
  },[]);

  useEffect(() => {
    if (user) {
      setState({ ...user });
    }
  }, [user]);

  const { name, email, occupation, bio } = state;

  const handleTextChange = (e) => {
    let { name, value } = e.target;
    setState({ ...state, [name]: value });
    console.log(state);
  };

  const handleOnSubmit = (e) => {
    e.preventDefault();
    swal("Good job!", "You Update The data", "success");
    dispatch(updateUserAction(state, id));
    navigate("/");
  }
   
   return (
     <div className="container" id="update">
       <div className={"border border-dark bg-dark text-white"}>
         <h3>Edit User</h3>
         <div className="form-container">
           <form onSubmit={handleOnSubmit}>
             <div className="form-group">
               <label>Name</label>
               <input
                 type="text"
                 name="name"
                 onChange={handleTextChange}
                 value={name || ""}
                 className="form-control w-50 p-2"
                 required
               />
             </div>
             <div className="form-group">
               <label>Email address</label>
               <input
                 type="email"
                 name="email"
                 onChange={handleTextChange}
                 value={email || ""}
                 className="form-control w-50 p-2"
                 required
               />
             </div>
             <div className="form-group">
               <label>Occupation</label>
               <input
                 type="text"
                 name="occupation"
                 onChange={handleTextChange}
                 value={occupation || ""}
                 className="form-control w-50 p-2"
                 required
               />
             </div>
             <div className="form-group">
               <label>Bio</label>
               <textarea
                 type="text"
                 name="bio"
                 onChange={handleTextChange}
                 value={bio || ""}
                 className="form-control w-50 p-2"
                 required
               />
             </div>

             <br></br>

             <div className="form-group">
               <button
                 onChange={handleTextChange}
                 className="btn btn-primary"
                 type="submit"
               >
                 Edit User
               </button>
               <Link to="/">
                 <button type="button" className="btn btn-secondary mx-3">
                  Back
                 </button>
               </Link>
             </div>
           </form>
         </div>
       </div>
     </div>
   );
 };

export default UpdateDetails;
