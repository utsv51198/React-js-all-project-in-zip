import React, { Component } from "react";
import { addUserAction } from "../redux/action/creators";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import swal from "sweetalert";
 class AddUser extends Component { 
  state = {
    name: "",
    email: "",
    occupation: "",
    bio: "",
  };
  handleTextChange = (event) => {
    const {
      target: { name, value },
    } = event;
    this.setState({ ...this.state, [name]: value });
    console.log(this.state);
  };

  handleOnSubmit = (event) => {
    event.preventDefault();
    this.props.addUserAction(this.state);
    swal("Good job!", "You Add new data in Database", "success");
    this.setState({
      name: "",
      email: "",
      occupation: "",
      bio: "",
    });
  };
  render() {
    return (
      <div className="container" id="update">
        <h3>Add User</h3>
        <div className="form-container"></div>
        <form onSubmit={this.handleOnSubmit}>
          <div className="form-group">
            <label>Name</label>
            <input
              type="text"
              name="name"
              onChange={this.handleTextChange}
              value={this.state.name}
              className="form-control w-50 p-2"
              required
            />
          </div>
          <div className="form-group">
            <label>Email address</label>
            <input
              type="email"
              name="email"
              onChange={this.handleTextChange}
              value={this.state.email}
              className="form-control w-50 p-2"
              required
            />
          </div>
          <div className="form-group">
            <label>Occupation</label>
            <input
              type="text"
              name="occupation"
              onChange={this.handleTextChange}
              value={this.state.occupation}
              className="form-control w-50 p-2"
              required
            />
          </div>
          <div className="form-group">
            <label>Bio</label>
            <input
              type="text"
              name="bio"
              onChange={this.handleTextChange}
              value={this.state.bio}
              className="form-control w-50 p-2"
              required
            />
          </div>

          <br></br>

          <div className="form-group">
            <button
              className="btn btn-primary"
              type="submit"
            >
              Add User
            </button>
            <Link to="/">
              <button type="button" className="btn btn-secondary mx-2">
                Back
              </button>
            </Link>
          </div>
        </form>
      </div>
    );
  }
}
export default connect(null, { addUserAction })(AddUser);
