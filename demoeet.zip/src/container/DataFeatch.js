import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useParams } from "react-router-dom";
import { getUserAction } from "../redux/action/creators";
import { Link } from "react-router-dom";
 const ViewDetails = () => {
   let dispatch = useDispatch();
    const [state, setState] = useState({
      name: "",
      email: "",
      occupation: "",
      bio: "",
    });
    let { id } = useParams();
    const { user } = useSelector((state) => state.user);
    useEffect(() => {
      dispatch(getUserAction(id));
    },[]);

    useEffect(() => {
      if (user) {
        setState({ ...user });
      }
    }, [user]);
    const { name, email, occupation, bio } = state;
return (
  <div className="container" id="update">
    <h3 className="profile">PROFILE DETAILS</h3>
    <form>
      <div className="container">
        <div className="profile-item">
          <h3>
            <label id="label">Name : {name} </label>
          </h3>
        </div>
        <div className="profile-item">
          <h3>
            {" "}
            <label id="label">Email : {email} </label>
          </h3>
        </div>
        <div className="profile-item">
          <h3>
            {" "}
            <label id="label">Occupation : {occupation} </label>
          </h3>
        </div>
        <div className="profile-item">
          <h2 className=" p-3 ">
            {" "}
            <label id="label">Bio </label>
            <br></br> {bio}
          </h2>
        </div>
        <Link to="/">
          {" "}
          <button type="button" className="btn btn-primary">
            Home
          </button>
        </Link>
        <Link to={"/update/" + id}>
          {" "}
          <button type="button" className="btn btn-secondary">
            Update
          </button>
        </Link>
      </div>
    </form>
  </div>
);
 }
  
export default ViewDetails;