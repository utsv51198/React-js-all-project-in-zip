import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { deleteUserAction } from "../redux/action/creators";
import { getUsersAction } from "../redux/action/creators";
import { Link } from "react-router-dom";
import swal from "sweetalert";

const UsersList = () => {
  const dispatch = useDispatch();
  const  {users}  = useSelector((state) => state.user);
   const handleDelete = (id) => {
    swal({
      title: "Are you sure?",
      text: "Once deleted, you will not be able to recover this imaginary file!",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
         
        swal("Poof! Your imaginary file has been deleted!", {
          icon: "success",
         
        });
        dispatch(deleteUserAction(id));
      } else {
        swal("Your imaginary file is safe!");
      }
    });
   };

  useEffect(() => {
    dispatch(getUsersAction());
  },[]);
  const renderList = users.map((user) => {
    const { id, email, name, occupation } = user;
    return (
      <tr key={id}>
        <th scope="row">{id}</th>
        <td>{name}</td>
        <td>{email}</td>
        <td>{occupation}</td>
        <th>
          <div className="btn-group" role="group" aria-label="Basic example">
            <Link
              type="button"
              to={"/update/" + user.id}
              className="btn btn-info mx-2"
            >
              Edit
            </Link>
            <Link
              type="button"
              to={"/details/" + user.id}
              className="btn btn-warning mx-2"
            >
              Details
            </Link>
            <button
              type="button"
              onClick={() => handleDelete(user.id)}
              className="btn btn-danger mx-2"
            >
              Delete
            </button>
          </div>
        </th>
      </tr>
    );
  });

  return (
    <div className="container my-2">
      <div className="d-flex justify-content-between">
        <h1>STUDENT DATA</h1>
        <Link type="button" to={"/add"} className="btn btn-primary " id="tab">
          Add User
        </Link>
      </div>
      <div className="container my-4">
        <table className="table">
          <thead>
            <tr>
              <th scope="col">id</th>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Occupation</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>{renderList}</tbody>
        </table>
      </div>
    </div>
  );
};

export default UsersList;
