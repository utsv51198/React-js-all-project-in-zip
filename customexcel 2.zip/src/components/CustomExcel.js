import React, { useState, useEffect } from "react";
import axios from "axios";
import * as XLSX from "xlsx";

export const CustomExcel = () => {
  const [exportData, setExportData] = useState([]);
  useEffect(() => {
    const getData = async () => {
      const { data } = await axios
        .get(`https://ti-react-test.herokuapp.com/users`)
        .catch((err) => {
          console.log("Error", err);
        });
      console.log(data);
      setExportData(data);
    };
    getData();
  }, []);

  const handleExcel = () => {
    const newData = exportData.map((row) => {
      delete row.created_at;
      delete row.updated_at;
      delete row.bio;
      return row;
    });
    //console.log("Clicked");
    const workSheet = XLSX.utils.json_to_sheet(newData);
    const workBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workBook, workSheet, "student");
    //Buffer
    const buf = XLSX.write(workBook, { bookType: "xlsx", type: "buffer" });
    console.log("buffer", buf);
    //Binary String
    XLSX.write(workBook, { bookType: "xlsx", type: "binary" });
    XLSX.writeFile(workBook, "Data.xlsx");
  };
  return (
    <div className="container my-2">
      <div className="d-flex justify-content-between">
        <h1>STUDENT DATA</h1>
        <button className="btn btn-success" onClick={handleExcel}>
          Excel Export
        </button>
      </div>
      <div className="container my-4">
        <table className="table">
          <thead>
            <tr>
              <th scope="col">NO</th>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Occupation</th>
              <th scope="col">Bio</th>
            </tr>
          </thead>
          <tbody>
            {exportData.map((data) => (
              <tr key={data.id}>
                <td>{data.id}</td>
                <td>{data.name}</td>
                <td>{data.email}</td>
                <td>{data.occupation}</td>
                <td>{data.bio}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
