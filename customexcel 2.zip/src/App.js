import "./App.css";
import { CustomExcel } from "./components/CustomExcel";

function App() {
  return (
    <div className="App">
      <CustomExcel />
    </div>
  );
}

export default App;
