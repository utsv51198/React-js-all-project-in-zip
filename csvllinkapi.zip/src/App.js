import "./App.css";
import { ExcelData } from "./components/ExcelData";

function App() {
  return (
    <div className="App">
      <ExcelData />
    </div>
  );
}

export default App;
