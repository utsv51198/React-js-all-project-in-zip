import axios from "axios";
import { ActionTypes } from "../constants/action-type";

const getData = (datas) => ({
    type : ActionTypes.GET_DATA,
    payload : datas,
})

const deleteData = (id) => ({
    type : ActionTypes.DELETE_DATA,
    payload : id

})

export const loadData = () =>{
         return function (dispatch) {
         axios.get("https://fakestoreapi.com/products").then((resp) => {
            console.log("resp",resp);
            dispatch(getData(resp.data));
          })
          .catch((error) => console.log(error))
         }
}

export const deletedData = (id) => {
  return function (dispatch) {
    axios
      .delete(`https://fakestoreapi.com/products/${id}`)
      .then((resp) => {
        console.log("resp", resp);
        dispatch(deleteData(id));
      })
      .catch((error) => console.log(error));
  };
};