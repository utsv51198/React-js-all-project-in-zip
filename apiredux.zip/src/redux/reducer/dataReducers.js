import { ActionTypes } from "../constants/action-type";

const initialState = {
  datas: [],
  data:{},
};

export const getDataReducer = (state = initialState, { type, payload }) => {
  switch (type) {
    case ActionTypes.GET_DATA:
      return { ...state, datas: payload };

    case ActionTypes.PUT_DATA: {
      const datas = [...state.datas];
      datas.push(type);
      return {
        datas,
      };
    }

    case ActionTypes.UPDATE_DATA: {
      const { index, data } = { type, payload };
      const datas = [...state.datas];
      datas[index] = data;
      return {
        datas,
      };
    }

    case ActionTypes.DELETE_DATA: {
     return {...state,
      datas : state.datas.filter((el) => el.id !== payload)
    }
    }

    default:
      return state;
  }
};
