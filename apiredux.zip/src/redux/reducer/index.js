import { combineReducers } from "redux";
import { getDataReducer } from "./dataReducers";

const reducers = combineReducers({
  allData : getDataReducer,
});
export default reducers;
