export const ActionTypes = {
  GET_DATA: "GET_DATA",
  DELETE_DATA: "DELETE_DATA",
};