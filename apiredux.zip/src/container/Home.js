import React from "react";
import { useDispatch, useSelector } from "react-redux/es/exports";
import { deletedData, loadData } from "../redux/action/action";
import { useEffect } from "react";
import { Link } from "react-router-dom";
 
export const Home = () => {
  const { datas } = useSelector((state) => state.allData);
  let dispatch = useDispatch();
  useEffect(() => {
    dispatch(loadData());
  }, []);

  const handlerDeleteData = (id) => {
    if (window.confirm("are you sure to delete this data")) {
      dispatch(deletedData(id));
    }
  };

  return (
    <>
      <div className="container my-2">
        <div className="d-flex justify-content-between">
          <h1>STUDENT DATA</h1>
          <Link to="/addData">
            <button className=" btn btn-primary">+Add Data</button>
          </Link>
        </div>
      </div>
      <div>
        <div>
          <div className="container my-4">
            <table className="table">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Title</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
                {datas &&
                  datas.map((data) => (
                    <tr key={data.id}>
                      <th scope="row">{data.id}</th>
                      <td>{data.title}</td>
                      <th>
                        <button>
                          <i
                            style={{ fontSize: "18px", color: "#cece12b5" }}
                            className="fa"
                          >
                            &#xf044;
                          </i>
                        </button>
                        <button
                          className="mx-2"
                          onClick={() => handlerDeleteData(data.id)}
                        >
                          <i
                            style={{ fontSize: "18px", color: "red" }}
                            className="fa"
                          >
                            &#xf014;
                          </i>
                        </button>
                      </th>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
};
