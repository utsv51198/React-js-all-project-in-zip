import "./App.css";
import { Payment } from "./components/Payment";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { Suceesful } from "./components/Suceesful";

function App() {
  return (
    <Router>
      <Routes>
        <Route exact path="/" element={<Payment />} />
        <Route exact path="/success" element={<Suceesful />} />
      </Routes>
    </Router>
  );
}

export default App;
