import React from "react";

export const Suceesful = () => {
  return (
    <div>
      <h1>Suceesful</h1>
    </div>
  );
};
