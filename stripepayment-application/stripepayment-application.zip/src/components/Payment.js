import React from "react";
import axios from "axios";
import { useState } from "react";
import StripeCheckout from "react-stripe-checkout";
import { useNavigate } from "react-router-dom";

export const Payment = () => {
  const navigate = useNavigate();
  const [product] = useState({
    name: "Sample Game",
    price: 200,
    description: "This is Juat a Game",
  });

  const handleToken = async (token, addresses) => {
    const response = await axios.post("http://localhost:5000/checkout", {
      token,
      product,
    });
    console.log("RESPONSE", response);
    const { status } = response;
    console.log("STATUS", status);

    if (response.status === 200) {
      alert("Success! Check email for details");
      navigate("/success");
    } else {
      alert("Something went wrong");
    }
  };
  return (
    <div className="container">
      <br />
      <br />
      <h1 className="text-center"> Stripe Payment Getway Demo</h1>
      <br />
      <br />
      <div className="form-group container">
        <StripeCheckout
          className="center"
          stripeKey="pk_test_51KVDzxLqP6NVVgd3TuKtrxiCDodKsgmlFRzNELtkltn9MRYzNqmJIdZ6xcmleMNs3Qw2woLDfMioK1DV4rowRYou00LDa87W3F"
          token={handleToken}
          amount={product.price * 100}
          name={product.name}
          billingAddress
          shippingAddress
        />
      </div>
    </div>
  );
};
