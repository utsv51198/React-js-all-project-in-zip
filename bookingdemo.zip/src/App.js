import React from 'react';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  useRoutes,
} from "react-router-dom";
import Booking from "./pages/Booking"
import ReviewBooking2 from './pages/ReviewBooking2';

function App() {
  return (
    <>
      <Routes>
        <Route exact path="/"  element={<Booking/>} />
        <Route exact path='/reviewbooking2' element = {<ReviewBooking2/>}/> 
      </Routes>
    </>
  );
}

export default App;
