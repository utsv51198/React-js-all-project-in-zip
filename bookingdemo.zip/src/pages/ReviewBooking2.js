import React from "react";
import Footer from "./Footer";

export default function ReviewBooking2() {
  return (
    <div>
      <nav className="navbar navbar-expand-lg bg-white navbar-light sticky-top p-0">
        <div className="container">
          <a href="index.html" className="navbar-brand nlogo">
            <img
              src="assets/images/logo/logo.png"
              alt="logo"
              width=""
              height=""
            />
          </a>
          <a href="index.html" className="navbar-brand slogo">
            <img
              src="assets/images/logo/medx1.png"
              alt="logo"
              width=""
              height=""
            />
            <img
              src="assets/images/logo/medx2.png"
              alt="tagline"
              width=""
              height=""
            />
          </a>
          <button
            type="button"
            className="navbar-toggler me-4"
            data-bs-toggle="collapse"
            data-bs-target="#navbarCollapse"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarCollapse">
            <div className="navbar-nav ms-auto p-4  p-lg-0">
              <a href="index.html" className="nav-item nav-link">
                Home
              </a>
              <a href="education.html" className="nav-item nav-link active">
                Education
              </a>
              <a href="community.html" className="nav-item nav-link">
                Community
              </a>
              <a href="offer.html" className="nav-item nav-link">
                Offer
              </a>
            </div>
            <a href="login.html" className="btn btn-login">
              Log in
            </a>
          </div>
        </div>
      </nav>

      <section className="mt-5 d-m-none">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <ul className="breadcrumb mt-3">
                <li>
                  <a href="profile.html">Profile</a>
                </li>
                <li>/</li>
                <li className="active">Doctors without...</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* <!-- Desktop Booking Start --> */}
      <section className="pt-3 pb-5 d-m-none">
        <div className="container">
          <div className="row p-20">
            <div className="review-bg">
              <div className="booking mt-4 mob-mt-0">
                <h3 className="title my-3 mob-mt-0">
                  Review Booking Information
                </h3>
                <div className="col-md-6 coupon">
                  <div className="d-flex">
                    <div className="block1">
                      <img
                        src="assets/images/qr-code.png"
                        className=""
                        width=""
                        height=""
                        alt=""
                      />
                      <span>Date and Time</span>
                      <h4>16 Sep 2022</h4>
                      <h5>10:00 - 10: 13</h5>
                      <ul>
                        <li>
                          <span>Seal</span>
                          <strong>23A</strong>
                        </li>
                        <li>
                          <span>Price</span>
                          <strong>฿ 300.00</strong>
                        </li>
                      </ul>
                    </div>
                    <div className="block2">
                      <a href="">
                        <img
                          src="assets/images/Ellipse 98.png"
                          className=""
                          width=""
                          height=""
                          alt=""
                        />
                      </a>
                      <a href="">
                        <h4>Dental Implants specialists in ...</h4>
                      </a>
                      <span className="text-center">Onsite</span>
                    </div>
                  </div>
                </div>
                <div className="col-md-6 c-details">
                  <div className="d-flex">
                    <div>
                      <ul>
                        <li>
                          <span>First Name</span>
                          <strong>Kittiya</strong>
                        </li>
                        <li>
                          <span>Email</span>
                          <strong>mail@mail.com</strong>
                        </li>
                      </ul>
                    </div>
                    <div>
                      <ul>
                        <li>
                          <span>Last Name</span>
                          <strong>Yuthasastrkosol</strong>
                        </li>
                        <li>
                          <span>Mobile Phone Number</span>
                          <strong>090-7700123</strong>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <hr />
              <h3 className="title my-3">Payment Method</h3>
              <div className="row">
                <div className="col-md-5">
                  <div className="pblock">
                    <img
                      src="assets/images/image 57.png"
                      alt=""
                      width=""
                      height=""
                      className=""
                    />
                    <div>
                      <strong>Kittiya Yuthasastrkosol</strong>
                      <span>Promptpay 0901234567</span>
                    </div>
                  </div>
                </div>
                <div className="col-md-5">
                  <div className="pblock">
                    <img
                      src="assets/images/image 58.png"
                      alt=""
                      width=""
                      height=""
                      className=""
                    />
                    <div>
                      <strong>Kittiya Yuthasastrkosol</strong>
                      <span>SCB 5052565979</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-12">
            <div className="clearfix"></div>
            <div className="mob-bg-white">
              <a
                href=""
                className="btn btn-join bg-secondary mt-4"
                data-bs-target="#cancelbooking"
                data-bs-toggle="modal"
              >
                Cancel Request
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* // <!-- Desktop Booking End --> */}

      {/* //  <!-- Booking Start --> */}

      <section className="bg-red mob-booking d-none">
        <div className="container">
          <div className="row">
            <div className="col-md-12 bg-red" style={{ display: "none" }}>
              <div className="d-flex align-items-center justify-content-between mob-mt-39">
                <div>
                  <a href="review-booking.html">
                    <img
                      src="assets/images/768/arrow-left-w.png"
                      className=""
                      alt=""
                      width=""
                      height=""
                    />
                  </a>
                </div>
                <div>
                  <h4 className="mb-0 text-white">Booking Detail</h4>
                </div>
                <div></div>
              </div>
              <div className="m-coupon red">
                <div className="text-center mh-300">
                  <div className="qr">
                    <img
                      src="assets/images/768/qrcode.png"
                      className="opacity-2 mb-2"
                      alt=""
                      width=""
                      height=""
                    />
                    <div className="overlay-text text-red">Cancelled</div>
                  </div>
                  <p className="opacity-2">
                    Please show this QR code to enter the event and don’t share
                    this QR to other people.
                  </p>
                </div>
                <div className="m-coupon-data">
                  <div>
                    <a href="">
                      <img
                        src="assets/images/768/Ellipse 98.png"
                        className="rounded"
                        width="97"
                        height=""
                        alt=""
                      />
                    </a>
                  </div>
                  <div>
                    <a href="">
                      <h4 className="mb-0">
                        Dental Implants specialists in ...
                      </h4>
                    </a>
                    <span className="text-center">
                      <img
                        src="assets/images/location-marker.png"
                        className=""
                        width=""
                        height=""
                        alt=""
                      />
                      Bangkok Marriott Hotel Sukhumvit, Pool Side Bangkok,
                      Thailand
                    </span>
                  </div>
                </div>
                <div className="mt-3 mb-2 m-data">
                  <div className="d-flex">
                    <div className="w-130">
                      <span>Date</span>
                      <h4>16 Sep 2022</h4>
                    </div>
                    <div>
                      <span>Time</span>
                      <h4>10:00 - 10: 13</h4>
                    </div>
                  </div>
                  <div className="d-flex">
                    <div className="w-130">
                      <span>Seal</span>
                      <h4>23A</h4>
                    </div>
                    <div>
                      <span>Price</span>
                      <h4>฿ 300.00</h4>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div
              className="col-md-12 bg-green2 green"
              style={{ display: "none" }}
            >
              <div className="d-flex align-items-center justify-content-between mob-mt-39">
                <div>
                  <a href="review-booking.html">
                    <img
                      src="assets/images/768/arrow-left-w.png"
                      className=""
                      alt=""
                      width=""
                      height=""
                    />
                  </a>
                </div>
                <div>
                  <h4 className="mb-0 text-white">Booking Detail</h4>
                </div>
                <div></div>
              </div>
              <div className="m-coupon green">
                <div className="text-center mh-300">
                  <div className="qr">
                    <img
                      src="assets/images/768/qrcode.png"
                      className="mb-2"
                      alt=""
                      width=""
                      height=""
                    />
                  </div>
                  <p className="">
                    Please show this QR code to enter the event and don’t share
                    this QR to other people.
                  </p>
                </div>
                <div className="m-coupon-data">
                  <div>
                    <a href="">
                      <img
                        src="assets/images/768/Ellipse 98.png"
                        className="rounded"
                        width="97"
                        height=""
                        alt=""
                      />
                    </a>
                  </div>
                  <div>
                    <a href="">
                      <h4 className="mb-0">
                        Dental Implants specialists in ...
                      </h4>
                    </a>
                    <span className="text-center">
                      <img
                        src="assets/images/location-marker.png"
                        className=""
                        width=""
                        height=""
                        alt=""
                      />
                      Bangkok Marriott Hotel Sukhumvit, Pool Side Bangkok,
                      Thailand
                    </span>
                  </div>
                </div>
                <div className="mt-3 mb-2 m-data">
                  <div className="d-flex">
                    <div className="w-130">
                      <span>Date</span>
                      <h4>16 Sep 2022</h4>
                    </div>
                    <div>
                      <span>Time</span>
                      <h4>10:00 - 10: 13</h4>
                    </div>
                  </div>
                  <div className="d-flex">
                    <div className="w-130">
                      <span>Seal</span>
                      <h4>23A</h4>
                    </div>
                    <div>
                      <span>Price</span>
                      <h4>฿ 300.00</h4>
                    </div>
                  </div>
                </div>
              </div>
              <div className="mb-3 m-btn">
                <a
                  href=""
                  className="btn btn-join2 bg-secondary"
                  data-bs-target="#cancelbooking"
                  data-bs-toggle="modal"
                >
                  Cancel Request
                </a>
              </div>
            </div>
            <div className="col-md-12 bg-blue2 blue">
              <div className="d-flex align-items-center justify-content-between mob-mt-39">
                <div>
                  <a href="review-booking.html">
                    <img
                      src="assets/images/768/arrow-left-w.png"
                      className=""
                      alt=""
                      width=""
                      height=""
                    />
                  </a>
                </div>
                <div>
                  <h4 className="mb-0 text-white">Booking Detail</h4>
                </div>
                <div></div>
              </div>
              <div className="m-coupon blue">
                <div className="text-center mh-300">
                  <div className="qr">
                    <img
                      src="assets/images/768/qrcode.png"
                      className="mb-2"
                      alt=""
                      width=""
                      height=""
                    />
                  </div>
                  <p className="">
                    Please show this QR code to enter the event and don’t share
                    this QR to other people.
                  </p>
                </div>
                <div className="m-coupon-data">
                  <div>
                    <a href="">
                      <img
                        src="assets/images/768/Ellipse 98.png"
                        className="rounded"
                        width="97"
                        height=""
                        alt=""
                      />
                    </a>
                  </div>
                  <div>
                    <a href="">
                      <h4 className="mb-0">
                        Dental Implants specialists in ...
                      </h4>
                    </a>
                    <span className="text-center">
                      <img
                        src="assets/images/location-marker.png"
                        className=""
                        width=""
                        height=""
                        alt=""
                      />
                      Bangkok Marriott Hotel Sukhumvit, Pool Side Bangkok,
                      Thailand
                    </span>
                  </div>
                </div>
                <div className="mt-3 mb-2 m-data">
                  <div className="d-flex">
                    <div className="w-130">
                      <span>Date</span>
                      <h4>16 Sep 2022</h4>
                    </div>
                    <div>
                      <span>Time</span>
                      <h4>10:00 - 10: 13</h4>
                    </div>
                  </div>
                  <div className="d-flex">
                    <div className="w-130">
                      <span>Seal</span>
                      <h4>23A</h4>
                    </div>
                    <div>
                      <span>Price</span>
                      <h4>฿ 300.00</h4>
                    </div>
                  </div>
                </div>
              </div>
              <div className="mb-3 m-btn">
                <a
                  href=""
                  className="btn btn-join2 bg-secondary"
                  data-bs-target="#cancelbooking"
                  data-bs-toggle="modal"
                >
                  Cancel Request
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* <!-- Booking End --> */}

      {/* <!-- Footer Start --> */}
      <Footer />
      {/* <!-- Footer End --> */}

      {/* <!-- Back to Top -->
    <!-- <a href="#" className="btn btn-lg btn-primary btn-lg-square back-to-top"><i className="bi bi-arrow-up"></i></a> -->

    <!-- Cancel Booking Modal --> */}
      <div className="modal fade" id="cancelbooking">
        <div className="modal-dialog modal-dialog-centered modal-xs">
          <div className="modal-content">
            {/* <!-- Modal body --> */}
            <div className="modal-body">
              <div className="c-content">
                <div>
                  <img
                    src="assets/images/cancel.png"
                    alt=""
                    width="40"
                    height="40"
                  />
                </div>
                <div className="p-l-20">
                  <h5> Cancel Booking</h5>
                  <p>
                    Are you sure you want to cancel your booking? All of your
                    data will be permanently removed from our servers forever.
                    This action cannot be undone.
                  </p>
                </div>
              </div>
              <div className="d-flex pt-4 cancel-btn-list">
                <a href="" className="float-right btn btn-cancel-d btn-blue">
                  Cancel
                </a>
                <a href="" className="float-right btn btn-cancel">
                  Yes, cancel booking
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
