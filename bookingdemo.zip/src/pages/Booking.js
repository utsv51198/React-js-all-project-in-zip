import React from 'react'
import { Link } from 'react-router-dom'
import Footer from './Footer'
import Navbar from './Navbar'

export default function Booking() {
  return (

<div>
   

 {/* <!-- Navbar Start --> */}
   <Navbar/>
                 
    {/* <!-- Navbar End --> */}

    {/* <!-- Mobile View Top Start --> */}
    <div className="mobile-gray-top d-none">
        <div className="container">
            <div className="row">
                <div className="d-flex align-items-center justify-content-between mob-mt-39">
                    <div>
                        <a href="review-booking.html"><img src="assets/images/768/arrow-left.png" className="" alt=""
                                width="" height="" /></a>
                    </div>
                    <div>
                        <h4 className="mb-0">My Booking</h4>
                    </div>
                    <div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    {/* <!-- Mobile View Top End --> */}

    {/* <!-- Mobile Bottom Menu Start --> */}
    <div className="d-none mob-menu bg-white">
        <ul className="d-flex align-items-center justify-content-between">
            <li>
                <a href="index.html">
                    <img src="assets/images/768/icon1.png" className="" width="" height="" />
                </a>
            </li>
            <li>
                <a href="education.html">
                    <img src="assets/images/768/icon2.png" className="active" width="" height="" />
                </a>
            </li>
            <li>
                <a href="community.html">
                    <img src="assets/images/768/icon3.png" className="" width="" height="" />
                </a>
            </li>
            <li>
                <a href="offer.html">
                    <img src="assets/images/768/icon4.png" className="" width="" height="" />
                </a>
            </li>
            <li>
                <a href="medx.html">
                    <img src="assets/images/768/icon5.png" className="" width="" height="" />
                </a>
            </li>
        </ul>
    </div>
    {/* <!-- Mobile Bottom Menu End --> */}

    <section className="mt-5  d-m-none">
        <div className="container">
            <div className="row p-8">
                <div className="col-md-12">
                    <h1 className="mt-5  mb-3 main-title">Profile</h1>
                </div>

            </div>
        </div>
    </section>

    {/* <!-- Booking Start --> */}
    <section className="dashboard top-curve2 mob-brd-radius-0">
        <div className="container">
            <div className="row p-8">
                <div className="col-md-2 d-m-none">
                    <div className="sidebar">
                        <ul>
                            <li>
                                <a href="profile.html">My Profile</a>
                            </li>
                            <li>
                                <a href="medx.html">My MedX</a>
                            </li>
                            <li>
                                <a href="internship.html">Internship</a>
                            </li>
                            <li>
                                <a href="booking.html" className="active">My Booking</a>
                            </li>
                            <li>
                                <a href="bookmark.html">Bookmark</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div className="col-md-10">
                    <div className="dashboard-inner">
                        <h2 className="mb-3">Upcoming</h2>
                        <div className="row booking mb-4">
                            <div className="col-md-6 coupon mb-3">
                                <div className="d-flex">
                                    <div className="block1">
                                        <img src="assets/images/qr-code.png" className="" width="" height="" alt="" />
                                        <span>Date and Time</span>
                                        <h4>16 Sep 2022</h4>
                                        <h5>10:00 - 10: 13</h5>
                                        <ul>
                                            <li>
                                                <span>Seal</span>
                                                <strong>23A</strong>
                                            </li>
                                            <li>
                                                <span>Price</span>
                                                <strong>฿ 300.00</strong>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="block2">
                                        <Link to="/reviewbooking2"><img src="assets/images/Ellipse 98.png" className=""
                                                width="" height="" alt="" /></Link>
                                        <Link to="/reviewbooking2">
                                            <h4>Dental Implants specialists in ...</h4>
                                        </Link>
                                        <span className="text-center">Onsite</span>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-6 coupon mb-3">
                                <div className="d-flex">
                                    <div className="block1 bg-green">
                                        <img src="assets/images/qr-code.png" className="" width="" height="" alt="" />
                                        <span>Date and Time</span>
                                        <h4>16 Sep 2022</h4>
                                        <h5>10:00 - 10: 13</h5>
                                        <ul>
                                            <li>
                                                <span>Seal</span>
                                                <strong>23A</strong>
                                            </li>
                                            <li>
                                                <span>Price</span>
                                                <strong>฿ 300.00</strong>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="block2">
                                        <a href=""><img src="assets/images/Ellipse 98.png" className="" width="" height=""
                                                alt="" /></a>
                                        <a href="">
                                            <h4 className="text-green">Dental Implants specialists in ...</h4>
                                        </a>
                                        <span className="text-center text-green2">Onsite</span>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-6 coupon mb-3">
                                <div className="d-flex">
                                    <div className="block1 bg-green">
                                        <img src="assets/images/qr-code.png" className="" width="" height="" alt="" />
                                        <span>Date and Time</span>
                                        <h4>16 Sep 2022</h4>
                                        <h5>10:00 - 10: 13</h5>
                                        <ul>
                                            <li>
                                                <span>Seal</span>
                                                <strong>23A</strong>
                                            </li>
                                            <li>
                                                <span>Price</span>
                                                <strong>฿ 300.00</strong>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="block2">
                                        <a href=""><img src="assets/images/Ellipse 98.png" className="" width="" height=""
                                                alt="" /></a>
                                        <a href="">
                                            <h4 className="text-green">Dental Implants specialists in ...</h4>
                                        </a>
                                        <span className="text-center text-green2">Onsite</span>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-6 coupon mb-3">
                                <div className="d-flex">
                                    <div className="block1">
                                        <img src="assets/images/qr-code.png" className="" width="" height="" alt="" />
                                        <span>Date and Time</span>
                                        <h4>16 Sep 2022</h4>
                                        <h5>10:00 - 10: 13</h5>
                                        <ul>
                                            <li>
                                                <span>Seal</span>
                                                <strong>23A</strong>
                                            </li>
                                            <li>
                                                <span>Price</span>
                                                <strong>฿ 300.00</strong>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="block2">
                                        <a href=""><img src="assets/images/Ellipse 98.png" className="" width="" height=""
                                                alt="" /></a>
                                        <a href="">
                                            <h4>Dental Implants specialists in ...</h4>
                                        </a>
                                        <span className="text-center">Onsite</span>
                                    </div>
                                </div>
                            </div>

                            <div className="col-md-6 coupon mb-3">
                                <div className="d-flex">
                                    <div className="block1 bg-green">
                                        <img src="assets/images/qr-code.png" className="" width="" height="" alt="" />
                                        <span>Date and Time</span>
                                        <h4>16 Sep 2022</h4>
                                        <h5>10:00 - 10: 13</h5>
                                        <ul>
                                            <li>
                                                <span>Seal</span>
                                                <strong>23A</strong>
                                            </li>
                                            <li>
                                                <span>Price</span>
                                                <strong>฿ 300.00</strong>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="block2">
                                        <a href=""><img src="assets/images/Ellipse 98.png" className="" width="" height=""
                                                alt="" /></a>
                                        <a href="">
                                            <h4 className="text-green">Dental Implants specialists in ...</h4>
                                        </a>
                                        <span className="text-center text-green2">Onsite</span>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-6 coupon mb-3">
                                <div className="d-flex">
                                    <div className="block1 bg-green">
                                        <img src="assets/images/qr-code.png" className="" width="" height="" alt="" />
                                        <span>Date and Time</span>
                                        <h4>16 Sep 2022</h4>
                                        <h5>10:00 - 10: 13</h5>
                                        <ul>
                                            <li>
                                                <span>Seal</span>
                                                <strong>23A</strong>
                                            </li>
                                            <li>
                                                <span>Price</span>
                                                <strong>฿ 300.00</strong>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="block2">
                                        <a href=""><img src="assets/images/Ellipse 98.png" className="" width="" height=""
                                                alt="" /></a>
                                        <a href="">
                                            <h4 className="text-green">Dental Implants specialists in ...</h4>
                                        </a>
                                        <span className="text-center text-green2">Onsite</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <h2 className="mb-3">Cancel</h2>
                        <div className="row booking mob-mb-30 clearfix">
                            <div className="col-md-6 coupon mb-3">
                                <div className="d-flex">
                                    <div className="block1 bg-orange">
                                        <img src="assets/images/qr-code.png" className="" width="" height="" alt="" />
                                        <span>Date and Time</span>
                                        <h4>16 Sep 2022</h4>
                                        <h5>10:00 - 10: 13</h5>
                                        <ul>
                                            <li>
                                                <span>Seal</span>
                                                <strong>23A</strong>
                                            </li>
                                            <li>
                                                <span>Price</span>
                                                <strong>฿ 300.00</strong>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="block2">
                                        <a href=""><img src="assets/images/Ellipse 98.png" className="" width="" height=""
                                                alt="" /></a>
                                        <a href="">
                                            <h4 className="text-orange">Dental Implants specialists in ...</h4>
                                        </a>
                                        <span className="text-center text-orange2">Onsite</span>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-6 coupon mb-3">
                                <div className="d-flex">
                                    <div className="block1 bg-orange">
                                        <img src="assets/images/qr-code.png" className="" width="" height="" alt="" />
                                        <span>Date and Time</span>
                                        <h4>16 Sep 2022</h4>
                                        <h5>10:00 - 10: 13</h5>
                                        <ul>
                                            <li>
                                                <span>Seal</span>
                                                <strong>23A</strong>
                                            </li>
                                            <li>
                                                <span>Price</span>
                                                <strong>฿ 300.00</strong>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="block2">
                                        <a href=""><img src="assets/images/Ellipse 98.png" className="" width="" height=""
                                                alt="" /></a>
                                        <a href="">
                                            <h4 className="text-orange">Dental Implants specialists in ...</h4>
                                        </a>
                                        <span className="text-center text-orange2">Onsite</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    {/* <!-- Booking End --> */}

    {/* <!-- Footer Start --> */}
    <Footer/>
    {/* <!-- Footer End --> */}



</div>
  )
}
