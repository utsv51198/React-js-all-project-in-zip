import './App.css';
import {ArrayList} from "./Components/ArrayList"

function App() {
  return (
    <div>
      <ArrayList/>
    </div>
  );
}

export default App;
