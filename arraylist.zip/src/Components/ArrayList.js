import React from 'react'

export const ArrayList = () => {
    const stockData = [
      {
        company: "Twitter Inc",
        ticker: "TWTR",
        stockPrice: "22.76 USD",
        timeElapsed: "5 sec ago",
      },
      {
        company: "Square Inc",
        ticker: "SQ",
        stockPrice: "45.28 USD",
        timeElapsed: "10 sec ago",
      },
      {
        company: "Shopify Inc",
        ticker: "SHOP",
        stockPrice: "341.79 USD",
        timeElapsed: "3 sec ago",
      },
      {
        company: "Sunrun Inc",
        ticker: "RUN",
        stockPrice: "9.87 USD",
        timeElapsed: "4 sec ago",
      },
      {
        company: "Adobe Inc",
        ticker: "ADBE",
        stockPrice: "300.99 USD",
        timeElapsed: "10 sec ago",
      },
      {
        company: "HubSpot Inc",
        ticker: "HUBS",
        stockPrice: "115.22 USD",
        timeElapsed: "12 sec ago",
      },
    ];
    const stockList = stockData.map((stock) => (
      <ol className="list-group list-group-numbered" key={stock.company}>
        <li className="list-group-item list-group-item-info">
          Comapny : {stock.company}
        </li>
        <li className="list-group-item list-group-item">
          Ticker : {stock.ticker}
        </li>
        <li className="list-group-item list-group-item">
          Price : {stock.stockPrice}
        </li>
        <li className="list-group-item list-group-item">
          Time-Elapsed : {stock.timeElapsed}
        </li>
      </ol>
    ));
  return (
      <>
      <div className='container'>
          <h2>Stock Details</h2>
      </div>
    <div className='container'>{stockList}</div>
    </>
  )
}
