let constants = {
    STATUS:
    {
        "1": "Active",
        "0": "Deactive"
    },
    CATEGORY_PARENT_TYPE:
    {
        "community": "Community",
        "offers": "Offers"
    },
    CATEGORY_TYPE:
    {
        "infoucs": "Infocus",
        "news": "News",
        "blog":"Blog"
    }
};

export default (constants);
