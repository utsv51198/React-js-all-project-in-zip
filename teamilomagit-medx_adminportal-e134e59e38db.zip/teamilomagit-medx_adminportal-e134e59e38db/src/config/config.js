module.exports = {
  API_URL: "http://159.65.1.66:8002",
  //API_URL: "http://localhost:8002",
  LIMIT:5,
  google: {
    API_KEY: "",
    CLIENT_ID: "",
    SECRET: "",
  },
  facebook: {
    APP_ID: "",
  },
}