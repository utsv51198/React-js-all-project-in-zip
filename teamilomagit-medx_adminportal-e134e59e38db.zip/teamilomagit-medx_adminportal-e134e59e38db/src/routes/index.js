import React from "react";
import { Redirect } from "react-router-dom";


// Authentication related pages
import Login from "../pages/Authentication/Login";
import Logout from "../pages/Authentication/Logout";
import Register from "../pages/Authentication/Register";
import ForgetPwd from "../pages/Authentication/ForgetPassword";

//  // Inner Authentication
import Login1 from "../pages/AuthenticationInner/Login";
import Login2 from "../pages/AuthenticationInner/Login2";
import Register1 from "../pages/AuthenticationInner/Register";
import Register2 from "../pages/AuthenticationInner/Register2";
import Recoverpw from "../pages/AuthenticationInner/Recoverpw";
import Recoverpw2 from "../pages/AuthenticationInner/Recoverpw2";
import ForgetPwd1 from "../pages/AuthenticationInner/ForgetPassword";
import ForgetPwd2 from "../pages/AuthenticationInner/ForgetPassword2";
import LockScreen from "../pages/AuthenticationInner/auth-lock-screen";
import LockScreen2 from "../pages/AuthenticationInner/auth-lock-screen-2";
import ConfirmMail from "../pages/AuthenticationInner/page-confirm-mail";
import ConfirmMail2 from "../pages/AuthenticationInner/page-confirm-mail-2";
import EmailVerification from "../pages/AuthenticationInner/auth-email-verification";
import EmailVerification2 from "../pages/AuthenticationInner/auth-email-verification-2";
import TwostepVerification from "../pages/AuthenticationInner/auth-two-step-verification";
import TwostepVerification2 from "../pages/AuthenticationInner/auth-two-step-verification-2";

// Dashboard
import Dashboard from "../pages/Dashboard/index";



import ProfileRoles from "../pages/Profile/Role/Roles";
import ProfileAddRoles from "../pages/Profile/Role/AddRoles";
import ProfileEditRoles from "../pages/Profile/Role/EditRoles";



import Institution from "../pages/Institution/Institutions";
import RequestInstitutions from "../pages/Institution/RequestInstitution/RequestInstitutions";
import ViewRequestInstitutions from "../pages/Institution/RequestInstitution/ViewRequestInstitutions";


import SubInstitutions from "../pages/SubInstitution/SubInstitutions";
import RequestSubInstitutions from "../pages/SubInstitution/RequestSubInstitution/RequestSubInstitutions";
import ViewRequestSubInstitutions from "../pages/SubInstitution/RequestSubInstitution/ViewRequestSubInstitutions";



import ProgramActivities from "../pages/Program/Activities";
import ProgramEvents from "../pages/Program/Events";
import ProgramLibraries from "../pages/Program/Libraries";


import SettingSpecializations from "../pages/Setting/Specializations";
import SettingBanners from "../pages/Master/Banner/Banners";
import SettingEducationTypes from "../pages/Setting/EducationTypes";
import SettingNews from "../pages/Setting/News";
import SettingPageContent from "../pages/Setting/PageContent";
import SystemSetting from "../pages/Setting/SystemSetting/SystemSettings";


import UserUsers from "../pages/User/Users";
import UserPrograms from "../pages/User/UserPrograms";
import UserScores from "../pages/User/UserScores";
import UserBookings from "../pages/User/UserBookings";
import UserBookmarks from "../pages/User/UserBookmarks";
import UserLibraries from "../pages/User/UserLibraries";
import UserActivities from "../pages/User/UserActivities";


import MarketingOffers from "../pages/Marketing/Offers";
import MarketingServices from "../pages/Marketing/Services";
import MarketingProdcuts from "../pages/Marketing/Products";


import UpdateProfile from "../pages/Profile/UserProfile/UpdateProfile";
import ChangePassword from "../pages/Profile/UserProfile/ChangePassword";

import Interests from "../pages/Master/Interest/Interests";
import OfferTypes from "../pages/Master/OfferType/OfferType";

import OrganizationTypes from "pages/Master/OrganizationType/OrganizationType";
import ServiceTypes from "pages/Master/ServiceType/ServiceType";
import Provinces from "pages/Master/Province/Province";
import Districts from "pages/Master/District/District";
import SubDistricts from "pages/Master/SubDistrict/SubDistrict";
import Categories from "pages/Master/Category/Category";


import CommunityPosts from "../pages/Community/CommunityPosts";

import MarktingProducts from "../pages/Marketing/Products";
import MarktingOffers from "../pages/Marketing/Offers";


const authProtectedRoutes = [
  { path: "/dashboard", component: Dashboard },

   //Marketing
   { path: "/products", component: MarktingProducts },
   { path: "/offers", component: MarktingOffers },


  //community
  { path: "/posts", component: CommunityPosts },



  // Profile
  { path: "/roles", component: ProfileRoles },
  { path: "/add-role", component: ProfileAddRoles },
  { path: "/edit-role/:role_id", component: ProfileEditRoles },


  //Institutions
  { path: "/institutions", component: Institution },

  { path: "/request-institutions", component: RequestInstitutions },
  { path: "/view-request-institute/:request_institute_id", component: ViewRequestInstitutions },

  { path: "/sub-institutions", component: SubInstitutions },

  { path: "/request-sub-institutions", component: RequestSubInstitutions },
  { path: "/view-request-sub-institute/:request_institute_id", component: ViewRequestSubInstitutions },

 
  //Programs
  { path: "/activities", component: ProgramActivities },
  { path: "/events", component: ProgramEvents },
  { path: "/libraries", component: ProgramLibraries },


  //Settings
  { path: "/specializations", component: SettingSpecializations },
  { path: "/banners", component: SettingBanners },
  { path: "/education-types", component: SettingEducationTypes },
  { path: "/news", component: SettingNews },
  { path: "/page-content", component: SettingPageContent },
  { path: "/system-settings", component: SystemSetting },


  //Marketing
  { path: "/offers", component: MarketingOffers },
  { path: "/services", component: MarketingServices },
  { path: "/prodcuts", component: MarketingProdcuts },



  //Users
  { path: "/users", component: UserUsers },
  { path: "/user-programs", component: UserPrograms },
  { path: "/user-score", component: UserScores },
  { path: "/user-bookings", component: UserBookings },
  { path: "/user-bookmark", component: UserBookmarks },
  { path: "/user-activities", component: UserActivities },
  { path: "/user-libraries", component: UserLibraries },

  // Non Module Route
  { path: "/update-profile", component: UpdateProfile },
  { path: "/change-password", component: ChangePassword },

  // this route should be at the end of all other routes
  // eslint-disable-next-line react/display-name
  { path: "/", exact: true, component: () => <Redirect to="/dashboard" /> },

  // Interests
  { path: "/interests", component: Interests },

  // OfferTypes
  { path: "/offer-types", component: OfferTypes },

  // OrganizationTypes
  { path: "/organisation-types", component: OrganizationTypes },

  // ServiceTypes
  { path: "/service-type", component: ServiceTypes },

   // Categories
   { path: "/categories", component: Categories },

  // Provinces
  { path: "/provinces", component: Provinces },

  // District 
  { path: "/districts", component: Districts },

  // SubDistricts
  { path: "/sub-districts", component: SubDistricts },

 
];

const publicRoutes = [
  { path: "/logout", component: Logout },
  { path: "/login", component: Login },
  { path: "/forgot-password", component: ForgetPwd },
  { path: "/register", component: Register },

  // { path: "/pages-maintenance", component: PagesMaintenance },
  // { path: "/pages-comingsoon", component: PagesComingsoon },
  // { path: "/pages-404", component: Pages404 },
  // { path: "/pages-500", component: Pages500 },
  // { path: "/crypto-ico-landing", component: CryptoIcoLanding },

  // Authentication Inner
  { path: "/pages-login", component: Login1 },
  { path: "/pages-login-2", component: Login2 },
  { path: "/pages-register", component: Register1 },
  { path: "/pages-register-2", component: Register2 },
  { path: "/page-recoverpw", component: Recoverpw },
  { path: "/page-recoverpw-2", component: Recoverpw2 },
  { path: "/pages-forgot-pwd", component: ForgetPwd1 },
  { path: "/auth-recoverpw-2", component: ForgetPwd2 },
  { path: "/auth-lock-screen", component: LockScreen },
  { path: "/auth-lock-screen-2", component: LockScreen2 },
  { path: "/page-confirm-mail", component: ConfirmMail },
  { path: "/page-confirm-mail-2", component: ConfirmMail2 },
  { path: "/auth-email-verification", component: EmailVerification },
  { path: "/auth-email-verification-2", component: EmailVerification2 },
  { path: "/auth-two-step-verification", component: TwostepVerification },
  { path: "/auth-two-step-verification-2", component: TwostepVerification2 },
];

export { authProtectedRoutes, publicRoutes };
