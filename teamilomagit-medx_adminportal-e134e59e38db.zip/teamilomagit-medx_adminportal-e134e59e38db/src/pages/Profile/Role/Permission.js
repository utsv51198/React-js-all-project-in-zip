import React, { useEffect, useState } from "react";
import {
  Row,
  Col,
  Card,
  CardBody,
  FormGroup,
  Button,
  CardTitle,
  CardSubtitle,
  Label,
  Input,
  Container,
  FormFeedback,
  Form,
} from "reactstrap";
// Formik validation
import * as Yup from "yup";
import { useFormik } from "formik";


import toastr from "toastr";
import "toastr/build/toastr.min.css";

import { RoleApi } from "../../../apis/RoleApi";
import { RoleModuleApi } from "../../../apis/RoleModuleApi";


//Import Breadcrumb
import Breadcrumbs from "../../../components/Common/Breadcrumb";
import { withTranslation } from "react-i18next";
import i18n from "../../../i18n";

const FormValidations = (props) => {

    const [allmodules, setAllModule] = useState([])
    useEffect(() => {
        getAllModule()
    }, [])
  
    const getAllModule = () => {
     RoleModuleApi.getAllModule()
        .then(res => {
          setAllModule(res.data.modules);
        }).catch(err => {
          console.log(err)
        })
    }

  // Form validation 
  const validationType = useFormik({
    // enableReinitialize : use this flag when initial values needs to be changed
    enableReinitialize: true,

    initialValues: {
        role: ''
    },
    validationSchema: Yup.object().shape({
        role: Yup.string().required(
        "This value is required"
      )
    }),
    onSubmit: (values) => {
      console.log("values", values);
        // setLoader(true)
        RoleApi.createRole(values)
        .then(res => {
            // setLoader(false)
            if (res.data.success) {
                toastr.success(`Record Added Successfully`, '');
                window.location.href = '/roles';
            } else {
                toastr.error(res.message, '');
            }
        }).catch(function (error) {
        toastr.error(error.response.data.message, '');
        });
    }
  });
  

  return (
    <React.Fragment>
      <div className="page-content">
      <Breadcrumbs title="Forms" breadcrumbItem="Form Validation" />
        <Container fluid={true}>
       
          <Row>

            <Col lg={12}>
              <Card>
                <CardBody >
                

                  <Form
                    onSubmit={(e) => {
                      e.preventDefault();
                      validationType.handleSubmit();
                      return false;
                    }}>
                    <Col sm={6}>
                    <div className="mb-3">
                      <Label className="form-label">Role</Label>
                      <Input
                        name="role"
                        placeholder="Role"
                        type="text"
                        onChange={validationType.handleChange}
                        onBlur={validationType.handleBlur}
                        value={validationType.values.role || ""}
                        invalid={
                          validationType.touched.role && validationType.errors.role ? true : false
                        }
                      />
                      {validationType.touched.role && validationType.errors.role ? (
                        <FormFeedback type="invalid">{validationType.errors.role}</FormFeedback>
                      ) : null}
                    </div>
                    </Col>

                    <div className="ul-list-style">
                    <Label className="form-label">Modules</Label>
                        <ul>

                          {
                            allmodules.map((menu, i) => {
                              if (!menu.is_dropdown) {
                                return (
                                  <>
                                    <li>

                                      <span className="caret">
                                        <div className="form-check">
                                          <input
                                            className="form-check-input"
                                            type="checkbox"
                                            name={`module_name[${i}]`}
                                            value={JSON.stringify(menu)}
                                            onChange={(e) => myhandleCheck(e, menu, 'parent', null, i, null)}
                                          />
                                          <label className="form-check-label" htmlFor="defaultCheck1">{menu.name}</label>
                                        </div></span>
                                    </li>
                                  </>
                                )

                              } else {

                                return (
                                  <>
                                    <li>
                                      <span className="caret">
                                        <div className="form-check">
                                          <input
                                            className="form-check-input"
                                            type="checkbox"
                                            name={`module_name[${i}]`}
                                            value={JSON.stringify(menu)}
                                          />
                                          <label className="form-check-label" htmlFor="defaultCheck1" >{menu.name}</label>
                                        </div></span>

                                     {
                                        menu.childrens.map((childmenu, j) => {
                                          return (
                                            <ul className="nested" key={j}>
                                              <li>
                                                <span className="caret">
                                                  <div className="form-check">
                                                    <input
                                                      className="form-check-input"
                                                      type="checkbox"
                                                      name={`module_name[${i}][${j}]`}
                                                      value={JSON.stringify(childmenu)}
                                                    />
                                                    <label className="form-check-label" htmlFor="defaultCheck1" > {childmenu.name}</label>
                                                  </div></span>
                                                <ul className="nested">


                                                  <li><div className="form-check">
                                                    <input
                                                      className="form-check-input"
                                                      type="checkbox"
                                                      name={`module_name[${i}][${j}]['view']`}
                                                      value={JSON.stringify(childmenu)}
                                                    />
                                                    <label className="form-check-label" htmlFor="defaultCheck1" >View</label>
                                                  </div>
                                                  </li>


                                                  {childmenu.is_readonly == 0 &&
                                                    <>
                                                      <li>
                                                        <div className="form-check">
                                                          <input
                                                            className="form-check-input"
                                                            type="checkbox"
                                                            name={`module_name['add'][${childmenu.id}]`}
                                                            value={JSON.stringify(childmenu)}
                                                          />
                                                          <label className="form-check-label" htmlFor="defaultCheck1" > Add</label>
                                                        </div>
                                                      </li>
                                                      <li>
                                                        <div className="form-check">
                                                          <input
                                                            className="form-check-input"
                                                            type="checkbox"
                                                            name={`module_name['edit'][${childmenu.id}]`}
                                                            value={JSON.stringify(childmenu)}
                                                          />
                                                          <label className="form-check-label" htmlFor="defaultCheck1" >Edit</label>
                                                        </div>
                                                      </li>
                                                      <li>
                                                        <div className="form-check">
                                                          <input
                                                            className="form-check-input"
                                                            type="checkbox"
                                                            name={`module_name['delete'][${childmenu.id}]`}
                                                            value={JSON.stringify(childmenu)}
                                                          />
                                                          <label className="form-check-label" htmlFor="defaultCheck1" > Delete</label>
                                                        </div>

                                                      </li>
                                                    </>
                                                  }
                                                </ul>
                                              </li>
                                            </ul>

                                          )

                                        })

                                      } 
                                    </li>

                                  </>
                                )

                              }
                            })
                          }


                        </ul>
                      </div>
                   
                    <div className="d-flex flex-wrap gap-2">
                      <Button type="submit" color="primary" >
                      {props.t("Submit")}
                      </Button>{" "}
                    </div>
                  </Form>
                </CardBody>
              </Card>
            </Col>

          </Row>
        </Container>
      </div>
    </React.Fragment>
  );
};

FormValidations.propTypes = {
  t: PropTypes.any,
  preGlobalFilteredRows: PropTypes.any,
};

export default withTranslation()(FormValidations);
