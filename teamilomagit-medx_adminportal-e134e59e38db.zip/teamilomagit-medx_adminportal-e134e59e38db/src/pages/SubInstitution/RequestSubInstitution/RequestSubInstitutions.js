// src/components/filter.
import React, { useMemo, useEffect,useState } from "react";
import PropTypes from 'prop-types';

//import components
import Breadcrumbs from '../../../components/Common/Breadcrumb';
import TableContainer from '../../../components/Common/TableContainer';
import DataTable from 'react-data-table-component';
import { RequestSubInstitutionApi } from "../../../apis/RequestSubInstitutionApi";
import { useHistory } from "react-router-dom"


import { Link } from "react-router-dom";
import {
    Button,
    DropdownToggle,
    DropdownMenu,
    DropdownItem,
    ButtonDropdown,
  } from "reactstrap";

import Swal from "sweetalert2";


function RequestSubInstitutions() {

    const history = useHistory();
    const [roles, setRoles] = useState([]);
    const [loading, setLoading] = useState(false);
    const [activeData, setActiveData] = useState({
        activePage: 1,
        totalPage: 1,
        search: "",
        limit: 10,
    });

    useEffect(() => {
      getAllSubRequestInstitution(activeData);
    }, []);
    
    const columns = [
        {
          name: "ID",
          selector: row => row.id,
          sort: "asc",
          width: 150,
          sortable: true,
          defaultSortField: true,
          defaultSortAsc: false
        },
        {
            name:"Institution Name",
            selector: row => row.insitution_name,
            sort: "asc",
            width: 270,
            sortable: true,
            defaultSortField: true,
            defaultSortAsc: false
        },
        {
          name:"Sub Institution Name",
          selector: row => row.sub_insitution_name,
          sort: "asc",
          width: 270,
          sortable: true,
          defaultSortField: true,
          defaultSortAsc: false
        },
        {
          name:"Affiliation",
          selector: row => row.affiliation,
          sort: "asc",
          width: 270,
          sortable: true,
          defaultSortField: true,
          defaultSortAsc: false
        },
        {
          name:"Status",
          selector: row => row.status,
          sort: "asc",
          width: 270,
          sortable: true,
          defaultSortField: true,
          defaultSortAsc: false
        },
        {
          name:"View",
          selector: row => row.action,
          sort: "asc",
          width: 200,
        }
      ];


    
    const getAllSubRequestInstitution = (data) => {
        setLoading(true);
        RequestSubInstitutionApi.getAllRequestSubInstitutions(data)
          .then((res) => {
            setActiveData({
              activePage: activeData.activePage,
              totalPage: res.data.requestsubinstitute.count,
              search: activeData.search,
              limit: activeData.limit,
            });
            let data = [];
            res.data.requestsubinstitute.rows.forEach((v, i) => {
              data[i] = {
                id: v.id,
                insitution_name: v.Institute.insitution_name,
                sub_insitution_name: v.sub_insitution_name,
                affiliation: v.affiliation,
                status: v.status,
                action: (
                  <>
                    <Link
                      to={`/view-request-sub-institute/${v.id}`}
                    >
                        <Button
                        type="button"
                        color="primary"
                        className="btn-sm btn-rounded"
                        >
                        View Details
                        </Button>
                    </Link>
                  </>
                ),
              };
            });
            setRoles(data);
            setLoading(false);
          })
          .catch((err) => {
            console.log(err);
          });
      };

    const handleChange = (v) => {
    setActiveData({ activePage: v, totalPage: activeData.totalPage, search: activeData.search, limit: activeData.limit });
    const data = { activePage: v, totalPage: activeData.totalPage, search: activeData.search, limit: activeData.limit }
    getAllRoles(data)
    }


    const handleRowChange = (v) => {
    setActiveData({ activePage: activeData.activePage, totalPage: activeData.totalPage, search: activeData.search, limit: v });
    const data = { activePage: activeData.activePage, totalPage: activeData.totalPage, search: activeData.search, limit: v }
    getAllRoles(data)
    }


     //meta title
    document.title = "Request Institution | MedX";

    return (
        <div className="page-content">
            <div className="container-fluid">
            <Breadcrumbs title="Sub Institution" breadcrumbItem="Request Sub Institutions" />
            <center><h1>Coming Soon</h1></center>
            </div>

            

            <div className="container-fluid">
                    {/* <DataTable
                      className="table-bordered"
                      progressPending={loading}
                      columns={columns}
                      data={roles}
                      pagination
                      paginationServer
                      paginationTotalRows={activeData.totalPage}
                      paginationPerPage={activeData.limit}
                      defaultSortFieldID={1}
                      onChangeRowsPerPage={value => handleRowChange(value)}
                      onChangePage={value => handleChange(value)}
                      sortable
                      noHeader
                      defaultSortField="id"
                      defaultSortAsc={false}
                      highlightOnHover
                    /> */}
            </div>
        </div>
    );
}
RequestSubInstitutions.propTypes = {
    preGlobalFilteredRows: PropTypes.any,

};


export default RequestSubInstitutions;