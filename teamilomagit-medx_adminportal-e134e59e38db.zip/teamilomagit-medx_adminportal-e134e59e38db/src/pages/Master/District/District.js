// src/components/filter.
import React, { useEffect, useState } from "react";
import PropTypes from 'prop-types';

//import components
import Breadcrumbs from '../../../components/Common/Breadcrumb';
import DataTable from 'react-data-table-component';
import { DistrictApi } from "../../../apis/DistrictApi";
import { useHistory } from "react-router-dom"
import { withTranslation } from "react-i18next";
import * as Yup from "yup";
import { useFormik } from "formik";
import toastr from "toastr";
import config from "config/config";
import constants from "../../../config/constants";

import {
    Container,
    Row,
    Col,
    Card,
    CardBody,
    Form,
    Label,
    Input,
    FormFeedback,
    Button
} from "reactstrap";

import Swal from "sweetalert2";

function District(props) {
    const history = useHistory();
    const [districtList, setDistrictList] = useState([]);
    const [provinceList, setProvinceList] = useState([]);
    const [fetchDistrict, setFetchDistrict] = useState([]);
    const [postDistrictId, setDistrictId] = useState('');
    const [loading, setLoading] = useState(false);

    const [activeData, setActiveData] = useState({
        page: 1,
        totalPage: 1,
        search: "",
        limit: config.LIMIT
    });

    useEffect(() => {
        getAllDistrict(activeData);
    }, []);

    const formClear = () => {
        validationType.resetForm();
        setFetchDistrict();
    };

    const columns = [
        {
            name: props.t("Sr. No"),
            selector: row => row.district_id,
            sort: "asc",
            width: 150,
            sortable: true,
            defaultSortField: true,
            defaultSortAsc: false
        },
        {
            name: props.t("Name Eng"),
            selector: row => row.name_en,
            sort: "asc",
            width: 270,
            sortable: true,
            defaultSortField: true,
            defaultSortAsc: false
        },
        {
            name: props.t("Name Thai"),
            selector: row => row.name_th,
            sort: "asc",
            width: 270,
            sortable: true,
            defaultSortField: true,
            defaultSortAsc: false
        },
        {
            name: props.t("Status"),
            selector: row => row.status,
            sort: "asc",
            width: 270,
            sortable: true,
            defaultSortField: true,
            defaultSortAsc: false
        },
        {
            name: props.t("Action"),
            selector: row => row.action,
            sort: "asc",
            width: 200,
        }
    ];

    const getAllDistrict = (data) => {
        setLoading(true);
        DistrictApi.getAllDistricts(data)
            .then((res) => {
                setActiveData({
                    page: activeData.page,
                    totalPage: res?.data?.data?.count,
                    search: activeData.search,
                    limit: activeData.limit,
                });
                let data = [];
                var sr_no = res.data.sr_no_start;

                res?.data?.data?.rows?.forEach((v, i) => {
                    sr_no = sr_no + 1;
                    data[i] = {
                        district_id: sr_no,
                        name_en: v.name_en,
                        name_th: v.name_th,
                        status: v.status == 1 ? (
                            <>
                                <span style={{ color: "green" }}>Active</span>
                            </>
                        ) : (
                            <>
                                <span style={{ color: "red" }}>Deactive</span>
                            </>
                        ),
                        action: (
                            <>

                                <i className="fas fa-edit" id="deletetooltip" style={{ color: "blue" }} onClick={() => onEdit(v.id)} />{" "}
                                <i className="mdi mdi-delete font-size-18" style={{ color: "red" }} id="deletetooltip" onClick={() => onDelete(v.id)} />
                            </>
                        ),
                    };
                });
                setDistrictList(data);
                setLoading(false);
            })
            .catch((err) => {
                console.log(err);
            });

            DistrictApi.getAllProvince()
            .then((res) => {
                setProvinceList(res.data.data);
                setLoading(false);
            })
            .catch((err) => {
                console.log(err);
            });
    };


    const onDelete = (id) => {

        Swal.fire({
            title: props.t("Are you sure?"),
            text: props.t("You won't be able to revert this!"),
            icon: props.t("warning"),
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#f46a6a",
            confirmButtonText: props.t("Yes, delete it!"),
        }).then((result) => {
            if (result.isConfirmed) {
                let DistrictId = { "district_id": id };
                DistrictApi.deleteDistrict(DistrictId)
                    .then((res) => {
                        Swal.fire(props.t("Deleted!"), res.data.message, props.t("success"));
                        setDistrictId();
                        formClear()
                        getAllDistrict(activeData)
                    })
                    .catch((err) => {
                        console.log(err);
                    });
            }
        });
    };

    const onEdit = (id) => {
        let DistrictId = { "district_id": id };
        setDistrictId(id);
        DistrictApi.getDistrictById(DistrictId)
            .then((res) => {
                setFetchDistrict(res.data.data);
            })
            .catch((err) => {
                console.log(err);
            });
    };
    // Form validation 
    const validationType = useFormik({
        enableReinitialize: true,
        initialValues: {
            province_id: fetchDistrict ? fetchDistrict.province_id : "",
            district_id: fetchDistrict ? fetchDistrict.id : "",
            name_en: fetchDistrict ? fetchDistrict.name_en : "",
            name_th: fetchDistrict ? fetchDistrict.name_th : "",
            status: fetchDistrict?.status === 1 ? "1" : fetchDistrict?.status === 0 ? "0" : ""
        },
        validationSchema: Yup.object().shape({
            province_id: Yup.string().required(
                props.t("This value is required")
            ),
            name_en: Yup.string().required(
                props.t("This value is required")
            ),
            name_th: Yup.string().required(
                props.t("This value is required")
            ),
            status: Yup.string().required(
                props.t("This value is required")
            )
        }),
        onSubmit: (values) => {
            if (postDistrictId) {
                values.district_id = postDistrictId;
                DistrictApi.updateDistrict(values)
                    .then(res => {
                        if (res.data.success) {
                            Swal.fire({
                                text: res.data.message,
                                icon: 'success',
                                imageAlt: 'success image',
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    history.push('/districts');
                                    setDistrictId();
                                    formClear()
                                    getAllDistrict(activeData)
                                }
                            });
                        } else {
                            toastr.error(res.message, '');
                        }
                    }).catch(function (error) {
                        if (error?.response?.data?.message) {
                            toastr.error(error?.response?.data?.message, '');
                        }
                        else {
                            toastr.error(error?.response?.data?.error?.errors?.map((item, v) => `${item.msg}<br>`), '');
                        }
                    });
            }
            else {
                DistrictApi.createDistrict(values)
                    .then(res => {
                        if (res.data.success) {
                            Swal.fire({
                                text: res.data.message,
                                icon: 'success',
                                imageAlt: 'success image',
                            }).then((result) => {
                                if (result?.isConfirmed) {
                                    history.push('/districts');
                                    formClear()
                                    getAllDistrict(activeData)
                                }
                            });
                        } else {
                            toastr.error(res?.data?.message, '');
                        }
                    }).catch(function (error) {
                        if (error?.response?.data?.message) {
                            toastr.error(error?.response?.data?.message, '');
                        }
                        else {
                            toastr.error(error?.response?.data?.error?.errors?.map((item, v) => `${item.msg}<br>`), '');
                        }
                    });
            }

        }
    });

    const handleChange = (v) => {
        setActiveData({ page: v, totalPage: activeData.totalPage, search: activeData.search, limit: activeData.limit });
        const data = { page: v, totalPage: activeData.totalPage, search: activeData.search, limit: activeData.limit }
        getAllDistrict(data)
    }


    const handleRowChange = (v) => {
        setActiveData({ page: activeData.page, totalPage: activeData.totalPage, search: activeData.search, limit: v });
        const data = { page: activeData.page, totalPage: activeData.totalPage, search: activeData.search, limit: v }
        getAllDistrict(data)
    }


    //meta title
    document.title = props.t("District") + ' | ' + props.t("MedX");

    return (
        <div className="page-content">
            <div className="container-fluid">
                <Breadcrumbs title={props.t("Master")} breadcrumbItem={props.t("District")} />
            </div>
            <Container fluid={false}>
                <Row>
                    <Col lg={8}>
                        <Card>
                            <CardBody >
                                <Col sm={12}>
                                    <DataTable
                                        className="table-bordered"
                                        progressPending={loading}
                                        columns={columns}
                                        data={districtList}
                                        pagination
                                        paginationServer
                                        paginationTotalRows={activeData.totalPage}
                                        paginationPerPage={activeData.limit}
                                        defaultSortFieldID={1}
                                        onChangeRowsPerPage={value => handleRowChange(value)}
                                        onChangePage={value => handleChange(value)}
                                        sortable
                                        noHeader
                                        defaultSortField="id"
                                        defaultSortAsc={false}
                                        highlightOnHover
                                    />
                                </Col>

                            </CardBody>
                        </Card>
                    </Col>
                    <Col lg={4}>
                        <Card>
                            <CardBody >
                                <Col sm={12}>
                                    <Form
                                        onSubmit={(e) => {
                                            e.preventDefault();
                                            validationType.handleSubmit();
                                            return false;
                                        }}>
                                        <Col sm={12}>
                                            <div className="mb-3">
                                                <Label className="form-label">{props.t("Name (Eng)")}</Label>
                                                <Input
                                                    name="name_en"
                                                    placeholder={props.t("Name (Eng)")}
                                                    type="text"
                                                    onChange={validationType.handleChange}
                                                    onBlur={validationType.handleBlur}
                                                    value={validationType.values.name_en || ""}
                                                    invalid={
                                                        validationType.touched.name_en && validationType.errors.name_en ? true : false
                                                    }
                                                />
                                                {validationType.touched.name_en && validationType.errors.name_en ? (
                                                    <FormFeedback type="invalid">{validationType.errors.name_en}</FormFeedback>
                                                ) : null}
                                            </div>
                                        </Col>
                                        <Col sm={12}>
                                            <div className="mb-3">
                                                <Label className="form-label">{props.t("Name (Thai)")}</Label>
                                                <Input
                                                    name="name_th"
                                                    placeholder={props.t("Name (Thai)")}
                                                    type="text"
                                                    onChange={validationType.handleChange}
                                                    onBlur={validationType.handleBlur}
                                                    value={validationType.values.name_th || ""}
                                                    invalid={
                                                        validationType.touched.name_th && validationType.errors.name_th ? true : false
                                                    }
                                                />
                                                {validationType.touched.name_th && validationType.errors.name_th ? (
                                                    <FormFeedback type="invalid">{validationType.errors.name_th}</FormFeedback>
                                                ) : null}
                                            </div>
                                        </Col>

                                        <Col sm={12}>
                                            <div className="mb-3">
                                                <Label className="form-label">{props.t("Province")}</Label>

                                                <select
                                                    name="province_id"
                                                    type="select"
                                                    className="form-control"
                                                    onChange={validationType.handleChange}
                                                    onBlur={validationType.handleBlur}
                                                    value={validationType.values.province_id || ""}

                                                >
                                                    <option value="">{props.t("Please Select Province")}</option>
                                                    {
                                                        provinceList.map((item,i) => {
                                                            return (
                                                                <option value={item.id} key={i}>{item.name_en}</option>
                                                            )
                                                        })
                                                    }

                                                </select>
                                                {validationType.touched.province_id && validationType.errors.province_id ? (
                                                    <div style={{ color: '#f46a6a', fontSize: '11px', marginTop: '3px' }}>
                                                        {validationType.errors.province_id}
                                                    </div>
                                                ) : null}
                                            </div>
                                        </Col>

                                        <Col sm={12}>
                                            <div className="mb-3">
                                                <Label className="form-label">{props.t("Status")}</Label>

                                                <select
                                                    name="status"
                                                    type="select"
                                                    className="form-control"
                                                    onChange={validationType.handleChange}
                                                    onBlur={validationType.handleBlur}
                                                    value={validationType.values.status || ""}

                                                >
                                                    <option value="">{props.t("Please Select Status")}</option>
                                                    {
                                                        Object.keys(constants.STATUS).map(key => {
                                                            return (
                                                                <option value={key} key={key}>{constants.STATUS[key]}</option>
                                                            )
                                                        })
                                                    }

                                                </select>
                                                {validationType.touched.status && validationType.errors.status ? (
                                                    <div style={{ color: '#f46a6a', fontSize: '11px', marginTop: '3px' }}>
                                                        {validationType.errors.status}
                                                    </div>
                                                ) : null}
                                            </div>
                                        </Col>


                                        <div className="d-flex flex-wrap gap-2">
                                            <Button type="submit" color="primary" >
                                                {props.t("Submit")}
                                            </Button>{" "}
                                            <Button color="secondary" onClick={e => formClear()}>
                                                {props.t("Clear")}
                                            </Button>
                                        </div>
                                    </Form>
                                </Col>

                            </CardBody>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </div>
    );
}
District.propTypes = {
    t: PropTypes.any,
    preGlobalFilteredRows: PropTypes.any,

};
export default withTranslation()(District);