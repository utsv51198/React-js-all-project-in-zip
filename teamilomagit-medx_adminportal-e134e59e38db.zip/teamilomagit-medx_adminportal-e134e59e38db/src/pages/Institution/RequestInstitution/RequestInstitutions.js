// src/components/filter.
import React, { useMemo, useEffect,useState } from "react";
import PropTypes from 'prop-types';

//import components
import Breadcrumbs from '../../../components/Common/Breadcrumb';
import TableContainer from '../../../components/Common/TableContainer';
import DataTable from 'react-data-table-component';
import { RequestInstitutionApi } from "../../../apis/RequestInstitutionApi";
import { useHistory } from "react-router-dom"


import { Link } from "react-router-dom";
import {
    Button,
    DropdownToggle,
    DropdownMenu,
    DropdownItem,
    ButtonDropdown,
  } from "reactstrap";

import Swal from "sweetalert2";

import { withTranslation } from "react-i18next";

import i18n from "../../../i18n";


function RequestInstitutions(props){
  

    const history = useHistory();
    const [roles, setRoles] = useState([]);
    const [loading, setLoading] = useState(false);
    const [activeData, setActiveData] = useState({
        activePage: 1,
        totalPage: 1,
        search: "",
        limit: 10,
    });

    useEffect(() => {
        getAllRequestInstitutions(activeData);
    }, []);
    
    const columns = [
        {
          name: props.t("ID"),
          selector: row => row.id,
          sort: "asc",
          width: 20,
          sortable: true,
          defaultSortField: true,
          defaultSortAsc: false
        },
        {
          name:props.t("Institution Name"),
          selector: row => row.insitution_name,
          sort: "asc",
          width: 270,
          sortable: true,
          defaultSortField: true,
          defaultSortAsc: false
        },
        {
            name:props.t("Affiliation"),
            selector: row => row.affiliation,
            sort: "asc",
            width: 270,
            sortable: true,
            defaultSortField: true,
            defaultSortAsc: false
        },
        {
          name:props.t("Insitution Address"),
          selector: row => row.insitution_address,
          sort: "asc",
          width: 270,
          sortable: true,
          defaultSortField: true,
          defaultSortAsc: false
        },
        {
          name:props.t("Established Year"),
          selector: row => row.established_year,
          sort: "asc",
          width: 270,
          sortable: true,
          defaultSortField: true,
          defaultSortAsc: false
        },
        {
          name:props.t("Status"),
          selector: row => row.status,
          sort: "asc",
          width: 270,
          sortable: true,
          defaultSortField: true,
          defaultSortAsc: false
        },
        {
          name:props.t("View"),
          selector: row => row.action,
          sort: "asc",
          width: 200,
        }
      ];


    
    const getAllRequestInstitutions = (data) => {
        setLoading(true);
        RequestInstitutionApi.getAllRequestInstitutions(data)
          .then((res) => {
           
           
            setActiveData({
              activePage: activeData.activePage,
              totalPage: res.data.requestinstitute.count,
              search: activeData.search,
              limit: activeData.limit,
            });
            let data = [];
            res.data.requestinstitute.rows.forEach((v, i) => {
              data[i] = {
                id: v.id,
                insitution_name: v.insitution_name,
                affiliation: v.affiliation,
                insitution_address: v.insitution_address,
                established_year: v.established_year,
                status: v.status,
                action: (
                  <>
                    <Link
                      to={`/view-request-institute/${v.id}`}
                    >
                        <Button
                        type="button"
                        color="primary"
                        className="btn-sm btn-rounded"
                        >
                        {props.t("View Details")}
                        </Button>
                    </Link>
                  </>
                ),
              };
            });
            setRoles(data);
            setLoading(false);


          })
          .catch((err) => {
            console.log(err);
          });
      };


    const handleChange = (v) => {
    setActiveData({ activePage: v, totalPage: activeData.totalPage, search: activeData.search, limit: activeData.limit });
    const data = { activePage: v, totalPage: activeData.totalPage, search: activeData.search, limit: activeData.limit }
    getAllRoles(data)
    }


    const handleRowChange = (v) => {
    setActiveData({ activePage: activeData.activePage, totalPage: activeData.totalPage, search: activeData.search, limit: v });
    const data = { activePage: activeData.activePage, totalPage: activeData.totalPage, search: activeData.search, limit: v }
    getAllRoles(data)
    }


     //meta title
    document.title = props.t("Request Institution")+' | '+props.t("MedX");

    return (
        <div className="page-content">
            <div className="container-fluid">
            <Breadcrumbs title={props.t("Institution")} breadcrumbItem={props.t("Request Institutions")} />
            </div>

            

            <div className="container-fluid">
                    <DataTable
                      className="table-bordered"
                      progressPending={loading}
                      columns={columns}
                      data={roles}
                      pagination
                      paginationServer
                      paginationTotalRows={activeData.totalPage}
                      paginationPerPage={activeData.limit}
                      defaultSortFieldID={1}
                      onChangeRowsPerPage={value => handleRowChange(value)}
                      onChangePage={value => handleChange(value)}
                      sortable
                      noHeader
                      defaultSortField="id"
                      defaultSortAsc={false}
                      highlightOnHover
                    />
            </div>
        </div>
    );
}

RequestInstitutions.propTypes = {
  t: PropTypes.any,
  preGlobalFilteredRows: PropTypes.any,
};

export default withTranslation()(RequestInstitutions);