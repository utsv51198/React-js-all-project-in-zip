// src/components/filter.
import React, { useMemo, useEffect,useState } from "react";
import PropTypes from 'prop-types';

//import components
import Breadcrumbs from '../../../components/Common/Breadcrumb';
import TableContainer from '../../../components/Common/TableContainer';
import DataTable from 'react-data-table-component';
import { RequestInstitutionApi } from "../../../apis/RequestInstitutionApi";
import { InstitutionApi } from "../../../apis/InstitutionApi";

import { useHistory } from "react-router-dom"
import * as Yup from "yup";
import { useFormik } from "formik";


import { Link } from "react-router-dom";
import {
    Card,
    Col,
    Container,
    Row,
    CardBody,
    CardTitle,
    Label,
    Button,
    Form,
    Input,
    InputGroup,
    TabContent,
  Table,
  TabPane,
  FormFeedback,

  } from "reactstrap";
import Swal from "sweetalert2";
import toastr from "toastr";
import "toastr/build/toastr.min.css";
import { withTranslation } from "react-i18next";

import i18n from "../../../i18n";



function RequestInstitutions(props) {

    const history = useHistory();
    const request_institute_id = props.match.params.request_institute_id;
    const [institutionData, setInstitutionData] = useState({});
    useEffect(() => {
        getRequestInstitution();
    }, []);
    
    const getRequestInstitution = () => {
        let data = {request_institute_id:request_institute_id};
        RequestInstitutionApi.getRequestInstitution(data)
          .then((res) => {
            setInstitutionData(res.data.requestinstitute);
          })
          .catch((err) => {
            console.log(err);
          });
    };

    const validation = useFormik({
      // enableReinitialize : use this flag when initial values needs to be changed
      enableReinitialize: true,
  
      initialValues: {
        comment: institutionData.comment || '',
        status: institutionData.status || ''
      },
      validationSchema: Yup.object({
        status: Yup.string().required(props.t("Please Select Status")),
      }),
      onSubmit: (values) => {
        values.request_institute_id =  request_institute_id;
        InstitutionApi.createInstitute(values)
        .then(res => {
          if (res.data.success) {
                    Swal.fire({
                      text: res.data.message,
                      icon: 'success',
                      imageAlt: 'success image',
                      // confirmButtonColor: '#00CA84'
                    }).then((result) => {
                      if (result.isConfirmed) {
                        history.push('/view-request-institute/'+request_institute_id);
                      }
                    });
            } else {
                toastr.error(res.message, '');
            }
            
        }).catch(function (error) {
        toastr.error(error.response.data.message, '');
        });
      }
    });
  
    //meta title
    document.title = props.t("Request Institution Details")+' | '+props.t("MedX")
    

    return (
        <div className="page-content">
            <div className="container-fluid">
            <Breadcrumbs title={props.t("Institution")} breadcrumbItem={props.t("Request Institution Details")} />
            </div>

            

            <div className="container-fluid">

            <Row>
            <Col lg={6}>
              <Card>
                <CardBody>
                <div className="table-responsive">
                        <Table className="table mb-0 table-bordered">
                          <tbody>
                            
                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Institution Name")}</th>
                                  <td>{institutionData.insitution_name ? institutionData.insitution_name : "-"}</td>
                                </tr>

                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Affiliation")}</th>
                                  <td>{institutionData.affiliation ? institutionData.affiliation : "-"}</td>
                                </tr>


                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Insitution Address")}</th>
                                  <td>{institutionData.insitution_address ? institutionData.insitution_address : "-"}</td>
                                </tr>

                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Province")}</th>
                                  <td>{institutionData.Province ? institutionData.Province.name_en : "-"}</td>
                                </tr>

                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("District")}</th>
                                  <td>{institutionData.District ? institutionData.District.name_en : "-"}</td>
                                </tr>

                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Sub District")}</th>
                                  <td>{institutionData.SubDistrict ? institutionData.SubDistrict.name_en : "-"}</td>
                                </tr>

                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Post Code")}</th>
                                  <td>{institutionData.post_code ? institutionData.post_code : "-"}</td>
                                </tr>

                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Phone")}</th>
                                  <td>{institutionData.phone ? institutionData.phone : "-"}</td>
                                </tr>

                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Email")}</th>
                                  <td>{institutionData.email ? institutionData.email : "-"}</td>
                                </tr>

                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Website")}</th>
                                  <td>{institutionData.website ? institutionData.website : "-"}</td>
                                </tr>

                                 <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Organization")}</th>
                                  <td>{institutionData.OrganizationType ? institutionData.OrganizationType.name_en : "-"}</td>
                                </tr>

                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Established Year")}</th>
                                  <td>{institutionData.established_year ? institutionData.established_year : "-"}</td>
                                </tr>

                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Number of Members")}</th>
                                  <td>{institutionData.number_of_members ? institutionData.number_of_members : "-"}</td>
                                </tr>

                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Education")}</th>
                                  <td>{institutionData.EducationType ? institutionData.EducationType.name_en : "-"}</td>
                                </tr>

                               


                                
                             
                          </tbody>
                        </Table>
                      </div>
                </CardBody>
              </Card>
            </Col>

            <Col lg={6}>
              <Card>
                <CardBody>
                   <div className="table-responsive">
                        <Table className="table mb-0 table-bordered">
                          <tbody>

                          <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Education No of Medical")}</th>
                                  <td>{institutionData.education_number_of_medical_with ? institutionData.education_number_of_medical_with : "-"}</td>
                                </tr>

                          <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Education Number of Beds")}</th>
                                  <td>{institutionData.education_number_of_beds ? institutionData.education_number_of_beds : "-"}</td>
                                </tr>
                            
                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Service")}</th>
                                  <td>{institutionData.ServiceType ? institutionData.ServiceType.name_en : "-"}</td>
                                </tr>

                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Service Number of Medical")}</th>
                                  <td>{institutionData.service_numbet_of_medical_with ? institutionData.service_numbet_of_medical_with : "-"}</td>
                                </tr>

                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Service Number of Beds")}</th>
                                  <td>{institutionData.service_number_of_beds ? institutionData.service_number_of_beds : "-"}</td>
                                </tr>

                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Service")}</th>
                                  <td>{institutionData.service_id ? institutionData.service_id : "-"}</td>
                                </tr>


                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Name Title")}</th>
                                  <td>{institutionData.contact_name_title ? institutionData.contact_name_title : "-"}</td>
                                </tr>

                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("First Name")}</th>
                                  <td>{institutionData.contact_first_name ? institutionData.contact_first_name : "-"}</td>
                                </tr>

                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Last Name")}</th>
                                  <td>{institutionData.contact_last_name ? institutionData.contact_last_name : "-"}</td>
                                </tr>

                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Organization Position")}</th>
                                  <td>{institutionData.organization_position ? institutionData.organization_position : "-"}</td>
                                </tr>


                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Contact Phone")}</th>
                                  <td>{institutionData.contact_phone ? institutionData.contact_phone : "-"}</td>
                                </tr>

                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Contact Email")}</th>
                                  <td>{institutionData.contact_email ? institutionData.contact_email : "-"}</td>
                                </tr>

                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Contact Webite")}</th>
                                  <td>{institutionData.contact_website ? institutionData.contact_website : "-"}</td>
                                </tr>

                                <tr>
                                  <th scope="row" className={"text-capitalize"}>{props.t("Contact Network Affiliated")}</th>
                                  <td>{institutionData.network_with_affiliated_institutions ? institutionData.network_with_affiliated_institutions : "-"}</td>
                                </tr>
                             
                          </tbody>
                        </Table>
                      </div>
                </CardBody>
              </Card>
            </Col>
          </Row>

          <Row>
            <Col lg={12}>
              <Card>
                <CardBody>
                  <CardTitle className="mb-4">{props.t("Update Request Insitution Status")}</CardTitle>

                  <Form
                    className="form-horizontal"
                    onSubmit={(e) => {
                      e.preventDefault();
                      validation.handleSubmit();
                      return false;
                    }}
                  > 
                   
                    <Row>
                      <Col md={6}>
                        <div className="mb-3">
                          <Label htmlFor="formrow-email-Input">{props.t("Status")}</Label>
                          <select 
                            onChange={validation.handleChange}
                            onBlur={validation.handleBlur}
                            value={validation.values.status || ""}
                            invalid={
                              validation.touched.status && validation.errors.status ? true : false
                            }  className="form-select">
                            <option value="0">{props.t("Select Status")}</option>
                            <option value="APPROVED" >{props.t("APPROVED")}</option>
                            <option value="PENDING">{props.t("PENDING")}</option>
                            <option value="REJECTED">{props.t("REJECTED")}</option>
                        </select>
                        {validation.touched.status && validation.errors.status ? (
                        <FormFeedback type="invalid">{validation.errors.status}</FormFeedback>
                      ) : null}
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col md={6}>
                        <div className="mb-3">
                          <Label htmlFor="formrow-email-Input">{props.t("Comment")}</Label>
                          <Input
                          name="comment"
                          type="textarea"
                          className="form-control"
                          id="horizontal-firstname-Input"
                          placeholder="Enter Comment"
                          maxLength="225"
                          rows="3"
                          onChange={validation.handleChange}
                          onBlur={validation.handleBlur}
                          value={validation.values.comment || ""}
                          invalid={
                            validation.touched.comment && validation.errors.comment ? true : false
                          }
                         />
                        </div>
                      </Col>
                    </Row>

                    <div>
                      <button type="submit" className="btn btn-primary w-md">
                        {props.t("Submit")}
                      </button>
                    </div>
                  </Form>
                </CardBody>
              </Card>
            </Col>

            
          </Row>


                   
            </div>
        </div>
    );
}
RequestInstitutions.propTypes = {
  t: PropTypes.any,
  preGlobalFilteredRows: PropTypes.any,
};

export default withTranslation()(RequestInstitutions);