/** Get Dashboard saas Top selling data */

export const API_SUCCESS = "API_SUCCESS";
export const API_FAIL = "API_FAIL";
export const GET_TOP_SELLING_PRODUCT = "GET_TOP_SELLING_PRODUCT";
export const GET_EARNING_DATA = "GET_EARNING_DATA";