import usFlag from "../assets/images/flags/us.jpg"
import thFlag from "../assets/images/flags/th.png"

const languages = {
  en: {
    label: "English",
    flag: usFlag,
  },
  th: {
    label: "Thai",
    flag: thFlag,
  },
}

export default languages
