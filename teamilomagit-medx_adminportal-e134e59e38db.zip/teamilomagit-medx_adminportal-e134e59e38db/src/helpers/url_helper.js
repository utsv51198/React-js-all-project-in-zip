// LOGIN
export const POST_ADMIN_LOGIN = "/api/admin/login";


// PROFILE
export const POST_CREATE_ROLE = "/api/admin/create-role";
export const POST_UPDATE_ROLE = "/api/admin/update-role";
export const POST_FETCH_ROLE = "/api/admin/fetch-role";
export const POST_FETCH_ALL_ROLES = "/api/admin/fetch-roles";

// System Setting
export const POST_FETCH_SYSTEM_SETTINGS = "/api/admin/fetch-system-setting";
export const POST_UPDATE_SYSTEM_SETTINGS = "/api/admin/update-system-setting";


export const POST_FETCH_REQUEST_INSTITUTIONS = "/api/admin/fetch-request-institutes";
export const POST_FETCH_REQUEST_SUB_INSTITUTIONS = "/api/admin/fetch-request-sub-institutes";
export const POST_FETCH_REQUEST_INSTITUTION_BY_ID = "/api/admin/fetch-request-institute-details";


//profile
export const POST_UPDATE_USER_LANGUAGE = "/api/admin/update-user-language";
export const POST_UPDATE_USER_PROFILE = "/api/admin/update-profile";
export const POST_UPDATE_USER_PASSWORD = "/api/admin/change-password";


//INSTITUTIONS
export const POST_CREATE_INSTITUTIONS = "/api/admin/create-institute";



//Role
export const POST_FETCH_MODULES = "/api/admin/fetch-all-modules";

//REGISTER
export const POST_FAKE_REGISTER = "/post-fake-register";
 
//LOGIN
export const POST_FAKE_LOGIN = "/post-fake-login";
export const POST_FAKE_JWT_LOGIN = "/post-jwt-login";
export const POST_FAKE_PASSWORD_FORGET = "/fake-forget-pwd";
export const POST_FAKE_JWT_PASSWORD_FORGET = "/jwt-forget-pwd";
export const SOCIAL_LOGIN = "/social-login";

//PROFILE
export const POST_EDIT_JWT_PROFILE = "/post-jwt-profile";
export const POST_EDIT_PROFILE = "/post-fake-profile";

//PRODUCTS
export const GET_PRODUCTS = "/products";
export const GET_PRODUCTS_DETAIL = "/product";

//Mails
export const GET_INBOX_MAILS = "/inboxmails";
export const ADD_NEW_INBOX_MAIL = "/add/inboxmail";
export const DELETE_INBOX_MAIL = "/delete/inboxmail";

//starred mail
export const GET_STARRED_MAILS = "/starredmails";

//important mails
export const GET_IMPORTANT_MAILS = "/importantmails";

//Draft mail
export const GET_DRAFT_MAILS = "/draftmails";

//Send mail
export const GET_SENT_MAILS = "/sentmails";

//Trash mail
export const GET_TRASH_MAILS = "/trashmails";

//CALENDER
export const GET_EVENTS = "/events";
export const ADD_NEW_EVENT = "/add/event";
export const UPDATE_EVENT = "/update/event";
export const DELETE_EVENT = "/delete/event";
export const GET_CATEGORIES = "/categories";

//CHATS
export const GET_CHATS = "/chats";
export const GET_GROUPS = "/groups";
export const GET_CONTACTS = "/contacts";
export const GET_MESSAGES = "/messages";
export const ADD_MESSAGE = "/add/messages";

//ORDERS
export const GET_ORDERS = "/orders";
export const ADD_NEW_ORDER = "/add/order";
export const UPDATE_ORDER = "/update/order";
export const DELETE_ORDER = "/delete/order";

//CART DATA
export const GET_CART_DATA = "/cart";

//CUSTOMERS
export const GET_CUSTOMERS = "/customers";
export const ADD_NEW_CUSTOMER = "/add/customer";
export const UPDATE_CUSTOMER = "/update/customer";
export const DELETE_CUSTOMER = "/delete/customer";

//SHOPS
export const GET_SHOPS = "/shops";

//CRYPTO
export const GET_WALLET = "/wallet";
export const GET_CRYPTO_ORDERS = "/crypto/orders";

//INVOICES
export const GET_INVOICES = "/invoices";
export const GET_INVOICE_DETAIL = "/invoice";

//PROJECTS
export const GET_PROJECTS = "/projects";
export const GET_PROJECT_DETAIL = "/project";
export const ADD_NEW_PROJECT = "/add/project";
export const UPDATE_PROJECT = "/update/project";
export const DELETE_PROJECT = "/delete/project";

//TASKS
export const GET_TASKS = "/tasks";

//CONTACTS
export const GET_USERS = "/users";
export const GET_USER_PROFILE = "/user";
export const ADD_NEW_USER = "/add/user";
export const UPDATE_USER = "/update/user";
export const DELETE_USER = "/delete/user";

//INTERESTS
export const POST_FETCH_ALL_INTERESTS = "/api/admin/fetch-interests";
export const POST_CREATE_INTEREST = "/api/admin/create-interest";
export const POST_FETCH_INTEREST = "/api/admin/fetch-interest";
export const POST_UPDATE_INTEREST = "/api/admin/update-interest";
export const POST_DELETE_INTEREST = "/api/admin/delete-interest";

//ORGANIZATIONTYPES
export const POST_FETCH_ALL_ORGANIZATIONTYPES = "/api/admin/fetch-organization-types";
export const POST_CREATE_ORGANIZATIONTYPE = "/api/admin/create-organization-type";
export const POST_FETCH_ORGANIZATIONTYPE = "/api/admin/fetch-organization-type";
export const POST_UPDATE_ORGANIZATIONTYPE = "/api/admin/update-organization-type";
export const POST_DELETE_ORGANIZATIONTYPE = "/api/admin/delete-organization-type";

//SERVICETYPES
export const POST_FETCH_ALL_SERVICETYPES = "/api/admin/fetch-service-types";
export const POST_CREATE_SERVICETYPE = "/api/admin/create-service-type";
export const POST_FETCH_SERVICETYPE = "/api/admin/fetch-service-type";
export const POST_UPDATE_SERVICETYPE = "/api/admin/update-service-type";
export const POST_DELETE_SERVICETYPE = "/api/admin/delete-service-type";

//PROVINCES
export const POST_FETCH_ALL_PROVINCES = "/api/admin/fetch-provinces";
export const POST_CREATE_PROVINCE = "/api/admin/create-province";
export const POST_FETCH_PROVINCE = "/api/admin/fetch-province";
export const POST_UPDATE_PROVINCE = "/api/admin/update-province";
export const POST_DELETE_PROVINCE = "/api/admin/delete-province";

//DISTRICTS
export const POST_FETCH_ALL_DISTRICTS = "/api/admin/fetch-districts";
export const POST_CREATE_DISTRICT = "/api/admin/create-district";
export const POST_FETCH_DISTRICT = "/api/admin/fetch-district";
export const POST_UPDATE_DISTRICT = "/api/admin/update-district";
export const POST_DELETE_DISTRICT = "/api/admin/delete-district";
export const POST_FETCH_ALL_COMMON_PROVINCES = "/api/common/fetch-province"; // COMMON PROVINCES

//SUBDISTRICTS
export const POST_FETCH_ALL_SUBDISTRICTS = "/api/admin/fetch-sub-districts";
export const POST_CREATE_SUBDISTRICT = "/api/admin/create-sub-district";
export const POST_FETCH_SUBDISTRICT = "/api/admin/fetch-sub-district";
export const POST_UPDATE_SUBDISTRICT = "/api/admin/update-sub-district";
export const POST_DELETE_SUBDISTRICT = "/api/admin/delete-sub-district";
export const POST_FETCH_ALL_COMMON_DISTRICTS = "/api/common/fetch-district"; // COMMON DISTRICTS

//CATEGORIES
export const POST_FETCH_ALL_CATEGORIES = "/api/admin/fetch-categories";
export const POST_CREATE_CATEGORY = "/api/admin/create-category";
export const POST_FETCH_CATEGORY = "/api/admin/fetch-category";
export const POST_UPDATE_CATEGORY = "/api/admin/update-category";
export const POST_DELETE_CATEGORY = "/api/admin/delete-category";

//BANNERS
export const POST_FETCH_ALL_BANNERS = "/api/admin/fetch-banners";
export const POST_CREATE_BANNER = "/api/admin/create-banner";
export const POST_FETCH_BANNER = "/api/admin/fetch-banner";
export const POST_UPDATE_BANNER = "/api/admin/update-banner";
export const POST_DELETE_BANNER = "/api/admin/delete-banner";

//OFFERTYPES
export const POST_FETCH_ALL_OFFERTYPES = "/api/admin/fetch-offer-types";
export const POST_CREATE_OFFERTYPE = "/api/admin/create-offer-type";
export const POST_FETCH_OFFERTYPE = "/api/admin/fetch-offer-type";
export const POST_UPDATE_OFFERTYPE = "/api/admin/update-offer-type";
export const POST_DELETE_OFFERTYPE = "/api/admin/delete-offer-type";

//dashboard charts data
export const GET_WEEKLY_DATA = "/weekly-data";
export const GET_YEARLY_DATA = "/yearly-data";
export const GET_MONTHLY_DATA = "/monthly-data";

export const TOP_SELLING_DATA = "/top-selling-data";

export const GET_EARNING_DATA = "/earning-charts-data";

export const GET_PRODUCT_COMMENTS = "/comments-product";

export const ON_LIKNE_COMMENT = "/comments-product-action";

export const ON_ADD_REPLY = "/comments-product-add-reply";

export const ON_ADD_COMMENT = "/comments-product-add-comment";
