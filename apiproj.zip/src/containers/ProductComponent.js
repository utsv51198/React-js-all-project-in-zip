import React from "react";
import { useSelector } from "react-redux/es/exports";
import { Link } from "react-router-dom";

const ProductComponent = () => {
  const products = useSelector((state) => state.allProducts.products);
  const renderList = products.map((product) => {
    const { id, title, image, price, category } = product;
    return (
      <div className="my-4 card col-md-4" style={{ width: "18rem" }} key={id}>
        <Link to={`/product/${id}`}>
          <img src={image} className="card-img-top" alt={title} />
          <div className="card-body">
            <h5 className="card-title">{title}</h5>
            <p className="card-text">{category}</p>
            <p className="card-text">$ {price}</p>
          </div>
        </Link>
      </div>
    );
  });
  return <>{renderList}</>;
};

export default ProductComponent;
