import './App.css';
import { FormCreate } from './components/FormCreate';

function App() {
  return (
    <div className="App">
       <FormCreate/>
    </div>
  );
}

export default App;
