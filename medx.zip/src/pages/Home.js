import React from "react";
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import Navbar from "./Navbar";
import Footer from "./Footer";
import upevent1 from "../assets/images/right-arrow.png";

function Home() {
    return (
        <div>
            <Navbar />

            {/* Mobile View Top Start */}
            <div className="mobile-top d-none">
                <div className="container">
                    <div className="row">
                        <div className="d-flex align-items-center justify-content-between">
                            <div>
                                <h4>What's New</h4>
                            </div>
                            <div>
                                <ul className="d-flex align-items-center justify-content-between">
                                    <li>
                                        <a href=""><img src="assets/images/768/bell.png" className="" alt="" width="" height="" /></a>
                                    </li>
                                    <li>
                                        <a href="profile.html"><img src="assets/images/Ellipse 83.png" className="img-rounded" alt="" width="50" height="" /></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* Mobile View Top End */}

            {/* Mobile Bottom Menu Start */}
            <div className="d-none mob-menu bg-white">
                <ul className="d-flex align-items-center justify-content-between">
                    <li>
                        <a href="index.html">
                            <img src="assets/images/768/icon1.png" className="active" width="" height="" />
                        </a>
                    </li>
                    <li>
                        <a href="education.html">
                            <img src="assets/images/768/icon2.png" className="" width="" height="" />
                        </a>
                    </li>
                    <li>
                        <a href="community.html">
                            <img src="assets/images/768/icon3.png" className="" width="" height="" />
                        </a>
                    </li>
                    <li>
                        <a href="offer.html">
                            <img src="assets/images/768/icon4.png" className="" width="" height="" />
                        </a>
                    </li>
                    <li>
                        <a href="medx.html">
                            <img src="assets/images/768/icon5.png" className="" width="" height="" />
                        </a>
                    </li>
                </ul>
            </div>
            {/* Mobile Bottom Menu End */}

            {/* Carousel Start  */}
            <section className="mt-5 top-curve">
                <div className="container p-0 carousel-p">
                    <div className="row">
                        <div id="demo" className="carousel slide" data-bs-ride="carousel">

                            <div className="carousel-indicators">
                                <button type="button" data-bs-target="#demo" data-bs-slide-to="0" className="active"></button>
                                <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
                                <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
                                <button type="button" data-bs-target="#demo" data-bs-slide-to="3"></button>
                            </div>

                            <div className="carousel-inner">
                                <div className="carousel-item active">
                                    <img className="w-100 d-m-none" src="assets/images/banner.png" alt="Image" />
                                    <img className="w-100 d-none" src="assets/images/768/image 109.png" alt="Image" />
                                </div>
                                <div className="carousel-item">
                                    <img className="w-100 d-m-none" src="assets/images/banner.png" alt="Image" />
                                    <img className="w-100 d-none" src="assets/images/768/image 17.png" alt="Image" />
                                </div>
                                <div className="carousel-item">
                                    <img className="w-100 d-m-none" src="assets/images/banner.png" alt="Image" />
                                    <img className="w-100 d-none" src="assets/images/768/image 109.png" alt="Image" />
                                </div>
                                <div className="carousel-item">
                                    <img className="w-100 d-m-none" src="assets/images/banner.png" alt="Image" />
                                    <img className="w-100 d-none" src="assets/images/768/image 17.png" alt="Image" />
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </section>
            {/* Carousel End  */}

            {/* My Score Start */}
            <section className="d-none py-3">
                <div className="container">
                    <div className="row">
                        <div className="col-md-12 m-px-20">
                            <div className="d-flex align-items-center justify-content-between myscore1 mb-3">
                                <div>
                                    <h4 className="m-0">My Score</h4>
                                    <p>Total score (2017-2022)</p>
                                    <div className="progress">
                                        <div className="progress-bar progress-primary" role="progressbar"
                                            style={{ width: "75%" }} aria-valuenow="15" aria-valuemin="0"
                                            aria-valuemax="100"></div>
                                    </div>
                                </div>
                                <div>
                                    <button className="btn btn-credit bg-primary text-left">
                                        <h5>200.50</h5>
                                        <span>Credit</span>
                                    </button>
                                </div>
                            </div>
                            <div className="d-flex align-items-center justify-content-between myscore1">
                                <div>
                                    <h4 className="m-0">My Token</h4>
                                    <p>Total token (2017-2022)</p>

                                </div>
                                <div>
                                    <button className="btn btn-credit bg-secondary text-left">
                                        <h5>1,695</h5>
                                        <span className="text-white">Token</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            {/* My Score End */}

            {/* Upcoming Events Start */}
            <section className="section-m py-3">
                <div className="container p-0">
                    <div className="row">
                        <div className="col-md-12 px-30 d-m-flex">
                            <h2 className="title">Upcoming Events</h2>
                            <div className="d-flex justify-content-between align-items-center">
                                <div className="subtitle">Come See What's Happening </div>
                                <div>
                                    <a href="cme-events.html" className="view-text"><span className="view-m">View More</span><span className="see-m">See
                                        All</span> <img src={upevent1} alt="icon" width="18"
                                            height="18" className="ml-2" /></a>
                                </div>
                            </div>
                        </div>

                        <OwlCarousel items={6} autoplay={false} className="owl-carousel events-carousel mt-4 px-20">
                            <div className="event-item text-center">
                                <div className="position-relative main-img mb-2">
                                    <a href="">
                                        <img className="img-fluid mx-auto" src="assets/images/image 15.png" alt="" /></a>
                                    <span>5 Credits</span>
                                    <div className="timer">
                                        <div className="hours"></div>
                                        <div className="minutes"></div>
                                        <div className="seconds"></div>
                                    </div>
                                </div>
                                <a href=""><h4>Doctors without Borders</h4></a>
                                <ul className="event-list">
                                    <li>
                                        <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>16 Sep 2022</div>
                                    </li>
                                    <li>
                                        <div><img className="img-fluid " src="assets/images/location-marker.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>Online</div>
                                    </li>
                                </ul>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img mb-2">
                                    <a href=""><img className="img-fluid mx-auto" src="assets/images/image 13.png" alt="" /></a>
                                    <span>5 Credits</span>
                                </div>
                                <a href=""><h4>Dental Implants specialists in ...</h4></a>
                                <ul className="event-list">
                                    <li>
                                        <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>16 Sep 2022</div>
                                    </li>
                                    <li>
                                        <div><img className="img-fluid " src="assets/images/location-marker.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>Bangkok Marriott Hotel...</div>
                                    </li>
                                </ul>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img mb-2">
                                    <a href=""><img className="img-fluid mx-auto" src="assets/images/image 16.png" alt="" /></a>
                                    <span>5 Credits</span>
                                </div>
                                <a href=""><h4>Golden Week</h4></a>
                                <ul className="event-list">
                                    <li>
                                        <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>16 Sep 2022</div>
                                    </li>
                                    <li>
                                        <div><img className="img-fluid " src="assets/images/location-marker.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>Bangkok Marriott Hotel...</div>
                                    </li>
                                </ul>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img mb-2">
                                    <a href=""><img className="img-fluid mx-auto" src="assets/images/image 15.png" alt="" /></a>
                                    <span>5 Credits</span>
                                    <div className="timer">
                                        <div className="hours"></div>
                                        <div className="minutes"></div>
                                        <div className="seconds"></div>
                                    </div>
                                </div>
                                <a href=""><h4>Doctors without Borders</h4></a>
                                <ul className="event-list">
                                    <li>
                                        <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>16 Sep 2022</div>
                                    </li>
                                    <li>
                                        <div><img className="img-fluid " src="assets/images/location-marker.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>Online</div>
                                    </li>
                                </ul>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img mb-2">
                                    <a href=""><img className="img-fluid mx-auto" src="assets/images/image 13.png" alt="" /></a>
                                    <span>5 Credits</span>
                                </div>
                                <a href=""><h4>Dental Implants specialists in ...</h4></a>
                                <ul className="event-list">
                                    <li>
                                        <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>16 Sep 2022</div>
                                    </li>
                                    <li>
                                        <div><img className="img-fluid " src="assets/images/location-marker.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>Bangkok Marriott Hotel...</div>
                                    </li>
                                </ul>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img mb-2">
                                    <a href=""><img className="img-fluid mx-auto" src="assets/images/image 16.png" alt="" /></a>
                                    <span>5 Credits</span>
                                </div>
                                <a href=""><h4>Golden Week</h4></a>
                                <ul className="event-list">
                                    <li>
                                        <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>16 Sep 2022</div>
                                    </li>
                                    <li>
                                        <div><img className="img-fluid " src="assets/images/location-marker.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>Bangkok Marriott Hotel...</div>
                                    </li>
                                </ul>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img mb-2">
                                    <a href=""><img className="img-fluid mx-auto" src="assets/images/image 15.png" alt="" /></a>
                                    <span>5 Credits</span>
                                    <div className="timer">
                                        <div className="hours"></div>
                                        <div className="minutes"></div>
                                        <div className="seconds"></div>
                                    </div>
                                </div>
                                <a href=""><h4>Doctors without Borders</h4></a>
                                <ul className="event-list">
                                    <li>
                                        <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>16 Sep 2022</div>
                                    </li>
                                    <li>
                                        <div><img className="img-fluid " src="assets/images/location-marker.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>Online</div>
                                    </li>
                                </ul>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img mb-2">
                                    <a href=""><img className="img-fluid mx-auto" src="assets/images/image 13.png" alt="" /></a>
                                    <span>5 Credits</span>
                                </div>
                                <a href=""><h4>Dental Implants specialists in ...</h4></a>
                                <ul className="event-list">
                                    <li>
                                        <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>16 Sep 2022</div>
                                    </li>
                                    <li>
                                        <div><img className="img-fluid " src="assets/images/location-marker.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>Bangkok Marriott Hotel...</div>
                                    </li>
                                </ul>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img mb-2">
                                    <a href=""><img className="img-fluid mx-auto" src="assets/images/image 16.png" alt="" /></a>
                                    <span>5 Credits</span>
                                </div>
                                <a href=""><h4>Golden Week</h4></a>
                                <ul className="event-list">
                                    <li>
                                        <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>16 Sep 2022</div>
                                    </li>
                                    <li>
                                        <div><img className="img-fluid " src="assets/images/location-marker.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>Bangkok Marriott Hotel...</div>
                                    </li>
                                </ul>
                            </div>
                        </OwlCarousel>

                    </div>
                </div>
            </section>
            {/* Upcoming Events End */}

            {/* Upcoming Activities Start */}
            <section className="section-m py-3">
                <div className="container p-0">
                    <div className="row">
                        <div className="col-md-12 px-30  d-m-flex">
                            <h2 className="title">Upcoming Activities</h2>
                            <div className="d-flex justify-content-between align-items-center">
                                <div className="subtitle">The Things That We Engage In </div>
                                <div>
                                    <a href="cpd-activities.html" className="view-text"><span className="view-m">View More</span><span className="see-m">See
                                        All</span> <img src="assets/images/right-arrow.png" alt="icon" width="18"
                                            height="18" className="ml-2" /></a>
                                </div>
                            </div>
                        </div>

                        <OwlCarousel items={6} autoplay={false} className="owl-carousel events-carousel mt-4 px-20">
                            <div className="event-item text-center">
                                <div className="position-relative main-img mb-2">
                                    <a href="">
                                        <img className="img-fluid mx-auto" src="assets/images/image 15.png" alt="" /></a>
                                    <span>5 Credits</span>
                                    <div className="timer">
                                        <div className="hours"></div>
                                        <div className="minutes"></div>
                                        <div className="seconds"></div>
                                    </div>
                                </div>
                                <a href=""><h4>Doctors without Borders</h4></a>
                                <ul className="event-list">
                                    <li>
                                        <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>16 Sep 2022</div>
                                    </li>
                                    <li>
                                        <div><img className="img-fluid " src="assets/images/location-marker.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>Online</div>
                                    </li>
                                </ul>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img mb-2">
                                    <a href=""><img className="img-fluid mx-auto" src="assets/images/image 13.png" alt="" /></a>
                                    <span>5 Credits</span>
                                </div>
                                <a href=""><h4>Dental Implants specialists in ...</h4></a>
                                <ul className="event-list">
                                    <li>
                                        <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>16 Sep 2022</div>
                                    </li>
                                    <li>
                                        <div><img className="img-fluid " src="assets/images/location-marker.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>Bangkok Marriott Hotel...</div>
                                    </li>
                                </ul>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img mb-2">
                                    <a href=""><img className="img-fluid mx-auto" src="assets/images/image 16.png" alt="" /></a>
                                    <span>5 Credits</span>
                                </div>
                                <a href=""><h4>Golden Week</h4></a>
                                <ul className="event-list">
                                    <li>
                                        <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>16 Sep 2022</div>
                                    </li>
                                    <li>
                                        <div><img className="img-fluid " src="assets/images/location-marker.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>Bangkok Marriott Hotel...</div>
                                    </li>
                                </ul>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img mb-2">
                                    <a href=""><img className="img-fluid mx-auto" src="assets/images/image 15.png" alt="" /></a>
                                    <span>5 Credits</span>
                                    <div className="timer">
                                        <div className="hours"></div>
                                        <div className="minutes"></div>
                                        <div className="seconds"></div>
                                    </div>
                                </div>
                                <a href=""><h4>Doctors without Borders</h4></a>
                                <ul className="event-list">
                                    <li>
                                        <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>16 Sep 2022</div>
                                    </li>
                                    <li>
                                        <div><img className="img-fluid " src="assets/images/location-marker.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>Online</div>
                                    </li>
                                </ul>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img mb-2">
                                    <a href=""><img className="img-fluid mx-auto" src="assets/images/image 13.png" alt="" /></a>
                                    <span>5 Credits</span>
                                </div>
                                <a href=""><h4>Dental Implants specialists in ...</h4></a>
                                <ul className="event-list">
                                    <li>
                                        <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>16 Sep 2022</div>
                                    </li>
                                    <li>
                                        <div><img className="img-fluid " src="assets/images/location-marker.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>Bangkok Marriott Hotel...</div>
                                    </li>
                                </ul>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img mb-2">
                                    <a href=""><img className="img-fluid mx-auto" src="assets/images/image 16.png" alt="" /></a>
                                    <span>5 Credits</span>
                                </div>
                                <a href=""><h4>Golden Week</h4></a>
                                <ul className="event-list">
                                    <li>
                                        <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>16 Sep 2022</div>
                                    </li>
                                    <li>
                                        <div><img className="img-fluid " src="assets/images/location-marker.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>Bangkok Marriott Hotel...</div>
                                    </li>
                                </ul>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img mb-2">
                                    <a href=""><img className="img-fluid mx-auto" src="assets/images/image 15.png" alt="" /></a>
                                    <span>5 Credits</span>
                                    <div className="timer">
                                        <div className="hours"></div>
                                        <div className="minutes"></div>
                                        <div className="seconds"></div>
                                    </div>
                                </div>
                                <a href=""><h4>Doctors without Borders</h4></a>
                                <ul className="event-list">
                                    <li>
                                        <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>16 Sep 2022</div>
                                    </li>
                                    <li>
                                        <div><img className="img-fluid " src="assets/images/location-marker.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>Online</div>
                                    </li>
                                </ul>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img mb-2">
                                    <a href=""><img className="img-fluid mx-auto" src="assets/images/image 13.png" alt="" /></a>
                                    <span>5 Credits</span>
                                </div>
                                <a href=""><h4>Dental Implants specialists in ...</h4></a>
                                <ul className="event-list">
                                    <li>
                                        <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>16 Sep 2022</div>
                                    </li>
                                    <li>
                                        <div><img className="img-fluid " src="assets/images/location-marker.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>Bangkok Marriott Hotel...</div>
                                    </li>
                                </ul>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img mb-2">
                                    <a href=""><img className="img-fluid mx-auto" src="assets/images/image 16.png" alt="" /></a>
                                    <span>5 Credits</span>
                                </div>
                                <a href=""><h4>Golden Week</h4></a>
                                <ul className="event-list">
                                    <li>
                                        <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>16 Sep 2022</div>
                                    </li>
                                    <li>
                                        <div><img className="img-fluid " src="assets/images/location-marker.png" alt="" width="12"
                                            height="12" /></div>
                                        <div>Bangkok Marriott Hotel...</div>
                                    </li>
                                </ul>
                            </div>
                        </OwlCarousel>

                    </div>
                </div>
            </section>
            {/* Upcoming Activities End */}

            {/* News Start */}
            <section className="section-m py-3 mob-mb-30">
                <div className="container p-0">
                    <div className="row">
                        <div className="col-md-12 px-30 d-m-flex2">
                            <div className="d-flex justify-content-between align-items-center">
                                <div>
                                    <h2 className="title">News</h2>
                                </div>
                                <div>
                                    <a href="news.html" className="view-text"><span className="view-m">View More</span><span className="see-m">See
                                        All</span> <img src="assets/images/right-arrow.png" alt="icon" width="18"
                                            height="18" className="ml-2" /></a>
                                </div>
                            </div>
                        </div>

                        <OwlCarousel items={4} autoplay={false} className="owl-carousel news-carousel mt-4 px-20">
                            <div className="event-item text-center">
                                <div className="position-relative main-img">
                                    <a href="news-detail.html">  <img className="img-fluid mx-auto" src="assets/images/image 21.png" alt="" /></a>
                                </div>
                                <div className="news-info">
                                    <a href="news-detail.html"> <h4>International Clinical Research (Trials) D...</h4></a>
                                    <p>Clinical research is vitally important as it is the found...</p>
                                    <ul className="event-list">
                                        <li>
                                            <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                                height="12" /></div>
                                            <div>16 Sep 2022</div>
                                        </li>
                                        <li>
                                            <div><img className="img-fluid " src="assets/images/location-marker.png" alt=""
                                                width="12" height="12" /></div>
                                            <div>Online</div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img">
                                    <a href="news-detail.html"><img className="img-fluid mx-auto" src="assets/images/no-preview.png" alt="" /></a>
                                </div>
                                <div className="news-info">
                                    <a href="news-detail.html"><h4>Ministerial Regulation Update</h4></a>
                                    <p></p>
                                    <ul className="event-list">
                                        <li>
                                            <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                                height="12" /></div>
                                            <div>16 Sep 2022</div>
                                        </li>
                                        <li>
                                            <div><img className="img-fluid " src="assets/images/location-marker.png" alt=""
                                                width="12" height="12" /></div>
                                            <div>Bangkok Marriott Hotel...</div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img">
                                    <a href="news-detail.html"> <img className="img-fluid mx-auto" src="assets/images/image 21.png" alt="" /></a>
                                </div>
                                <div className="news-info">
                                    <a href="news-detail.html"> <h4>Clinical research is vitally important as it is the found...</h4></a>
                                    <p>Clinical research is vitally important as it is the found...</p>
                                    <ul className="event-list">
                                        <li>
                                            <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                                height="12" /></div>
                                            <div>16 Sep 2022</div>
                                        </li>
                                        <li>
                                            <div><img className="img-fluid " src="assets/images/location-marker.png" alt=""
                                                width="12" height="12" /></div>
                                            <div>Bangkok Marriott Hotel...</div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img">
                                    <a href="news-detail.html"> <img className="img-fluid mx-auto" src="assets/images/image 21.png" alt="" /></a>
                                </div>
                                <div className="news-info">
                                    <a href="news-detail.html"> <h4>Clinical research is vitally important as it is the found...</h4></a>
                                    <p>Clinical research is vitally important as it is the found...</p>
                                    <ul className="event-list">
                                        <li>
                                            <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                                height="12" /></div>
                                            <div>16 Sep 2022</div>
                                        </li>
                                        <li>
                                            <div><img className="img-fluid " src="assets/images/location-marker.png" alt=""
                                                width="12" height="12" /></div>
                                            <div>Bangkok Marriott Hotel...</div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img">
                                    <a href="news-detail.html"> <img className="img-fluid mx-auto" src="assets/images/image 21.png" alt="" /></a>
                                </div>
                                <div className="news-info">
                                    <a href="news-detail.html"> <h4>Clinical research is vitally important as it is the found...</h4></a>
                                    <p>Clinical research is vitally important as it is the found...</p>
                                    <ul className="event-list">
                                        <li>
                                            <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                                height="12" /></div>
                                            <div>16 Sep 2022</div>
                                        </li>
                                        <li>
                                            <div><img className="img-fluid " src="assets/images/location-marker.png" alt=""
                                                width="12" height="12" /></div>
                                            <div>Bangkok Marriott Hotel...</div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </OwlCarousel>

                        {/* <div className="owl-carousel news-carousel mt-4 px-20">
                            <div className="event-item text-center">
                                <div className="position-relative main-img">
                                    <a href="news-detail.html">  <img className="img-fluid mx-auto" src="assets/images/image 21.png" alt="" /></a>
                                </div>
                                <div className="news-info">
                                    <a href="news-detail.html"> <h4>International Clinical Research (Trials) D...</h4></a>
                                    <p>Clinical research is vitally important as it is the found...</p>
                                    <ul className="event-list">
                                        <li>
                                            <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                                height="12" /></div>
                                            <div>16 Sep 2022</div>
                                        </li>
                                        <li>
                                            <div><img className="img-fluid " src="assets/images/location-marker.png" alt=""
                                                width="12" height="12" /></div>
                                            <div>Online</div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img">
                                    <a href="news-detail.html"><img className="img-fluid mx-auto" src="assets/images/no-preview.png" alt="" /></a>
                                </div>
                                <div className="news-info">
                                    <a href="news-detail.html"><h4>Ministerial Regulation Update</h4></a>
                                    <p></p>
                                    <ul className="event-list">
                                        <li>
                                            <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                                height="12" /></div>
                                            <div>16 Sep 2022</div>
                                        </li>
                                        <li>
                                            <div><img className="img-fluid " src="assets/images/location-marker.png" alt=""
                                                width="12" height="12" /></div>
                                            <div>Bangkok Marriott Hotel...</div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img">
                                    <a href="news-detail.html"> <img className="img-fluid mx-auto" src="assets/images/image 21.png" alt="" /></a>
                                </div>
                                <div className="news-info">
                                    <a href="news-detail.html"> <h4>Clinical research is vitally important as it is the found...</h4></a>
                                    <p>Clinical research is vitally important as it is the found...</p>
                                    <ul className="event-list">
                                        <li>
                                            <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                                height="12" /></div>
                                            <div>16 Sep 2022</div>
                                        </li>
                                        <li>
                                            <div><img className="img-fluid " src="assets/images/location-marker.png" alt=""
                                                width="12" height="12" /></div>
                                            <div>Bangkok Marriott Hotel...</div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img">
                                    <a href="news-detail.html"> <img className="img-fluid mx-auto" src="assets/images/image 21.png" alt="" /></a>
                                </div>
                                <div className="news-info">
                                    <a href="news-detail.html"> <h4>Clinical research is vitally important as it is the found...</h4></a>
                                    <p>Clinical research is vitally important as it is the found...</p>
                                    <ul className="event-list">
                                        <li>
                                            <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                                height="12" /></div>
                                            <div>16 Sep 2022</div>
                                        </li>
                                        <li>
                                            <div><img className="img-fluid " src="assets/images/location-marker.png" alt=""
                                                width="12" height="12" /></div>
                                            <div>Bangkok Marriott Hotel...</div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div className="event-item text-center">
                                <div className="position-relative main-img">
                                    <a href="news-detail.html"> <img className="img-fluid mx-auto" src="assets/images/image 21.png" alt="" /></a>
                                </div>
                                <div className="news-info">
                                    <a href="news-detail.html"> <h4>Clinical research is vitally important as it is the found...</h4></a>
                                    <p>Clinical research is vitally important as it is the found...</p>
                                    <ul className="event-list">
                                        <li>
                                            <div><img className="img-fluid" src="assets/images/clock.png" alt="" width="12"
                                                height="12" /></div>
                                            <div>16 Sep 2022</div>
                                        </li>
                                        <li>
                                            <div><img className="img-fluid " src="assets/images/location-marker.png" alt=""
                                                width="12" height="12" /></div>
                                            <div>Bangkok Marriott Hotel...</div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div> */}

                    </div>
                </div>
            </section>
            {/* News End */}

            <Footer />
        </div>
    );
}

export default Home