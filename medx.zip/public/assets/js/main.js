
// Spinner
var spinner = function () {
    setTimeout(function () {
        if ($('#spinner').length > 0) {
            $('#spinner').removeClass('show');
        }
    }, 1);
};
spinner();


// Initiate the wowjs
new WOW().init();


// Sticky Navbar
$(window).scroll(function () {
    if ($(this).scrollTop() > 100) {
        $('.sticky-top').addClass('shadow-sm').css('top', '0px');
        $('.slogo').css('display', 'block');
        $('.nlogo').css('display', 'none');
    } else {
        $('.sticky-top').removeClass('shadow-sm').css('top', '-100px');
        $('.slogo').css('display', 'none');
        $('.nlogo').css('display', 'block');
    }
});


// Back to top button
$(window).scroll(function () {
    if ($(this).scrollTop() > 300) {
        $('.back-to-top').fadeIn('slow');
    } else {
        $('.back-to-top').fadeOut('slow');
    }
});
$('.back-to-top').click(function () {
    $('html, body').animate({ scrollTop: 0 }, 1500, 'easeInOutExpo');
    return false;
});


// events carousel
$(".events-carousel").owlCarousel({
    autoplay: true,
    smartSpeed: 1000,
    items: 6,
    dots: false,
    loop: false,
    responsiveClass: true,
        responsive: {
            0:{
            items: 2
            },
            420:{
            items: 2
            },
            520:{
                items: 2
            },
            580:{
                items: 2
            },
            620:{
                items: 3
            },
            680:{
                items: 4
            },
            768:{
            items: 4
            },
            991:{
                items: 5
            },
            1024:{
                items: 5
            },
            1199:{
                items: 6
            }
    }
});
$(".events-carousel2").owlCarousel({
    autoplay: true,
    smartSpeed: 1000,
    items: 4,
    dots: false,
    loop: true,
    responsiveClass: true,
        responsive: {
            0:{
            items: 2
            },
            420:{
            items: 3
            },
            520:{
                items: 3
            },
            580:{
                items: 3
            },
            620:{
                items: 3
            },
            680:{
                items: 3
            },
            768:{
            items: 3
            },
            991:{
                items: 3
            },
            1024:{
                items: 3
            },
            1199:{
                items: 4
            }
    }
    
});

// events carousel
$(".events-carousel3").owlCarousel({
    autoplay: true,
    smartSpeed: 1000,
    items: 6,
    dots: false,
    loop: false,
    responsiveClass: true,
        responsive: {
            0:{
            items: 2
            },
            420:{
            items: 2
            },
            520:{
                items: 3
            },
            580:{
                items: 3
            },
            620:{
                items: 4
            },
            680:{
                items: 4
            },
            768:{
            items: 4
            },
            991:{
                items: 5
            },
            1024:{
                items: 5
            },
            1199:{
                items: 6
            }
    }
});

// news carousel
$(".news-carousel").owlCarousel({
    autoplay: true,
    smartSpeed: 1000,
    items: 4,
    dots: false,
    // loop: true,
    responsiveClass: true,
    responsive: {
        0:{
        items: 1
        },
        480:{
        items: 1
        },
        680:{
            items: 2
        },
        768:{
        items: 4
        },
        991:{
            items: 4
        },
        1024:{
            items: 4
        },
        1199:{
            items: 4
        }
}
});



$(document).ready(function () {
    $(".more-save").click(function () {
        $("#more-information").hide();
        $("#terms").show();
    });
    $("#terms .btn").click(function () {
        $(".modal-backdrop").remove();
        $("body").css('overflow', 'scroll');
    });
    // $('.dislike-btn').click(function() {
    //     $('.like-btn').show();
    //     $('.dislike-btn').hide();
    // });
    // $('.like-btn').click(function() {
    //     $('.dislike-btn').show();
    //     $('.like-btn').hide();
    // });
    $('.text-b').click(function() {
        $('.text-r').show();
        $('.text-b').hide();
    });
    $('.create').click(function() {
        $('#bookmarkto').hide();
    });
    $('.close-modal').click(function() {
        $(".modal-backdrop").remove();
        $('#createcollection').hide();
        $("body").removeClass("modal-open");
        $('body[style]').removeAttr('style');
        $('.bookmark-hide').show();
        $('.bookmark-show').hide();
        return false;
    });
    
});

$("input:radio:checked").next('label').addClass("active");


//product timer

function makeTimer() {

    //		var endTime = new Date("29 April 2018 9:56:00 GMT+01:00");	
    var endTime = new Date("29 April 2020 9:56:00 GMT+01:00");
    endTime = (Date.parse(endTime) / 1000);

    var now = new Date();
    now = (Date.parse(now) / 1000);

    var timeLeft = endTime - now;

    var days = Math.floor(timeLeft / 86400);
    var hours = Math.floor((timeLeft - (days * 86400)) / 3600);
    var minutes = Math.floor((timeLeft - (days * 86400) - (hours * 3600)) / 60);
    var seconds = Math.floor((timeLeft - (days * 86400) - (hours * 3600) - (minutes * 60)));

    if (hours < "10") { hours = "0" + hours; }
    if (minutes < "10") { minutes = "0" + minutes; }
    if (seconds < "10") { seconds = "0" + seconds; }

    // $(".days").html(days + "<span>Days</span>");
    $(".hours").html(hours + " : ");
    $(".minutes").html(minutes + " : ");
    $(".seconds").html(seconds);

}

setInterval(function () { makeTimer(); }, 1000);



//Gallery Slider

let slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("demo");
  let captionText = document.getElementById("caption");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
  captionText.innerHTML = dots[slideIndex-1].alt;
}


var $container = $('.mySlides'), // you should use a more specific selector, not just `div`
    $aside = $('img', $container),
    parentX = $container.position().left,
    onMouseMove = function(e) {
        var left = e.clientX - parentX;
        $aside.css('left', left).children('img').css('left', -left);        
    };

$('img', $container).on('dragstart', function(e) {
    e.preventDefault(); // disable dragging img
});

$container.mousedown(function() {
    $container.on("mousemove", onMouseMove);
}).mouseup(function() {
    $container.off("mousemove", onMouseMove);
});













