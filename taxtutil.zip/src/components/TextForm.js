import React from "react";
import { useState } from "react";

export const TextForm = (props) => {
  const handleCopy = () => {
    var text = document.getElementById("myBox");
    text.select();
    navigator.clipboard.writeText(text.value);
    props.showAlert("Copied to Clickbord!", "success");
  };
  const handleSpeakClick = () => {
    let msg = new SpeechSynthesisUtterance();
    msg.text = text;
    window.speechSynthesis.speak(msg);
  };
  const handleUpClick = () => {
    // console.log("Uppercase Was Clicked: " + text);
    let newText = text.toUpperCase();
    setText(newText);
    props.showAlert("Convert Text in Uppercase!", "success");
  };
  const handleClearClick = () => {
    let newText = "";
    setText(newText);
  };
  const handleLoClick = () => {
    // console.log("Lowercase Was Clicked: " + text);
    let newText = text.toLowerCase();
    setText(newText);
    props.showAlert("Convert Text in Lowercase!", "success");
  };
  const handleOnChange = (event) => {
    //console.log("On Change");
    setText(event.target.value);
  };
  const [text, setText] = useState("");
  return (
    <>
      <h1
        className="text-center"
        style={{ color: props.mode === "dark" ? "white" : "#040728" }}
      >
        {props.heading}
      </h1>
      <div
        className="mb-3"
        style={{ color: props.mode === "dark" ? "white" : "#040728" }}
      >
        <textarea
          className="form-control my-4"
          value={text}
          onChange={handleOnChange}
          id="myBox"
          rows="11"
          style={{
            backgroundColor:
              props.mode === "dark" ? "rgb(53, 57, 98)" : "white",
            color: props.mode === "dark" ? "white" : "rgb(53, 57, 98)",
          }}
        ></textarea>
        <button
          disabled={text.length === 0}
          className="btn btn-primary mx-2 my-2"
          onClick={handleUpClick}
        >
          Convert to Uppercase
        </button>
        <button
          disabled={text.length === 0}
          className="btn btn-primary mx-2 my-2"
          onClick={handleLoClick}
        >
          Convert to Lowercase
        </button>
        <button
          disabled={text.length === 0}
          className="btn btn-primary mx-2 my-2"
          onClick={handleClearClick}
        >
          Clear Text
        </button>
        <button
          disabled={text.length === 0}
          className="btn btn-primary mx-2 my-2"
          onClick={handleCopy}
        >
          Copy Text
        </button>
        <button
          disabled={text.length === 0}
          className="btn btn-primary mx-2 my-2"
          onClick={handleSpeakClick}
        >
          Speak
        </button>
      </div>
      <div
        className="container my-3"
        style={{ color: props.mode === "dark" ? "white" : "#040728" }}
      >
        <h2>Your Text Summary</h2>
        <p>
          {
            text.split(" ").filter((element) => {
              return element.length !== 0;
            }).length
          }{" "}
          Words and {text.length} Characters
        </p>
        <p>
          {0.008 *
            text.split(" ").filter((element) => {
              return element.length !== 0;
            }).length}{" "}
          Minites To Read
        </p>
        <h2>Preview</h2>
        <p>
          {text.length > 0
            ? text
            : "Enter Something in the textbox above to preview of the text"}
        </p>
      </div>
    </>
  );
};
