import React from 'react'
import Footer from './Footer'
import Navbar from './Navbar'
import { Link } from 'react-router-dom'

export default function News() {
  return (
    <>
    <Navbar/>
      {/* <!-- Mobile View Top Start --> */}
    <div className="mobile-top d-none">
        <div className="container">
            <div className="row">
                <div className="d-flex align-items-center justify-content-between">
                    <div>
                        <h4>Community</h4>
                    </div>
                    <div>
                        <ul className="d-flex align-items-center justify-content-between">
                            <li>
                                <a href="notifications.html"><img src="assets/images/768/bell.png" className="" alt="" width=""
                                        height="" /></a>
                            </li>
                            <li>
                                <a href="profile.html"><img src="assets/images/Ellipse 83.png" className="img-rounded"
                                        alt="" width="50" height="" /></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    {/* <!-- Mobile View Top End --> */}

    {/* <!-- Mobile Bottom Menu Start --> */}
    <div className="d-none mob-menu bg-white">
        <ul className="d-flex align-items-center justify-content-between">
            <li>
                <a href="index.html">
                    <img src="assets/images/768/icon1.png" className="" width="" height="" />
                </a>
            </li>
            <li>
                <a href="education.html">
                    <img src="assets/images/768/icon2.png" className="" width="" height="" />
                </a>
            </li>
            <li>
                <a href="community.html">
                    <img src="assets/images/768/icon3.png" className="active" width="" height="" />
                </a>
            </li>
            <li>
                <a href="offer.html">
                    <img src="assets/images/768/icon4.png" className="" width="" height="" />
                </a>
            </li>
            <li>
                <a href="medx.html">
                    <img src="assets/images/768/icon5.png" className="" width="" height="" />
                </a>
            </li>
        </ul>
    </div>
    {/* <!-- Mobile Bottom Menu End --> */}

    <section className="pt-3 top-curve">
        <div className="container">
            <div className="row px-10">
                <div className="col-md-12">
                    <h1 className="mt-5 mb-4 main-title d-m-none">Community</h1>
                </div>
                <div className="col-md-12">
                    <div className="top-links d-none">
                        <ul>
                            <li>
                                <a href="community.html" className="">In focus</a>
                            </li>
                            <li>
                                <a href="news.html" className="active">News</a>
                            </li>
                            <li>
                                <a href="blog.html" className="">Blog</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

     {/* <!-- Carousel Start --> */}
     <section className="pt-2 d-none">
        <div className="container p-0 carousel-p">
            <div className="row">
                <div id="demo" className="carousel slide" data-bs-ride="carousel">

                    {/* <!-- Indicators/dots --> */}
                    <div className="carousel-indicators">
                        <button type="button" data-bs-target="#demo" data-bs-slide-to="0" className="active"></button>
                        <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
                        <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
                        <button type="button" data-bs-target="#demo" data-bs-slide-to="3"></button>
                    </div>

                    <div className="carousel-inner">
                        <div className="carousel-item active">
                            <img className="w-100" src="assets/images/community-banner.png" alt="Image"/>
                        </div>
                        <div className="carousel-item">
                            <img className="w-100" src="assets/images/community-banner.png" alt="Image"/>
                        </div>
                        <div className="carousel-item">
                            <img className="w-100" src="assets/images/community-banner.png" alt="Image"/>
                        </div>
                        <div className="carousel-item">
                            <img className="w-100" src="assets/images/community-banner.png" alt="Image"/>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </section>
    {/* <!-- Carousel End --> */}

    {/* <!-- News Start --> */}
    <section className="community pb-3 mob-pt-1 mob-mt-m-35 mob-pb-0">
        <div className="container p-0">
            <div className="row">
                <div className="col-md-12 px-30 mob-px-30">
                    <ul className="nav nav-tabs d-m-none" id="myTab" role="tablist">
                        <li className="nav-item" role="presentation">
                            <button className="nav-link" id="focus-tab" onclick="window.location.href = 'community.html'">In focus</button>
                        </li>
                        <li className="nav-item" role="presentation">
                            <button className="nav-link active" id="news-tab" data-bs-toggle="tab" data-bs-target="#news"
                                type="button" role="tab" aria-controls="news" aria-selected="false">News</button>
                        </li>
                        <li className="nav-item" role="presentation">
                            <button className="nav-link" id="blog-tab" onclick="window.location.href = 'blog.html'">Blog</button>
                        </li>
                    </ul>
                    <div className="tab-content mob-mb-30 clearfix" id="myTabContent">
                       
                        <div className="tab-pane fade show active" id="news" role="tabpanel" aria-labelledby="news-tab">
                            <div className="row">
                                <div className="col-md-10 col-mob-46">
                                    <div className="search-box mb-2">
                                        <form action="">
                                            <div className="row">
                                                <div className="col-md-12">
                                                    <div className="input-group">
                                                        <span className="input-group-text"><img src="assets/images/search.png"
                                                                alt="search-icon" width="15" height="15" /></span>
                                                        <input type="text" className="form-control" placeholder="Search"/>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div className="mob-pr-0 specialiry my-4 mob-mb-0 mob-mt-30 mob-pl-8">
                                        <h5 className="title mb-4 d-m-none">Medical Institute</h5>
                                        <ul>
                                            <li><a href="" className="active">All</a></li>
                                            <li><a href="" className="">Ramathibodi</a></li>
                                            <li><a href="" className="">Chulalongkorn</a></li>
                                            <li><a href="" className="">Vajira</a></li>
                                            <li><a href="" className="">Naresuan</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="col-md-10 bg-m-white">
                                    <div className="bg-gray mb-3">
                                        <h3>Doctors without borders in the future</h3>
                                        <div className="d-flex align-items-center">
                                            <div>
                                                <img src="assets/images/Ellipse 2.png" className="rounded" alt="" width="40" height="40" />
                                            </div>
                                            <div className="ml-1">
                                                <h5 className="mb-0">Kittiya Yuthasastrkosol</h5>
                                                <span>1 day ago</span>
                                            </div>
                                        </div>
                                        <div className="slide-gallery my-3">
                                            <img src="assets/images/image 94.png" className="w-100 img-rouded-5"/>
                                        </div>
                                        <div className="bottom-block pt-3 mt-3 d-flex align-items-center justify-content-between">
                                            <div>
                                                <ul className="d-flex m-0 p-0 image-list">
                                                    <li>
                                                        <a href="">
                                                            <img src="assets/images/avatar (1).png" className="rounded" alt="" width="35" height="35" />
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="">
                                                            <img src="assets/images/avatar (2).png" className="rounded" alt="" width="35" height="35" />
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="">
                                                            <img src="assets/images/avatar (1).png" className="rounded" alt="" width="35" height="35" />
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="">
                                                            <img src="assets/images/avatar2.png" className="rounded" alt="" width="35" height="35" />
                                                            <span className="image-count">+2</span>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div>
                                                <Link to = "/news-details" className="view-text2">Read More <img src="assets/images/right-arrow.png" alt="icon" width="18"
                                                    height="18" className="ml-2" /></Link>
                                            </div>
                                        </div>

                                    </div>
                                    <div className="bg-gray mb-3">
                                        <h3>Doctors without borders in the future</h3>
                                        <div className="d-flex align-items-center">
                                            <div>
                                                <img src="assets/images/Ellipse 2.png" className="rounded" alt="" width="40" height="40" />
                                            </div>
                                            <div className="ml-1">
                                                <h5 className="mb-0">Kittiya Yuthasastrkosol</h5>
                                                <span>1 day ago</span>
                                            </div>
                                        </div>
                                        <div className="slide-gallery my-3">
                                            <div className="mySlides">
                                              <img src="assets/images/image 94.png" className="w-100 img-rounded-5"/>
                                            </div>
                                          
                                            <div className="mySlides">
                                                <img src="assets/images/image 94.png" className="w-100 img-rounded-5"/>
                                            </div>
                                          
                                            <div className="mySlides">
                                                <img src="assets/images/image 94.png" className="w-100 img-rounded-5"/>
                                            </div>
                                              
                                            <div className="mySlides">
                                                <img src="assets/images/image 94.png" className="w-100 img-rounded-5"/>
                                            </div>
                                          
                                            <div className="mySlides">
                                                <img src="assets/images/image 94.png" className="w-100 img-rounded-5"/>
                                            </div>
                                              
                                            <div className="mySlides">
                                                <img src="assets/images/image 94.png" className="w-100 img-rounded-5"/>
                                            </div>
                                              
                                            <a className="prev" onclick="plusSlides(-1)">❮</a>
                                            <a className="next" onclick="plusSlides(1)">❯</a>
                                          
                                            <div className="d-flex column-list">
                                              <div className="column">
                                                <img className="demo cursor w-100" src="assets/images/image 92.png" onclick="currentSlide(1)" alt=""/>
                                              </div>
                                              <div className="column">
                                                <img className="demo cursor w-100" src="assets/images/image 92.png" onclick="currentSlide(2)" alt=""/>
                                              </div>
                                              <div className="column">
                                                <img className="demo cursor w-100" src="assets/images/image 92.png" onclick="currentSlide(3)" alt=""/>
                                              </div>
                                              <div className="column">
                                                <Link to="/news-gallery">
                                                    <img className="demo cursor w-100" src="assets/images/image 92.png" alt=""/>
                                                <div className="overlay">
                                                    <span className="image-count">+20</span>
                                                </div>
                                                </Link>
                                              </div>
                                            </div>
                                        </div>
                                        <div className="bottom-block pt-3 mt-3 d-flex align-items-center justify-content-between">
                                            <div>
                                                <ul className="d-flex m-0 p-0 image-list">
                                                    <li>
                                                        <a href="">
                                                            <img src="assets/images/avatar (1).png" className="rounded" alt="" width="35" height="35" />
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="">
                                                            <img src="assets/images/avatar (2).png" className="rounded" alt="" width="35" height="35" />
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="">
                                                            <img src="assets/images/avatar (1).png" className="rounded" alt="" width="35" height="35" />
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="">
                                                            <img src="assets/images/avatar2.png" className="rounded" alt="" width="35" height="35" />
                                                            <span className="image-count">+2</span>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div>
                                                <Link to = "/news-details" className="view-text2">Read More <img src="assets/images/right-arrow.png" alt="icon" width="18"
                                                    height="18" className="ml-2" /></Link>
                                            </div>
                                        </div>

                                    </div>
                                    
                                    <div className="bg-gray mb-3">
                                        <h3>Doctors without borders in the future</h3>
                                        <div className="d-flex align-items-center">
                                            <div>
                                                <img src="assets/images/Ellipse 2.png" className="rounded" alt="" width="40" height="40" />
                                            </div>
                                            <div className="ml-1">
                                                <h5 className="mb-0">Kittiya Yuthasastrkosol</h5>
                                                <span>1 day ago</span>
                                            </div>
                                        </div>
                                       
                                        <div className="bottom-block mt-3 pt-3 d-flex align-items-center justify-content-between">
                                            <div>
                                                <ul className="d-flex m-0 p-0 image-list">
                                                    <li>
                                                        <a href="">
                                                            <img src="assets/images/avatar (1).png" className="rounded" alt="" width="35" height="35" />
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="">
                                                            <img src="assets/images/avatar (2).png" className="rounded" alt="" width="35" height="35" />
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="">
                                                            <img src="assets/images/avatar (1).png" className="rounded" alt="" width="35" height="35" />
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="">
                                                            <img src="assets/images/avatar2.png" className="rounded" alt="" width="35" height="35" />
                                                            <span className="image-count">+2</span>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div>
                                                <Link to = "/news-details" className="view-text2">Read More <img src="assets/images/right-arrow.png" alt="icon" width="18"
                                                    height="18" className="ml-2" /></Link>
                                            </div>
                                        </div>

                                    </div>
                                    <div className="bg-gray mb-3">
                                        <h3>Doctors without borders in the future</h3>
                                        <div className="d-flex align-items-center">
                                            <div>
                                                <img src="assets/images/Ellipse 2.png" className="rounded" alt="" width="40" height="40" />
                                            </div>
                                            <div className="ml-1">
                                                <h5 className="mb-0">Kittiya Yuthasastrkosol</h5>
                                                <span>1 day ago</span>
                                            </div>
                                        </div>
                                       
                                        <div className="bottom-block mt-3 pt-3 d-flex align-items-center justify-content-between">
                                            <div>
                                                <ul className="d-flex m-0 p-0 image-list">
                                                    <li>
                                                        <a href="">
                                                            <img src="assets/images/avatar (1).png" className="rounded" alt="" width="35" height="35" />
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="">
                                                            <img src="assets/images/avatar (2).png" className="rounded" alt="" width="35" height="35" />
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="">
                                                            <img src="assets/images/avatar (1).png" className="rounded" alt="" width="35" height="35" />
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="">
                                                            <img src="assets/images/avatar2.png" className="rounded" alt="" width="35" height="35" />
                                                            <span className="image-count">+2</span>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div>
                                                <Link to="/news-details" className="view-text2">Read More <img src="assets/images/right-arrow.png" alt="icon" width="18"
                                                    height="18" className="ml-2" /></Link>
                                            </div>
                                        </div>

                                    </div>
                                    <div className="px-30 mt-4 mob-mb-30">
                                        <div className="text-center">
                                            Loading...
                                        </div>
                                    </div>

                                </div>
                                <div className="col-md-2 d-m-none">
                                    <div className="img-block mb-3">
                                        <img src="assets/images/image 83.png" className="img-fluid" alt="" width="" height="" />
                                    </div>
                                    <div className="img-block mb-3">
                                        <img src="assets/images/image 110.png" className="img-fluid"  alt="" width="" height="" />
                                    </div>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>
    </section>
    {/* <!-- News End --> */}
    <Footer/>
    </>
  )
}
