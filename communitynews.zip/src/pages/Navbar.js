import React from "react";

function Navbar() {
    return (
        <div>
            {/* Navbar Start */}
            <nav className="navbar navbar-expand-lg bg-white navbar-light sticky-top p-0">
                <div className="container">
                    <a href="index.html" className="navbar-brand nlogo">
                        <img src="assets/images/logo/logo.png" alt="logo" width="" height="" />
                    </a>
                    <a href="index.html" className="navbar-brand slogo">
                        <img src="assets/images/logo/medx1.png" alt="logo" width="" height="" />
                        <img src="assets/images/logo/medx2.png" alt="tagline" width="" height="" />
                    </a>
                    <button type="button" className="navbar-toggler me-4" data-bs-toggle="collapse"
                        data-bs-target="#navbarCollapse">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarCollapse">
                        <div className="navbar-nav ms-auto p-4  p-lg-0">
                            <a href="index.html" className="nav-item nav-link active">Home</a>
                            <a href="education.html" className="nav-item nav-link">Education</a>
                            <a href="community.html" className="nav-item nav-link">Community</a>
                            <a href="offer.html" className="nav-item nav-link">Offer</a>
                        </div>
                        <div className="d-flex float-right menu-right align-items-center">
                            <div className="nav-item dropdown">
                                <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                                    <img src="assets/images/bell.png" alt="bell" width="17" height="" />
                                </a>
                                <div className="dropdown-menu notification-dropdown bg-light m-0">
                                    <div className="card">
                                        <div className="card-header">
                                            <h4>Notifications</h4>
                                            <p>You have <span className="text-primary">4 Notifications</span> today</p>
                                        </div>
                                        <div className="card-body">
                                            <div className="notification-list">
                                                <h4 className="mt-0">Today</h4>
                                                <div className="border-bottom-n">
                                                    <div className="d-flex p-relative">
                                                        <div>
                                                            <img src="assets/images/avatar5.png" className="rounded" alt=""
                                                                width="35" height="35" />
                                                        </div>
                                                        <div className="ml-1 mx-2">
                                                            <a href="">
                                                                <h6 className="mb-0"><strong className="text-primary">Surasak
                                                                    Jaikum</strong> Liked your [topic blog]</h6>
                                                            </a>
                                                            <span className="time">2 mins ago</span>
                                                        </div>
                                                        <div className="status"> </div>
                                                    </div>
                                                </div>
                                                <div className="border-bottom-n pl-55">
                                                    <div className="d-flex p-relative">
                                                        <div className="ml-1 mx-2">
                                                            <a href="">
                                                                <h6 className="mb-0"><strong className="text-primary">Aum
                                                                    Korakit</strong> Mentioned you in a comment</h6>
                                                            </a>
                                                            <span className="time">2 hrs ago</span>
                                                        </div>
                                                        <div className="status"> </div>
                                                    </div>
                                                </div>
                                                <h4 className="mt-0">This Week</h4>
                                                <div className="border-bottom-n pl-55">
                                                    <div className="d-flex p-relative">

                                                        <div className="ml-1 mx-2">
                                                            <a href="">
                                                                <h6 className="mb-0"><strong className="text-primary">Money Mak</strong>
                                                                    Liked your comment</h6>
                                                            </a>
                                                            <span className="time">1 dat ago</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="border-bottom-n">
                                                    <div className="d-flex p-relative">
                                                        <div>
                                                            <img src="assets/images/medx.png" className="rounded" alt="" width="35"
                                                                height="35" />
                                                        </div>
                                                        <div className="ml-1 mx-2">
                                                            <a href="">
                                                                <h6 className="mb-0 fw-400">You have [event or activity name] that
                                                                    you need to join soon.</h6>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="no-notification text-center" style={{ display: "none" }}>
                                                <img src="assets/images/no-notification.png" className="my-3" alt="" width=""
                                                    height="" />
                                                <h5>No notification in this time</h5>
                                                <span>You can see a list of notifications here.</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="nav-item dropdown">
                                <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                                    <img src="assets/images/avatar.png" className="nav-avtar" alt="user-icon" width="" height="" />
                                    Kritiya
                                    <img src="assets/images/angle-down.png" className="arrow-down" alt="arrow" width="9"
                                        height="" />
                                </a>
                                <div className="dropdown-menu bg-light m-0">
                                    <a href="profile.html" className="dropdown-item">Profile</a>
                                    <a href="" className="dropdown-item">Log Out</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
            {/* Navbar End */}
        </div>
    );
}
export default Navbar