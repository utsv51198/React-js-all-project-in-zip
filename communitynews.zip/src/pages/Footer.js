import React from "react";

function Footer() {
    return (
        <div>
            <footer className="py-4 d-m-none">
                <div className="container">
                    <div className="row">
                        <div className="col-md-12">
                            <div className="text-center">
                                <p>
                                    ศูนย์การศึกษาต่อเนื่องของแพทย์ ชั้น 12<br />
                                    อาคารสภาวิชาชีพ ซอยสาธารณสุข 8 กระทรวงสาธารณสุข 8 กระทรวงสาธารณสุข<br />
                                    ถนนติวานนท์ อำเภอเมือง จังหวัดนนทบุรี 11000
                                </p>
                                <ul className="my-4">
                                    <li>
                                        <img src="assets/images/call.png" alt="" width="" height="" className="img-fluid" />
                                        02-5901894
                                    </li>
                                    <li>
                                        <img src="assets/images/call.png" alt="" width="" height="" className="img-fluid" />
                                        064-9363624
                                    </li>
                                    <li>
                                        <img src="assets/images/Message.png" alt="" width="" height="" className="img-fluid" />
                                        ccme.or.th@gmail.com
                                    </li>
                                </ul>
                                <a href="" className="text-blue">The Medical Council of Thailand</a>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    );
}
export default Footer