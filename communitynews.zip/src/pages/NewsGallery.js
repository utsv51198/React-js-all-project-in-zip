import React from "react";
import Footer from "./Footer";
import Navbar from "./Navbar";
import { Link } from "react-router-dom";
// var slideIndex = 1;
// showSlides(slideIndex);

// function plusSlides(n) {
//   showSlides((slideIndex += n));
// }

// function currentSlide(n) {
//   showSlides((slideIndex = n));
// }

// function showSlides(n) {
//   var i;
//   var slides = document.getElementsByClassName("mySlides");
//   var dots = document.getElementsByClassName("demo");
//   var captionText = document.getElementById("caption");
//   if (n > slides.length) {
//     slideIndex = 1;
//   }
//   if (n < 1) {
//     slideIndex = slides.length;
//   }
//   for (i = 0; i < slides.length; i++) {
//     slides[i].style.display = "none";
//   }
//   for (i = 0; i < dots.length; i++) {
//     dots[i].className = dots[i].className.replace(" active", "");
//   }
//   slides[slideIndex - 1].style.display = "block";
//   dots[slideIndex - 1].className += " active";
//   captionText.innerHTML = dots[slideIndex - 1].alt;
// }

export default function NewsGallery() {
  return (
    <>
      <Navbar />
      {/* <!-- Mobile View Top Start --> */}
      <div className="mobile-gray-top d-none zi-1">
        <div className="container">
          <div className="row">
            <div className="d-flex align-items-center justify-content-between mob-mt-39">
              <div>
                <a href="news.html">
                  <img
                    src="assets/images/768/arrow-left.png"
                    className=""
                    alt=""
                    width=""
                    height=""
                  />
                </a>
              </div>
              <div>
                <h4 className="mb-0"></h4>
              </div>
              <div></div>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- Mobile View Top End --> */}

      {/* <!-- Explore Gallery Start --> */}
      <section className="pb-3 gallery">
        <div className="container p-0">
          <div className="row">
            <div className="col-md-12 px-30">
              <Link to="/" className="left-arrow d-m-none">
                <img
                  src="assets/images/left-arrow.png"
                  className="mr-2"
                  alt=""
                  width=""
                  height=""
                />{" "}
                Back
              </Link>
              <div className="slide-gallery mb-3 mx-auto">
                <div className="mySlides" style={{ display: "block" }}>
                  <div className="numbertext d-none">1 / 11</div>
                  <img src="assets/images/image 1044.png" className="" />
                </div>

                <div className="mySlides">
                  <div className="numbertext d-none">2 / 11</div>
                  <img src="assets/images/image 92.png" className="" />
                </div>

                <div className="mySlides">
                  <div className="numbertext d-none">3 / 11</div>
                  <img src="assets/images/image 94.png" className="" />
                </div>

                <div className="mySlides">
                  <div className="numbertext d-none">4 / 11</div>
                  <img src="assets/images/image 92.png" className="" />
                </div>

                <div className="mySlides">
                  <div className="numbertext d-none">5 / 11</div>
                  <img src="assets/images/image 94.png" className="" />
                </div>

                <div className="mySlides">
                  <div className="numbertext d-none">6 / 11</div>
                  <img src="assets/images/image 92.png" className="" />
                </div>

                <div className="mySlides">
                  <div className="numbertext d-none">7 / 11</div>
                  <img src="assets/images/image 94.png" className="" />
                </div>
                <div className="mySlides">
                  <div className="numbertext d-none">8 / 11</div>
                  <img src="assets/images/image 92.png" className="" />
                </div>

                <div className="mySlides">
                  <div className="numbertext d-none">9 / 11</div>
                  <img src="assets/images/image 94.png" className="" />
                </div>
                <div className="mySlides">
                  <div className="numbertext d-none">10 / 11</div>
                  <img src="assets/images/image 92.png" className="" />
                </div>

                <div className="mySlides">
                  <div className="numbertext d-none">11 / 11</div>
                  <img src="assets/images/image 94.png" className="" />
                </div>
                <a className="prev" onClick={window["plusSlides(-1)"]}>
                  <img src="assets/images/prev.png" alt="" width="" height="" />
                </a>

                <a className="next" onClick={window["plusSlides(1)"]}>
                  <img src="assets/images/next.png" alt="" width="" height="" />
                </a>
                <div className="d-flex justify-content-center column-list">
                  <div className="column">
                    <img
                      className="demo cursor"
                      src="assets/images/image 92.png"
                      onClick={window["currentSlide(1)"]}
                      alt=""
                    />
                  </div>
                  <div className="column">
                    <img
                      className="demo cursor"
                      src="assets/images/image 92.png"
                      onClick={window["currentSlide(2)"]}
                      alt=""
                    />
                  </div>
                  <div className="column">
                    <img
                      className="demo cursor"
                      src="assets/images/image 94.png"
                      onClick={window["currentSlide(3)"]}
                      alt=""
                    />
                  </div>
                  <div className="column">
                    <img
                      className="demo cursor"
                      src="assets/images/image 92.png"
                      onClick={window["currentSlide(4)"]}
                      alt=""
                    />
                  </div>
                  <div className="column">
                    <img
                      className="demo cursor"
                      src="assets/images/image 94.png"
                      onClick={window["currentSlide(5)"]}
                      alt=""
                    />
                  </div>
                  <div className="column">
                    <img
                      className="demo cursor"
                      src="assets/images/image 92.png"
                      onClick={window["currentSlide(6)"]}
                      alt=""
                    />
                  </div>
                  <div className="column">
                    <img
                      className="demo cursor"
                      src="assets/images/image 94.png"
                      onClick={window["currentSlide(7)"]}
                      alt=""
                    />
                  </div>
                  <div className="column">
                    <img
                      className="demo cursor"
                      src="assets/images/image 92.png"
                      onClick={window["currentSlide(8)"]}
                      alt=""
                    />
                  </div>
                  <div className="column">
                    <img
                      className="demo cursor"
                      src="assets/images/image 94.png"
                      onClick={window["currentSlide(9)"]}
                      alt=""
                    />
                  </div>
                  <div className="column">
                    <img
                      className="demo cursor"
                      src="assets/images/image 92.png"
                      onClick={window["currentSlide(10)"]}
                      alt=""
                    />
                  </div>
                  <div className="column">
                    <img
                      className="demo cursor"
                      src="assets/images/image 94.png"
                      onClick={window["currentSlide(11)"]}
                      alt=""
                    />
                  </div>
                </div>
              </div>

              <div className="explore-listing  d-none">
                <div className="my-3 mx-4">
                  <div>
                    <a href="news.html">
                      <h4 className="mb-0">Product Name</h4>
                    </a>
                  </div>
                  <div>
                    <span>
                      1,090 <small>THB</small>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* <!-- Explore gallery End --> */}
      <Footer />
    </>
  );
}
