import React from "react";
import { Routes, Route } from "react-router-dom";
import News from "./pages/News";
import NewsDetails from "./pages/NewsDetails";
import NewsGallery from "./pages/NewsGallery";

function App() {
  return (
    <>
      <Routes>
        <Route path="/" exact element={<News />} />
        <Route exact path="/news-details" element={<NewsDetails />} />
        <Route exact path="/news-gallery" element={<NewsGallery />} />
      </Routes>
    </>
  );
}

export default App;
