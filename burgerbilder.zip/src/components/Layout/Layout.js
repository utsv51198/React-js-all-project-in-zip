import { Ax } from "../../hoc/Ax";
import {SideDrawer}  from "../Navigation/SideDrawer/SideDrawer";
import { Toolbar } from "../Navigation/Toolbar/Toolbar";
import "./Layout.css";

import React, { Component } from 'react'

export default class Layout extends Component {
  constructor() {
    super();
    this.state = {
      showSideDrawer: true,
    };
  }
  sideDrawerClosedHandler = () => {
    this.setState({ showSideDrawer: false });
    console.log("Clicked");
  };

  render() {
    return (
      <Ax>
        <Toolbar />
        <SideDrawer
          open={this.state.showSideDrawer}
          closed={this.sideDrawerClosedHandler}
        />
        <main className="Content">{this.props.children}</main>
      </Ax>
    );
  }
}

