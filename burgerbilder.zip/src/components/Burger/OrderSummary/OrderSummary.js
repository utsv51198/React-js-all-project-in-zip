import React from "react";
import { Ax } from "../../../hoc/Ax";
export const OrderSummary = (props) => {
  const ingredientSummary = Object.keys(props.ingredients).map((igKey) => {
    return (
      <li key={igKey}>
        <span style={{ textTransform: "capitalize" }}>{igKey}</span>:
        {props.ingredients[igKey]}
      </li>
    );
  });

  return (
    <Ax>
      <h3>Your Order</h3>
      <p>A delicious burger with following ingredients : </p>
      <ul>{ingredientSummary}</ul>

      <p><strong>Total Price : {props.price.toFixed(2)}</strong></p>
      <p>Continue to Checkouts</p>
      <button className="btn btn-danger mb-2 my-2" onClick={props.purchaseCanceled}>
        CANCEL
      </button>
      <button className="btn btn-success mb-2 my-2 mx-2"  onClick={props.purchaseContinued}>
        CONTINUE
      </button>
    </Ax>
  );
};
