import { Ax } from "../../../hoc/Ax";
import { Logo } from "../../Logo/Logo";
import { Backdrop } from "../../UI/Backdrop/Backdrop";
import { Navigationitems } from "../Navigationitems/Navigationitems";
import "./SideDrawer.css";
import React from 'react'

export const SideDrawer = (props) => {
  return (
     <Ax>
        <Backdrop show={props.open} clicked={props.closed} />
        <div className="SideDrawer">
          <button
            type="button"
            className="btn-close position-absolute top-0 end-0 translate-middle-x my-2"
            aria-label="Close"
          ></button>
          <Logo height="11%" />

          <nav>
            <Navigationitems />
          </nav>
        </div>
      </Ax>
  )
}

