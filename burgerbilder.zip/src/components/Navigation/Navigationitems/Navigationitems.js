import React from 'react'
import "./Navigationitems.css"
import { Navigationitem } from './Navigationitem/Navigationitem'

export const Navigationitems = (props) => {
  return (
    <ul className='NavigationItems'>
       <Navigationitem link='/' active>Burger Builder</Navigationitem>
       <Navigationitem link='/'>Checkout</Navigationitem>
    </ul>
  )
}
