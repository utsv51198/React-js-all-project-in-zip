import React from 'react'
import burgerLogo from "../../assets/Images/133 burger-logo.png";
import "./Logo.css"

export const Logo = (props) => {
  return (
    <div className='Logo' style={{height : props.height}}>
      <img src={burgerLogo} alt="My Burger" />
    </div>
  );
}
