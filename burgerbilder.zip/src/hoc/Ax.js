import React from 'react'

export const Ax = (props) => {
  return (
    <div>
        {props.children}
    </div>
  )
}
