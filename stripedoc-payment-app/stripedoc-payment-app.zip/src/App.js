import React, { useState } from "react";
import logo from "./logo.svg";
import "./App.css";
import StripeCheckout from "react-stripe-checkout";

function App() {
  const [product, setProduct] = useState({
    name: "React from fb",
    price: 10,
    productBy: "fb",
  });

  const makePayment = async (token) => {
    const body = {
      token,
      product,
    };

    const headers = {
      "Content-Type": "application/json",
    };

    try {
      const response = await fetch(`http://localhost:8282/payment`, {
        method: "POST",
        headers,
        body: JSON.stringify(body),
      });
      console.log("RESPONSE", response);
      const { status } = response;
      console.log("STATUS", status);
    } catch (error) {
      console.log("ERROR", error);
    }
  };
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <a
          className="App-link"
          href="#"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
        <StripeCheckout
          token={makePayment}
          stripeKey="pk_test_51KVDzxLqP6NVVgd3TuKtrxiCDodKsgmlFRzNELtkltn9MRYzNqmJIdZ6xcmleMNs3Qw2woLDfMioK1DV4rowRYou00LDa87W3F"
          name="Buy React"
          amount={product.price}
        >
          <button className="btn-large blue">
            Buy React in ${product.price}
          </button>
        </StripeCheckout>
      </header>
    </div>
  );
}

export default App;
