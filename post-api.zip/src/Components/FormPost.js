import axios from "axios";
import React, { useState } from "react";

export default function FormPost() {
  const [name, setName] = useState("");
  const [occupation, setOccupation] = useState("");
  const [email, setEmail] = useState("");
  const [bio, setBio] = useState("");

  const submitHandler = (e) => {
    const data = { name, occupation, email, bio };
    e.preventDefault();
    axios
      .post("https://ti-react-test.herokuapp.com/users", data)
      .then((response) => {
        console.log("response", response);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  return (
    <div className="conatiner">
      <h1>Post Api Data</h1>
      <input
        placeholder="Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        type="text"
        name="name"
      />{" "}
      <br />
      <br />
      <input
        placeholder="Occupation"
        value={occupation}
        onChange={(e) => setOccupation(e.target.value)}
        type="text"
        name="occupation"
      />{" "}
      <br />
      <br />
      <input
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        type="email"
        name="email"
      />{" "}
      <br />
      <br />
      <textarea
        placeholder="Bio"
        value={bio}
        onChange={(e) => setBio(e.target.value)}
        type="text"
        name="bio"
        rows="3"
      ></textarea>
      <br />
      <br />
      <button onClick={submitHandler} type="button" className="btn btn-primary">
        Submit
      </button>
    </div>
  );
}
