import "./App.css";
import FormPost from "./Components/FormPost";

function App() {
  return (
    <div className="App">
      <FormPost />
    </div>
  );
}

export default App;
