import "./App.css";
import DataList from "./components/DataList";

function App() {
  return (
    <div className="App">
      <DataList />
    </div>
  );
}

export default App;
