import React, { useEffect, useState } from "react";
import axios from "axios";
import BootStrapTable from "react-bootstrap-table-next";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.css";
import paginationFactory from "react-bootstrap-table2-paginator";
import "react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css";
import filterFactory, { textFilter } from "react-bootstrap-table2-filter";
import "react-bootstrap-table2-filter/dist/react-bootstrap-table2-filter.min.css";

export default function DataList() {
  const [userList, setUserList] = useState([]);
  const columns = [
    {
      dataField: "id",
      text: "ID",
    },
    {
      dataField: "name",
      text: "Name",
      sort: true,
      filter: textFilter(),
    },
    {
      dataField: "email",
      text: "Email",
      sort: true,
    },
    {
      dataField: "occupation",
      text: "Occupation",
      sort: true,
      filter: textFilter(),
    },
  ];

  const pagination = paginationFactory({
    page: 1,
    sizePerPage: 5,
    lastPageText: ">>>",
    firstPageText: "<<<",
    nextPageText: ">",
    showTotal: true,
    alwaysShowAllBtns: true,
    onPageChange: function (page, sizePerPage) {
      console.log("page", page);
      console.log("sizePerPage", sizePerPage);
    },
  });
  useEffect(() => {
    axios
      .get("https://ti-react-test.herokuapp.com/users")
      .then((response) => {
        console.log("response", response);
        setUserList(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  //const userData = userList.map((user) => {
  // return (
  // <tr key={user.id}>
  // <th scope="row">{user.id}</th>
  // <td>{user.name}</td>
  // <td>{user.email}</td>
  //  <td>{user.occupation}</td>
  // </tr>
  // );
  // });

  return (
    <div className="container">
      <h1>DataList</h1>
      {/*<table className="table my-4">
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Occupation</th>
          </tr>
        </thead>
        <tbody>{userData}</tbody>
  </table>*/}
      <BootStrapTable
        bootstrap4
        keyField="id"
        columns={columns}
        data={userList}
        pagination={pagination}
        filter={filterFactory()}
      />{" "}
    </div>
  );
}
