import "./App.css";
import AuthenticationJwt from "./components/AuthenticationJwt";

function App() {
  return (
    <div className="App">
      <AuthenticationJwt />
    </div>
  );
}

export default App;
