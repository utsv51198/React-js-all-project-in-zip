import axios from "axios";
import React, { useState } from "react";

export default function AuthenticationJwt() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [login, setLogin] = useState("");
  const [token, setToken] = useState("");

  const submitHandler = (e) => {
    const data = { email, password, login, token };
    e.preventDefault();
    axios
      .post("http://localhost:3000/Login/", data)
      .then((response) => {
        console.log("Response", response);
        localStorage.setItem(
          "login",
          JSON.stringify({
            login: true,
            token: response.token,
          })
        );
        setLogin({ login: true });
      })
      .catch((error) => {
        console.log("Error", error);
      });
  };
  return (
    <div>
      {" "}
      <h1>JWT Authentication</h1>
      {!login ? (
        <div className="container my-4">
          <input
            type="email"
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email"
            value={email}
          />
          <br />
          <br />
          <input
            type="password"
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            value={password}
          />
          <br />
          <br />
          <button className="btn btn-primary" onClick={submitHandler}>
            Login
          </button>
        </div>
      ) : (
        <div>
          <textarea></textarea>
          <button className="btn btn-primary">Post Data</button>
        </div>
      )}
    </div>
  );
}
