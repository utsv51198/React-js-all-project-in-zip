import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Activities from "./pages/Activities";
import Events from "./pages/Events";
import Explores from "./pages/Explores";
import Library from "./pages/Library";
import Offers from "./pages/Offers";

function App() {
  return (
    <>
      <Routes>
        <Route exact path="/" element={<Events />} />
        <Route exact path="/activities" element={<Activities />} />
        <Route exact path="/library" element={<Library />} />
        <Route exact path="/offers" element={<Offers />} />
        <Route exact path="/explore" element={<Explores />} />
      </Routes>
    </>
  );
}

export default App;
