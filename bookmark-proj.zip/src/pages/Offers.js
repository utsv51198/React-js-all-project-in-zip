import React from "react";
import Footer from "./Footer";
import Navbar from "./Navbar";
import { Link } from "react-router-dom";

export default function Offers() {
  return (
    <>
      <Navbar />
      {/* <!-- Mobile View Top Start --> */}
      <div className="mobile-gray-top d-none">
        <div className="container">
          <div className="row">
            <div className="d-flex align-items-center justify-content-between mob-mt-39">
              <div>
                <a href="bookmark.html">
                  <img
                    src="assets/images/768/arrow-left.png"
                    className=""
                    alt=""
                    width=""
                    height=""
                  />
                </a>
              </div>
              <div>
                <h4 className="mb-0">Bookmark</h4>
              </div>
              <div></div>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- Mobile View Top End --> */}
      <section className="mt-5 top-curve2 mob-brd-radius-0">
        <div className="container">
          <div className="row p-8">
            <div className="col-md-12">
              <h1 className="mt-5  mb-3 main-title d-m-none">Profile</h1>
            </div>
          </div>
        </div>
      </section>
      {/* <!-- Bookmark List Start --> */}
      <section className="dashboard">
        <div className="container">
          <div className="row p-8">
            <div className="col-md-2 d-m-none">
              <div className="sidebar">
                <ul>
                  <li>
                    <a href="profile.html">My Profile</a>
                  </li>
                  <li>
                    <a href="medx.html">My MedX</a>
                  </li>
                  <li>
                    <a href="internship.html">Internship</a>
                  </li>
                  <li>
                    <a href="booking.html">My Booking</a>
                  </li>
                  <li>
                    <a href="bookmark.html" className="active">
                      Bookmark
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col-md-10">
              <div className="dashboard-inner  ha-tab">
                <div className="top-head">
                  <a href="">
                    <img
                      src="assets/images/768/arrow-left.png"
                      className="mb-3 d-m-none"
                      alt=""
                      width=""
                      height=""
                    />
                  </a>
                </div>
                <div className="mob-pr-0 specialiry my-4 mob-mb-0 mob-mt-30 mob-pl-8">
                  <ul>
                    <li>
                      <Link to="/" className="">
                        Events
                      </Link>
                    </li>
                    <li>
                      <Link to="/activities" className="">
                        Activities
                      </Link>
                    </li>
                    <li>
                      <Link to="/library" className="">
                        {" "}
                        Library
                      </Link>
                    </li>
                    <li>
                      <Link to="/offers" className="active">
                        Offers
                      </Link>
                    </li>
                    <li>
                      <Link to="/explore" className="">
                        Explore
                      </Link>
                    </li>
                  </ul>
                </div>
                <div className="clearfix"></div>
                <div className="d-flex justify-content-between align-items-center">
                  <div>
                    <h3 className="title mb-0">Offer</h3>
                  </div>
                  <div>
                    <a href="" className="view-text d-none">
                      <span className="view-m">View More</span>
                      <span className="see-m">See All</span>{" "}
                      <img
                        src="assets/images/right-arrow.png"
                        alt="icon"
                        width="18"
                        height="18"
                        className="ml-2"
                      />
                    </a>
                  </div>
                </div>
                <div className="offer-list mt-4">
                  <div className="offer-block mb-3">
                    <div>
                      <img
                        src="assets/images/offer3.png"
                        className="w-100 brd-23"
                        alt=""
                        width=""
                        height=""
                      />
                    </div>
                    <div className="offer-content d-flex align-items-center justify-content-between">
                      <div>
                        <h5 className="mb-0">
                          {" "}
                          Different word 30% off on booking in this week
                        </h5>
                        <strong>16 - 30 Sep 2022</strong>
                      </div>
                      <div>
                        <span className="badge badge-orange">Course</span>
                      </div>
                    </div>
                  </div>
                  <div className="offer-block mb-3">
                    <div>
                      <img
                        src="assets/images/offer3.png"
                        className="w-100 brd-23"
                        alt=""
                        width=""
                        height=""
                      />
                    </div>
                    <div className="offer-content d-flex align-items-center justify-content-between">
                      <div>
                        <h5 className="mb-0"> Course 20% discount</h5>
                        <strong>16 - 30 Sep 2022</strong>
                      </div>
                      <div>
                        <span className="badge badge-orange">Course</span>
                      </div>
                    </div>
                  </div>
                  <div className="offer-block mb-3">
                    <div>
                      <img
                        src="assets/images/offer1.png"
                        className="w-100 brd-23"
                        alt=""
                        width=""
                        height=""
                      />
                    </div>
                    <div className="offer-content d-flex align-items-center justify-content-between">
                      <div>
                        <h5 className="mb-0">Chicken 50% discount</h5>
                        <strong>16 - 30 Sep 2022</strong>
                      </div>
                      <div>
                        <span className="badge badge-blue">Food</span>
                      </div>
                    </div>
                  </div>
                  <div className="offer-block mb-3">
                    <div>
                      <img
                        src="assets/images/offer3.png"
                        className="w-100 brd-23"
                        alt=""
                        width=""
                        height=""
                      />
                    </div>
                    <div className="offer-content d-flex align-items-center justify-content-between">
                      <div>
                        <h5 className="mb-0">
                          {" "}
                          Different word 30% off on booking in this week
                        </h5>
                        <strong>16 - 30 Sep 2022</strong>
                      </div>
                      <div>
                        <span className="badge badge-orange">Course</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="clearfix"></div>
              <div className="d-flex justify-content-between align-items-center d-none2">
                <div>
                  <h3 className="title mb-0">Service</h3>
                </div>
                <div>
                  <a href="" className="view-text d-none">
                    <span className="view-m">View More</span>
                    <span className="see-m">See All</span>{" "}
                    <img
                      src="assets/images/right-arrow.png"
                      alt="icon"
                      width="18"
                      height="18"
                      className="ml-2"
                    />
                  </a>
                </div>
              </div>
              <div className="service-list mt-4 d-none">
                <div className="service-block mb-3">
                  <a href="service-detail.html">
                    <div className="p-relative">
                      <img
                        src="assets/images/service1.png"
                        className="w-100 brd-23"
                        alt=""
                        width=""
                        height=""
                      />
                      <span className="badge badge-teal badge-top">Spa</span>
                    </div>

                    <div className="service-content d-flex align-items-center justify-content-between mt-3">
                      <div>
                        <h5 className="mb-0">
                          Product Name Product Name Product Name Product Name
                          Product Name Product Name{" "}
                        </h5>
                        <strong>
                          <img
                            src="assets/images/location-marker.png"
                            className="mr-2"
                            alt=""
                            width="13"
                            height=""
                          />{" "}
                          Bangkok Marriott Hotel Sukhumvit
                        </strong>
                      </div>
                      <div className="text-right">
                        <h6 className="mb-0">300~1,090</h6>
                        <small>THB</small>
                      </div>
                    </div>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
}
