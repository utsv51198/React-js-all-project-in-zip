import React from "react";
import { Link } from "react-router-dom";
import Footer from "./Footer";
import Navbar from "./Navbar";

export default function Activities() {
  return (
    <>
      <Navbar />
      {/* <!-- Mobile View Top Start --> */}
      <div className="mobile-gray-top d-none">
        <div className="container">
          <div className="row">
            <div className="d-flex align-items-center justify-content-between mob-mt-39">
              <div>
                <a href="bookmark.html">
                  <img
                    src="assets/images/768/arrow-left.png"
                    className=""
                    alt=""
                    width=""
                    height=""
                  />
                </a>
              </div>
              <div>
                <h4 className="mb-0">Bookmark</h4>
              </div>
              <div></div>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- Mobile View Top End --> */}

      <section className="mt-5 top-curve2 mob-brd-radius-0">
        <div className="container">
          <div className="row p-8">
            <div className="col-md-12">
              <h1 className="mt-5  mb-3 main-title d-m-none">Profile</h1>
            </div>
          </div>
        </div>
      </section>

      {/* <!-- Bookmark List Start --> */}
      <section className="dashboard">
        <div className="container">
          <div className="row p-8">
            <div className="col-md-2 d-m-none">
              <div className="sidebar">
                <ul>
                  <li>
                    <a href="profile.html">My Profile</a>
                  </li>
                  <li>
                    <a href="medx.html">My MedX</a>
                  </li>
                  <li>
                    <a href="internship.html">Internship</a>
                  </li>
                  <li>
                    <a href="booking.html">My Booking</a>
                  </li>
                  <li>
                    <a href="bookmark.html" className="active">
                      Bookmark
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col-md-10">
              <div className="dashboard-inner  ha-tab">
                <div className="top-head">
                  <a href="">
                    <img
                      src="assets/images/768/arrow-left.png"
                      className="mb-3 d-m-none"
                      alt=""
                      width=""
                      height=""
                    />
                  </a>
                </div>
                <div className="mob-pr-0 specialiry my-4 mob-mb-0 mob-mt-30 mob-pl-8">
                  <ul>
                    <li>
                      <Link to="/" className="">
                        Events
                      </Link>
                    </li>
                    <li>
                      <Link to="/activities" className="active">
                        Activities
                      </Link>
                    </li>
                    <li>
                      <Link to="/library" className="">
                        {" "}
                        Library
                      </Link>
                    </li>
                    <li>
                      <Link to="/offers" className="">
                        Offers
                      </Link>
                    </li>
                    <li>
                      <Link to="/explore" className="">
                        Explore
                      </Link>
                    </li>
                  </ul>
                </div>
                <div className="d-flex justify-content-between align-items-center">
                  <h3 className="title mb-0">Activities</h3>
                  <div>
                    <a href="cme-events.html" className="view-text d-none">
                      <span className="view-m">View More</span>
                      <span className="see-m">See All</span>{" "}
                      <img
                        src="assets/images/right-arrow.png"
                        alt="icon"
                        width="18"
                        height="18"
                        className="ml-2"
                      />
                    </a>
                  </div>
                </div>

                {/* <!-- Desktop Activities Listing Start --> */}
                <div
                  className="events-listing mt-4 d-m-none"
                  style={{ justifyContent: "space-between" }}
                >
                  <div className="event-item text-center">
                    <div className="position-relative main-img mb-2">
                      <a href="">
                        {" "}
                        <img
                          className="img-fluid mx-auto"
                          src="assets/images/image 16.png"
                          alt=""
                        />
                      </a>
                    </div>
                    <a href="">
                      <h4>Golden Week</h4>
                    </a>
                    <ul className="event-list">
                      <li>
                        <div>
                          <img
                            className="img-fluid"
                            src="assets/images/clock.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>16 Sep 2022</div>
                      </li>
                      <li>
                        <div>
                          <img
                            className="img-fluid "
                            src="assets/images/location-marker.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>Bangkok Marriott Hotel...</div>
                      </li>
                    </ul>
                  </div>
                  <div className="event-item text-center">
                    <div className="position-relative main-img mb-2">
                      <a href="">
                        {" "}
                        <img
                          className="img-fluid mx-auto"
                          src="assets/images/image 16.png"
                          alt=""
                        />
                      </a>
                    </div>
                    <a href="">
                      <h4>Golden Week</h4>
                    </a>
                    <ul className="event-list">
                      <li>
                        <div>
                          <img
                            className="img-fluid"
                            src="assets/images/clock.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>16 Sep 2022</div>
                      </li>
                      <li>
                        <div>
                          <img
                            className="img-fluid "
                            src="assets/images/location-marker.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>Bangkok Marriott Hotel...</div>
                      </li>
                    </ul>
                  </div>
                  <div className="event-item text-center">
                    <div className="position-relative main-img mb-2">
                      <a href="">
                        {" "}
                        <img
                          className="img-fluid mx-auto"
                          src="assets/images/image 16.png"
                          alt=""
                        />
                      </a>
                    </div>
                    <a href="">
                      <h4>Golden Week</h4>
                    </a>
                    <ul className="event-list">
                      <li>
                        <div>
                          <img
                            className="img-fluid"
                            src="assets/images/clock.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>16 Sep 2022</div>
                      </li>
                      <li>
                        <div>
                          <img
                            className="img-fluid "
                            src="assets/images/location-marker.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>Bangkok Marriott Hotel...</div>
                      </li>
                    </ul>
                  </div>
                  <div className="event-item text-center">
                    <div className="position-relative main-img mb-2">
                      <a href="">
                        <img
                          className="img-fluid mx-auto"
                          src="assets/images/image 15.png"
                          alt=""
                        />
                      </a>
                    </div>
                    <a href="">
                      <h4>Doctors without Borders</h4>
                    </a>
                    <ul className="event-list">
                      <li>
                        <div>
                          <img
                            className="img-fluid"
                            src="assets/images/clock.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>16 Sep 2022</div>
                      </li>
                      <li>
                        <div>
                          <img
                            className="img-fluid "
                            src="assets/images/location-marker.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>Online</div>
                      </li>
                    </ul>
                  </div>
                  <div className="event-item text-center">
                    <div className="position-relative main-img mb-2">
                      <a href="">
                        <img
                          className="img-fluid mx-auto"
                          src="assets/images/image 13.png"
                          alt=""
                        />
                      </a>
                    </div>
                    <a href="">
                      <h4>Dental Implants specialists in ...</h4>
                    </a>
                    <ul className="event-list">
                      <li>
                        <div>
                          <img
                            className="img-fluid"
                            src="assets/images/clock.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>16 Sep 2022</div>
                      </li>
                      <li>
                        <div>
                          <img
                            className="img-fluid "
                            src="assets/images/location-marker.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>Bangkok Marriott Hotel...</div>
                      </li>
                    </ul>
                  </div>
                  <div className="event-item text-center">
                    <div className="position-relative main-img mb-2">
                      <a href="">
                        {" "}
                        <img
                          className="img-fluid mx-auto"
                          src="assets/images/image 16.png"
                          alt=""
                        />
                      </a>
                    </div>
                    <a href="">
                      <h4>Golden Week</h4>
                    </a>
                    <ul className="event-list">
                      <li>
                        <div>
                          <img
                            className="img-fluid"
                            src="assets/images/clock.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>16 Sep 2022</div>
                      </li>
                      <li>
                        <div>
                          <img
                            className="img-fluid "
                            src="assets/images/location-marker.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>Bangkok Marriott Hotel...</div>
                      </li>
                    </ul>
                  </div>
                  <div className="event-item text-center">
                    <div className="position-relative main-img mb-2">
                      <a href="">
                        <img
                          className="img-fluid mx-auto"
                          src="assets/images/image 13.png"
                          alt=""
                        />
                      </a>
                    </div>
                    <a href="">
                      <h4>Dental Implants specialists in ...</h4>
                    </a>
                    <ul className="event-list">
                      <li>
                        <div>
                          <img
                            className="img-fluid"
                            src="assets/images/clock.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>16 Sep 2022</div>
                      </li>
                      <li>
                        <div>
                          <img
                            className="img-fluid "
                            src="assets/images/location-marker.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>Bangkok Marriott Hotel...</div>
                      </li>
                    </ul>
                  </div>
                  <div className="event-item text-center">
                    <div className="position-relative main-img mb-2">
                      <a href="">
                        {" "}
                        <img
                          className="img-fluid mx-auto"
                          src="assets/images/image 16.png"
                          alt=""
                        />
                      </a>
                    </div>
                    <a href="">
                      <h4>Golden Week</h4>
                    </a>
                    <ul className="event-list">
                      <li>
                        <div>
                          <img
                            className="img-fluid"
                            src="assets/images/clock.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>16 Sep 2022</div>
                      </li>
                      <li>
                        <div>
                          <img
                            className="img-fluid "
                            src="assets/images/location-marker.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>Bangkok Marriott Hotel...</div>
                      </li>
                    </ul>
                  </div>
                </div>
                {/* <!-- Desktop Activities Listing End --> */}

                {/* <!-- Mobile Activities carousel Start --> */}
                <div className="owl-carousel events-carousel mt-4 mob-mb-5  d-flex flex-wrap">
                  <div className="event-item text-center col-6 col-sm-6 col-md-4">
                    <div className="position-relative main-img mb-2">
                      <a href="">
                        <a href="">
                          <img
                            className="img-fluid mx-auto"
                            src="assets/images/image 15.png"
                            alt=""
                          />
                        </a>
                      </a>
                      <span>5 Credits</span>
                      <div className="timer">
                        <div className="hours"></div>
                        <div className="minutes"></div>
                        <div className="seconds"></div>
                      </div>
                    </div>
                    <a href="">
                      <h4>Doctors without Borders</h4>
                    </a>
                    <ul className="event-list">
                      <li>
                        <div>
                          <img
                            className="img-fluid"
                            src="assets/images/clock.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>16 Sep 2022</div>
                      </li>
                      <li>
                        <div>
                          <img
                            className="img-fluid "
                            src="assets/images/location-marker.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>Online</div>
                      </li>
                    </ul>
                  </div>
                  <div className="event-item text-center col-6 col-sm-6 col-md-4">
                    <div className="position-relative main-img mb-2">
                      <a href="">
                        <a href="">
                          <img
                            className="img-fluid mx-auto"
                            src="assets/images/image 15.png"
                            alt=""
                          />
                        </a>
                      </a>
                      <span>5 Credits</span>
                      <div className="timer">
                        <div className="hours"></div>
                        <div className="minutes"></div>
                        <div className="seconds"></div>
                      </div>
                    </div>
                    <a href="">
                      <h4>Doctors without Borders</h4>
                    </a>
                    <ul className="event-list">
                      <li>
                        <div>
                          <img
                            className="img-fluid"
                            src="assets/images/clock.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>16 Sep 2022</div>
                      </li>
                      <li>
                        <div>
                          <img
                            className="img-fluid "
                            src="assets/images/location-marker.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>Online</div>
                      </li>
                    </ul>
                  </div>
                  <div className="event-item text-center col-6 col-sm-6 col-md-4">
                    <div className="position-relative main-img mb-2">
                      <a href="">
                        <a href="">
                          <img
                            className="img-fluid mx-auto"
                            src="assets/images/image 15.png"
                            alt=""
                          />
                        </a>
                      </a>
                      <span>5 Credits</span>
                      <div className="timer">
                        <div className="hours"></div>
                        <div className="minutes"></div>
                        <div className="seconds"></div>
                      </div>
                    </div>
                    <a href="">
                      <h4>Doctors without Borders</h4>
                    </a>
                    <ul className="event-list">
                      <li>
                        <div>
                          <img
                            className="img-fluid"
                            src="assets/images/clock.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>16 Sep 2022</div>
                      </li>
                      <li>
                        <div>
                          <img
                            className="img-fluid "
                            src="assets/images/location-marker.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>Online</div>
                      </li>
                    </ul>
                  </div>
                  <div className="event-item text-center col-6 col-sm-6 col-md-4">
                    <div className="position-relative main-img mb-2">
                      <a href="">
                        <img
                          className="img-fluid mx-auto"
                          src="assets/images/image 13.png"
                          alt=""
                        />
                      </a>
                      <span>5 Credits</span>
                    </div>
                    <a href="">
                      <h4>Dental Implants specialists in ...</h4>
                    </a>
                    <ul className="event-list">
                      <li>
                        <div>
                          <img
                            className="img-fluid"
                            src="assets/images/clock.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>16 Sep 2022</div>
                      </li>
                      <li>
                        <div>
                          <img
                            className="img-fluid "
                            src="assets/images/location-marker.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>Bangkok Marriott Hotel...</div>
                      </li>
                    </ul>
                  </div>
                  <div className="event-item text-center col-6 col-sm-6 col-md-4">
                    <div className="position-relative main-img mb-2">
                      <a href="">
                        <img
                          className="img-fluid mx-auto"
                          src="assets/images/image 16.png"
                          alt=""
                        />
                      </a>
                      <span>5 Credits</span>
                    </div>
                    <a href="">
                      <h4>Golden Week</h4>
                    </a>
                    <ul className="event-list">
                      <li>
                        <div>
                          <img
                            className="img-fluid"
                            src="assets/images/clock.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>16 Sep 2022</div>
                      </li>
                      <li>
                        <div>
                          <img
                            className="img-fluid "
                            src="assets/images/location-marker.png"
                            alt=""
                            width="12"
                            height="12"
                          />
                        </div>
                        <div>Bangkok Marriott Hotel...</div>
                      </li>
                    </ul>
                  </div>
                </div>
                {/* <!-- Mobile Event carousel End --> */}
              </div>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
}
