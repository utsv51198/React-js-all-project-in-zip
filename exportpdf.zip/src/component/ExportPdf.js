import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import { useReactToPrint } from "react-to-print";

export const ExportPdf = () => {
  const [exportData, setExportData] = useState([]);
  const componentRef = useRef();
  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
    documentTitle: "myPdf",
  });
  useEffect(() => {
    const getData = async () => {
      const { data } = await axios
        .get(`https://fakestoreapi.com/products`)
        .catch((err) => {
          console.log("Error", err);
        });
      console.log(data);
      setExportData(data);
    };
    getData();
  }, []);

  return (
    <>
      <React.Fragment>
        <div className="container">
          <h4 className="mt-3 mb-3">Export Data in PDF using React Js </h4>
          <button className="btn btn-info" onClick={handlePrint}>
            Print Here
          </button>
          <div
            className="container"
            ref={componentRef}
            style={{ width: "100%", height: window.innerHeight }}
          >
            <div className="row">
              <div className="col-sm-8">
                <h4 className="mt-3 mb-3">
                  Export Data in PDF using React Js{" "}
                </h4>

                <table className="table table-bordered my-3" id="table-to-xls">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Name</th>
                      <th>Price</th>
                      <th>Category</th>
                      <th>Description</th>
                    </tr>
                  </thead>
                  <tbody>
                    <>
                      {exportData.map((data) => (
                        <tr key={data.id}>
                          <td>{data.id}</td>
                          <td>{data.title}</td>
                          <td>${data.price}</td>
                          <td>{data.category}</td>
                          <td>{data.description}</td>
                        </tr>
                      ))}
                    </>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    </>
  );
};
