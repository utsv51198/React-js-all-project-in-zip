import "./App.css";
import { ExportPdf } from "./component/ExportPdf";

function App() {
  return (
    <div className="App">
      <ExportPdf />
    </div>
  );
}

export default App;
