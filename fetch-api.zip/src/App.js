import React from 'react'
import FetchApi from './components/FetchApi'

function App() {
  return <div><FetchApi/></div>;
}

export default App