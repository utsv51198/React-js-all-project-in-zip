import "./App.css";
import { ImportPdfData } from "./components/ImportPdfData";

function App() {
  return (
    <div className="App">
      <ImportPdfData />
    </div>
  );
}

export default App;
