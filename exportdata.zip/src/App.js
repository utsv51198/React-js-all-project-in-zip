import "./App.css";
import { ExportData } from "./components/ExportData";

function App() {
  return (
    <div className="App">
      <ExportData />
    </div>
  );
}

export default App;
