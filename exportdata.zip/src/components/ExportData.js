import React, { useState, useEffect } from "react";
import axios from "axios";
import { Container, Table } from "react-bootstrap";
import { CSVLink } from "react-csv";

export const ExportData = () => {
  const [exportData, setExportData] = useState([]);
  useEffect(() => {
    const getData = async () => {
      const { data } = await axios
        .get(`https://fakestoreapi.com/products`)
        .catch((err) => {
          console.log("Error", err);
        });
      console.log(data);
      setExportData(data);
    };
    getData();
  }, []);

  return (
    <React.Fragment>
      <Container>
        <div className="row">
          <div className="col-sm-8">
            <h4 className="mt-3 mb-3">Export Data in Excel using React Js </h4>

            <CSVLink
              data={exportData}
              filename="RegisterUserData"
              className="btn btn-success mb-3"
            >
              Export User Data
            </CSVLink>
            <Table className="table table-bordered">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Name</th>
                  <th>Price</th>
                  <th>Category</th>
                  <th>Description</th>
                </tr>
              </thead>
              <tbody>
                <>
                  {exportData.map((data) => (
                    <tr key={data.id}>
                      <td>{data.id}</td>
                      <td>{data.title}</td>
                      <td>{data.price}</td>
                      <td>{data.category}</td>
                      <td>{data.description}</td>
                    </tr>
                  ))}
                </>
              </tbody>
            </Table>
          </div>
        </div>
      </Container>
    </React.Fragment>
  );
};
