import React from "react";

export default function Link() {
  return <div>Link</div>;
}
