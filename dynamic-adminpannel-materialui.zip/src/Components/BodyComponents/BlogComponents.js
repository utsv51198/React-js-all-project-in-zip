import React from "react";

export default function BlogComponents() {
  return <div>BlogComponents</div>;
}
