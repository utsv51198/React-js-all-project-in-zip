import React from "react";
import {
  Box,
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Hidden,
} from "@material-ui/core";
import Profile from "./Navtabs/Profile";
import Notification from "./Navtabs/Notification";
import Messages from "./Navtabs/Messages";
import { useStyles } from "./HeaderStyle";
import MenuIcon from "@mui/icons-material/Menu";

export default function NavBar({ handleDrawerOpen }) {
  const classes = useStyles();
  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="fixed">
        <Toolbar className={classes.toolbar}>
          <Typography variant="h6" className={classes.logo}>
            PeaFowlSoft
          </Typography>
          <Hidden smDown>
            <Box style={{ display: "flex" }}>
              <Notification />
              <Messages />
              <Profile />
            </Box>
          </Hidden>
          <Hidden mdUp>
            <IconButton color="inherit" onClick={handleDrawerOpen}>
              <MenuIcon />
            </IconButton>
          </Hidden>
        </Toolbar>
      </AppBar>
    </Box>
  );
}
