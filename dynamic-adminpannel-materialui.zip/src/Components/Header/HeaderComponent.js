import React, { useState } from "react";
import { useStyles } from "./HeaderStyle";
import NavBar from "./NavBar";
import Sidenav from "./Sidenav";
import { Routes, Route } from "react-router-dom";
import Link from "../BodyComponents/Link";
import { Box } from "@mui/system";
import Dashbored from "../BodyComponents/Dashbored/Dashbored";
import Notification from "../BodyComponents/Notification";
import BlogComponents from "../BodyComponents/BlogComponents";
import Logout from "../BodyComponents/Logout";

export default function HeaderComponent() {
  const classes = useStyles();
  const [mobileOpen, setMobileOpen] = useState(false);
  const handleDrawerOpen = () => {
    setMobileOpen(!mobileOpen);
  };
  const handleDrawerClose = () => {
    setMobileOpen(false);
  };
  return (
    <div>
      <NavBar handleDrawerOpen={handleDrawerOpen} />
      <Sidenav
        mobileOpen={mobileOpen}
        handleDrawerOpen={handleDrawerOpen}
        handleDrawerClose={handleDrawerClose}
      />
      {/* // registerian our routes  */}
      <Box className={classes.wrapper}>
        <Routes>
          {/* <Route exact path="/blog" render={() => <BlogComponent />} />*/}
          <Route exact path="/blog" element={<BlogComponents />} />
          <Route exact path="/link" element={<Link />} />
          <Route exact path="/notification" element={<Notification />} />
          <Route exact path="/logout" element={<Logout />} />
          <Route exact path="/" element={<Dashbored />} />
        </Routes>
      </Box>
    </div>
  );
}
