import { request as https } from "./request";

export const GetPost = ({ limit }) => {
  return https.get(`https://reqres.in/api/users?limit=${limit}`);
};

export const GetUser = ({ limit }) => {
  return https.get(`https://reqres.in/api/users?limit=${limit}`);
};
