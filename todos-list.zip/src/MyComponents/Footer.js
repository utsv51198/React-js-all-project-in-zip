import React from 'react'

export const Footer = () => {
  return (
      <div className='bg-dark text-light fixed-bottom py-3'>
      <p className='text-center'>  Copyright &copy; MyTodosList.com</p>
    </div>
  )
}
