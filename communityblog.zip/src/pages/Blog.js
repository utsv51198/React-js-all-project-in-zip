import React from "react";
import Footer from "./Footer";
import Navbar from "./Navbar";
import { Link } from "react-router-dom";

export default function Blog() {
  return (
    <>
      <Navbar />
      {/* <!-- Mobile View Top Start --> */}
      <div className="mobile-top d-none">
        <div className="container">
          <div className="row">
            <div className="d-flex align-items-center justify-content-between">
              <div>
                <h4>Community</h4>
              </div>
              <div>
                <ul className="d-flex align-items-center justify-content-between">
                  <li>
                    <a href="notifications.html">
                      <img
                        src="assets/images/768/bell.png"
                        className=""
                        alt=""
                        width=""
                        height=""
                      />
                    </a>
                  </li>
                  <li>
                    <a href="profile.html">
                      <img
                        src="assets/images/Ellipse 83.png"
                        className="img-rounded"
                        alt=""
                        width="50"
                        height=""
                      />
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- Mobile View Top End --> */}

      {/* <!-- Mobile Bottom Menu Start --> */}
      <div className="d-none mob-menu bg-f8">
        <ul className="d-flex align-items-center justify-content-between">
          <li>
            <a href="index.html">
              <img
                src="assets/images/768/icon1.png"
                className=""
                width=""
                height=""
              />
            </a>
          </li>
          <li>
            <a href="education.html">
              <img
                src="assets/images/768/icon2.png"
                className=""
                width=""
                height=""
              />
            </a>
          </li>
          <li>
            <a href="community.html">
              <img
                src="assets/images/768/icon3.png"
                className="active"
                width=""
                height=""
              />
            </a>
          </li>
          <li>
            <a href="offer.html">
              <img
                src="assets/images/768/icon4.png"
                className=""
                width=""
                height=""
              />
            </a>
          </li>
          <li>
            <a href="medx.html">
              <img
                src="assets/images/768/icon5.png"
                className=""
                width=""
                height=""
              />
            </a>
          </li>
        </ul>
      </div>
      {/* <!-- Mobile Bottom Menu End --> */}

      <section className="pt-3 top-curve">
        <div className="container">
          <div className="row px-10">
            <div className="col-md-12">
              <h1 className="mt-5 mb-4 main-title d-m-none">Community</h1>
            </div>
            <div className="col-md-12">
              <div className="top-links d-none">
                <ul>
                  <li>
                    <a href="community.html" className="">
                      In focus
                    </a>
                  </li>
                  <li>
                    <a href="news.html" className="">
                      News
                    </a>
                  </li>
                  <li>
                    <a href="blog.html" className="active">
                      Blog
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* <!-- Carousel Start --> */}
      <section className="pt-2 d-none">
        <div className="container p-0 carousel-p">
          <div className="row">
            <div id="demo" className="carousel slide" data-bs-ride="carousel">
              {/* <!-- Indicators/dots --> */}
              <div className="carousel-indicators">
                <button
                  type="button"
                  data-bs-target="#demo"
                  data-bs-slide-to="0"
                  className="active"
                ></button>
                <button
                  type="button"
                  data-bs-target="#demo"
                  data-bs-slide-to="1"
                ></button>
                <button
                  type="button"
                  data-bs-target="#demo"
                  data-bs-slide-to="2"
                ></button>
                <button
                  type="button"
                  data-bs-target="#demo"
                  data-bs-slide-to="3"
                ></button>
              </div>

              <div className="carousel-inner">
                <div className="carousel-item active">
                  <img
                    className="w-100"
                    src="assets/images/community-banner.png"
                    alt="Image"
                  />
                </div>
                <div className="carousel-item">
                  <img
                    className="w-100"
                    src="assets/images/community-banner.png"
                    alt="Image"
                  />
                </div>
                <div className="carousel-item">
                  <img
                    className="w-100"
                    src="assets/images/community-banner.png"
                    alt="Image"
                  />
                </div>
                <div className="carousel-item">
                  <img
                    className="w-100"
                    src="assets/images/community-banner.png"
                    alt="Image"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* <!-- Carousel End --> */}

      {/* <!-- CME Events Start --> */}
      <section className="community pb-3 mob-pt-1 mob-mt-m-35 mob-pb-0">
        <div className="container p-0">
          <div className="row">
            <div className="col-md-12 px-30  mob-px-30">
              <ul className="nav nav-tabs d-m-none" id="myTab" role="tablist">
                <li className="nav-item" role="presentation">
                  <button
                    className="nav-link"
                    id="focus-tab"
                    onclick="window.location.href = 'community.html'"
                  >
                    In Focus
                  </button>
                </li>
                <li className="nav-item" role="presentation">
                  <button
                    className="nav-link"
                    id="news-tab"
                    onclick="window.location.href = 'news.html'"
                  >
                    News
                  </button>
                </li>
                <li className="nav-item" role="presentation">
                  <button
                    className="nav-link active"
                    id="blog-tab"
                    data-bs-toggle="tab"
                    data-bs-target="#news"
                    type="button"
                    role="tab"
                    aria-controls="blog"
                    aria-selected="false"
                  >
                    Blog
                  </button>
                </li>
              </ul>
              <div className="tab-content mob-mb-30 clearfix" id="myTabContent">
                <div
                  className="tab-pane fade show active"
                  id="blog"
                  role="tabpanel"
                  aria-labelledby="blog-tab"
                >
                  <div className="row">
                    <div className="col-md-10 bg-m-white">
                      <div className="bg-gray mb-3">
                        <div className="d-flex align-items-center">
                          <div>
                            <img
                              src="assets/images/Ellipse 2.png"
                              className="rounded"
                              alt=""
                              width="40"
                              height="40"
                            />
                          </div>
                          <div className="ml-1">
                            <h5 className="mb-0">Kittiya Yuthasastrkosol</h5>
                            <span>1 day ago</span>
                          </div>
                        </div>
                        <div className="pl-55">
                          <h3>Doctors without borders in the future</h3>
                          <p className="desc">
                            Lorem Ipsum is simply dummy text of the printing and
                            typesetting industry. Lorem Ipsum has been the
                            industry's standard dummy text ever since the 1500s,
                            when an unknown printer took a galley of type and
                            scrambled it to make a type specia...
                          </p>
                          <Link to="/blog-detalis" className="view-text2">
                            Read More
                          </Link>
                          <div className="slide-gallery my-3">
                            <div className="d-flex column-list">
                              <div className="column">
                                <img
                                  className="demo cursor w-100"
                                  src="assets/images/image 92.png"
                                  alt=""
                                />
                              </div>
                              <div className="column">
                                <img
                                  className="demo cursor w-100"
                                  src="assets/images/image 92.png"
                                  alt=""
                                />
                              </div>
                              <div className="column">
                                <img
                                  className="demo cursor w-100"
                                  src="assets/images/image 92.png"
                                  alt=""
                                />
                              </div>
                              <div className="column">
                                <img
                                  className="demo cursor w-100"
                                  src="assets/images/image 92.png"
                                  alt=""
                                />
                              </div>
                              <div className="column">
                                <img
                                  className="demo cursor w-100"
                                  src="assets/images/image 92.png"
                                  alt=""
                                />
                              </div>
                              <div className="column">
                                <img
                                  className="demo cursor w-100"
                                  src="assets/images/image 92.png"
                                  alt=""
                                />
                                <div className="overlay">
                                  <span className="image-count">+20</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="bottom-block pt-3 mt-3 d-flex align-items-center justify-content-between pl-55">
                          <div>
                            <ul className="d-flex m-0 p-0 image-list">
                              <li>
                                <a href="">
                                  <img
                                    src="assets/images/avatar (1).png"
                                    className="rounded"
                                    alt=""
                                    width="35"
                                    height="35"
                                  />
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <img
                                    src="assets/images/avatar (2).png"
                                    className="rounded"
                                    alt=""
                                    width="35"
                                    height="35"
                                  />
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <img
                                    src="assets/images/avatar (1).png"
                                    className="rounded"
                                    alt=""
                                    width="35"
                                    height="35"
                                  />
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <img
                                    src="assets/images/avatar2.png"
                                    className="rounded"
                                    alt=""
                                    width="35"
                                    height="35"
                                  />
                                  <span className="image-count">+2</span>
                                </a>
                              </li>
                            </ul>
                          </div>
                          <div>
                            <a href="" className="text-cl">
                              21 Comments
                            </a>
                            <a href="" className="text-cl">
                              27 Likes
                            </a>
                          </div>
                        </div>
                      </div>
                      <div className="bg-gray mb-3">
                        <div className="d-flex align-items-center">
                          <div>
                            <img
                              src="assets/images/Ellipse 2.png"
                              className="rounded"
                              alt=""
                              width="40"
                              height="40"
                            />
                          </div>
                          <div className="ml-1">
                            <h5 className="mb-0">Kittiya Yuthasastrkosol</h5>
                            <span>1 day ago</span>
                          </div>
                        </div>
                        <div className="pl-55">
                          <h3>Doctors without borders in the future</h3>
                          <p className="desc">
                            Lorem Ipsum is simply dummy text of the printing and
                            typesetting industry. Lorem Ipsum has been the
                            industry's standard dummy text ever since the 1500s,
                            when an unknown printer took a galley of type and
                            scrambled it to make a type specia...
                          </p>
                          <Link to="/blog-detalis" className="view-text2">
                            Read More
                          </Link>
                        </div>

                        <div className="bottom-block pt-3 mt-3 d-flex align-items-center justify-content-between pl-55">
                          <div>
                            <ul className="d-flex m-0 p-0 image-list">
                              <li>
                                <a href="">
                                  <img
                                    src="assets/images/avatar (1).png"
                                    className="rounded"
                                    alt=""
                                    width="35"
                                    height="35"
                                  />
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <img
                                    src="assets/images/avatar (2).png"
                                    className="rounded"
                                    alt=""
                                    width="35"
                                    height="35"
                                  />
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <img
                                    src="assets/images/avatar (1).png"
                                    className="rounded"
                                    alt=""
                                    width="35"
                                    height="35"
                                  />
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <img
                                    src="assets/images/avatar2.png"
                                    className="rounded"
                                    alt=""
                                    width="35"
                                    height="35"
                                  />
                                  <span className="image-count">+2</span>
                                </a>
                              </li>
                            </ul>
                          </div>
                          <div>
                            <a href="" className="text-cl">
                              21 Comments
                            </a>
                            <a href="" className="text-cl">
                              27 Likes
                            </a>
                          </div>
                        </div>
                      </div>
                      <div className="bg-gray mb-3">
                        <div className="d-flex align-items-center">
                          <div>
                            <img
                              src="assets/images/Ellipse 2.png"
                              className="rounded"
                              alt=""
                              width="40"
                              height="40"
                            />
                          </div>
                          <div className="ml-1">
                            <h5 className="mb-0">Kittiya Yuthasastrkosol</h5>
                            <span>1 day ago</span>
                          </div>
                        </div>
                        <div className="pl-55">
                          <h3>Doctors without borders in the future</h3>
                          <p className="desc">
                            Lorem Ipsum is simply dummy text of the printing and
                            typesetting industry. Lorem Ipsum has been the
                            industry's standard dummy text ever since the 1500s,
                            when an unknown printer took a galley of type and
                            scrambled it to make a type specia...
                          </p>
                          <Link to="/blog-detalis" className="view-text2">
                            Read More
                          </Link>
                          <div className="slide-gallery my-3">
                            <img
                              src="assets/images/image 92.png"
                              className="w-100 img-rouded-5"
                            />
                          </div>
                        </div>

                        <div className="bottom-block pt-3 mt-3 d-flex align-items-center justify-content-between pl-55">
                          <div>
                            <ul className="d-flex m-0 p-0 image-list">
                              <li>
                                <a href="">
                                  <img
                                    src="assets/images/avatar (1).png"
                                    className="rounded"
                                    alt=""
                                    width="35"
                                    height="35"
                                  />
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <img
                                    src="assets/images/avatar (2).png"
                                    className="rounded"
                                    alt=""
                                    width="35"
                                    height="35"
                                  />
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <img
                                    src="assets/images/avatar (1).png"
                                    className="rounded"
                                    alt=""
                                    width="35"
                                    height="35"
                                  />
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <img
                                    src="assets/images/avatar2.png"
                                    className="rounded"
                                    alt=""
                                    width="35"
                                    height="35"
                                  />
                                  <span className="image-count">+2</span>
                                </a>
                              </li>
                            </ul>
                          </div>
                          <div>
                            <a href="" className="text-cl">
                              21 Comments
                            </a>
                            <a href="" className="text-cl">
                              27 Likes
                            </a>
                          </div>
                        </div>
                      </div>
                      <div className="bg-gray mb-3">
                        <div className="d-flex align-items-center">
                          <div>
                            <img
                              src="assets/images/Ellipse 2.png"
                              className="rounded"
                              alt=""
                              width="40"
                              height="40"
                            />
                          </div>
                          <div className="ml-1">
                            <h5 className="mb-0">Kittiya Yuthasastrkosol</h5>
                            <span>1 day ago</span>
                          </div>
                        </div>
                        <div className="pl-55">
                          <h3>Doctors without borders in the future</h3>
                          <p className="desc">
                            Lorem Ipsum is simply dummy text of the printing and
                            typesetting industry. Lorem Ipsum has been the
                            industry's standard dummy text ever since the 1500s,
                            when an unknown printer took a galley of type and
                            scrambled it to make a type specia...
                          </p>
                          <Link to="/blog-detalis" className="view-text2">
                            Read More
                          </Link>
                          <div className="slide-gallery my-3">
                            <div className="d-flex column-list">
                              <div className="column">
                                <img
                                  className="demo cursor w-100"
                                  src="assets/images/image 92.png"
                                  alt=""
                                />
                              </div>
                              <div className="column">
                                <img
                                  className="demo cursor w-100"
                                  src="assets/images/image 92.png"
                                  alt=""
                                />
                              </div>
                              <div className="column">
                                <img
                                  className="demo cursor w-100"
                                  src="assets/images/image 92.png"
                                  alt=""
                                />
                              </div>
                              <div className="column">
                                <img
                                  className="demo cursor w-100"
                                  src="assets/images/image 92.png"
                                  alt=""
                                />
                              </div>
                              <div className="column">
                                <img
                                  className="demo cursor w-100"
                                  src="assets/images/image 92.png"
                                  alt=""
                                />
                              </div>
                              <div className="column">
                                <img
                                  className="demo cursor w-100"
                                  src="assets/images/image 92.png"
                                  alt=""
                                />
                                <div className="overlay">
                                  <span className="image-count">+20</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="bottom-block pt-3 mt-3 d-flex align-items-center justify-content-between pl-55">
                          <div>
                            <ul className="d-flex m-0 p-0 image-list">
                              <li>
                                <a href="">
                                  <img
                                    src="assets/images/avatar (1).png"
                                    className="rounded"
                                    alt=""
                                    width="35"
                                    height="35"
                                  />
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <img
                                    src="assets/images/avatar (2).png"
                                    className="rounded"
                                    alt=""
                                    width="35"
                                    height="35"
                                  />
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <img
                                    src="assets/images/avatar (1).png"
                                    className="rounded"
                                    alt=""
                                    width="35"
                                    height="35"
                                  />
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <img
                                    src="assets/images/avatar2.png"
                                    className="rounded"
                                    alt=""
                                    width="35"
                                    height="35"
                                  />
                                  <span className="image-count">+2</span>
                                </a>
                              </li>
                            </ul>
                          </div>
                          <div>
                            <a href="" className="text-cl">
                              21 Comments
                            </a>
                            <a href="" className="text-cl">
                              27 Likes
                            </a>
                          </div>
                        </div>
                      </div>
                      <div className="bg-gray mb-3">
                        <div className="d-flex align-items-center">
                          <div>
                            <img
                              src="assets/images/Ellipse 2.png"
                              className="rounded"
                              alt=""
                              width="40"
                              height="40"
                            />
                          </div>
                          <div className="ml-1">
                            <h5 className="mb-0">Kittiya Yuthasastrkosol</h5>
                            <span>1 day ago</span>
                          </div>
                        </div>
                        <div className="pl-55">
                          <h3>Doctors without borders in the future</h3>
                          <p className="desc">
                            Lorem Ipsum is simply dummy text of the printing and
                            typesetting industry. Lorem Ipsum has been the
                            industry's standard dummy text ever since the 1500s,
                            when an unknown printer took a galley of type and
                            scrambled it to make a type specia...
                          </p>
                          <Link to="/blog-detalis" className="view-text2">
                            Read More
                          </Link>
                        </div>

                        <div className="bottom-block pt-3 mt-3 d-flex align-items-center justify-content-between pl-55">
                          <div>
                            <ul className="d-flex m-0 p-0 image-list">
                              <li>
                                <a href="">
                                  <img
                                    src="assets/images/avatar (1).png"
                                    className="rounded"
                                    alt=""
                                    width="35"
                                    height="35"
                                  />
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <img
                                    src="assets/images/avatar (2).png"
                                    className="rounded"
                                    alt=""
                                    width="35"
                                    height="35"
                                  />
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <img
                                    src="assets/images/avatar (1).png"
                                    className="rounded"
                                    alt=""
                                    width="35"
                                    height="35"
                                  />
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <img
                                    src="assets/images/avatar2.png"
                                    className="rounded"
                                    alt=""
                                    width="35"
                                    height="35"
                                  />
                                  <span className="image-count">+2</span>
                                </a>
                              </li>
                            </ul>
                          </div>
                          <div>
                            <a href="" className="text-cl">
                              21 Comments
                            </a>
                            <a href="" className="text-cl">
                              27 Likes
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-2 d-m-none">
                      <div className="img-block mb-3">
                        <img
                          src="assets/images/image 83.png"
                          className="img-fluid"
                          alt=""
                          width=""
                          height=""
                        />
                      </div>
                      <div className="img-block mb-3">
                        <img
                          src="assets/images/image 110.png"
                          className="img-fluid"
                          alt=""
                          width=""
                          height=""
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* <!-- CME Events End --> */}
      <Footer />
    </>
  );
}
