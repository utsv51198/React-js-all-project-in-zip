import React from "react";
import Footer from "./Footer";
import Navbar from "./Navbar";
import { Link } from "react-router-dom";

export default function BlogDetalis() {
  return (
    <>
      <Navbar />
      <section className="pt-3">
        <div className="container">
          <div className="row px-10">
            <div className="col-md-12">
              <h1 className="mt-5 mb-4 main-title d-m-none">Community</h1>
            </div>
          </div>
        </div>
      </section>

      {/* <!-- Blog Detail Start --> */}
      <section className="community pb-3 mob-pt-1 mob-mt-m-35 mob-pb-0">
        <div className="container p-0">
          <div className="row">
            <div className="col-md-12 px-30">
              <ul className="nav nav-tabs d-m-none" id="myTab" role="tablist">
                <li className="nav-item" role="presentation">
                  <button
                    className="nav-link"
                    id="focus-tab"
                    onclick="window.location.href = 'community.html'"
                  >
                    In Focus
                  </button>
                </li>
                <li className="nav-item" role="presentation">
                  <button
                    className="nav-link"
                    id="news-tab"
                    onclick="window.location.href = 'news.html'"
                  >
                    News
                  </button>
                </li>
                <li className="nav-item" role="presentation">
                  <button
                    className="nav-link active"
                    id="blog-tab"
                    data-bs-toggle="tab"
                    data-bs-target="#news"
                    type="button"
                    role="tab"
                    aria-controls="blog"
                    aria-selected="false"
                  >
                    Blog
                  </button>
                </li>
              </ul>
              <div className="tab-content mob-mb-30 clearfix" id="myTabContent">
                <div
                  className="tab-pane fade show active blog-d"
                  id="blog"
                  role="tabpanel"
                  aria-labelledby="blog-tab"
                >
                  <div className="row">
                    <div className="col-md-10">
                      <img
                        src="assets/images/768/top-gray-circle.png"
                        className="d-none top-circle"
                        alt=""
                        width=""
                        height=""
                      />
                      <div className="bg-gray focus-detail">
                        <div className="mb-3">
                          <Link to="/">
                            <img
                              src="assets/images/left-arrow.png"
                              className=""
                              alt=""
                              width=""
                              height=""
                            />
                          </Link>
                        </div>
                        <div className="px-4">
                          <div className="d-flex align-items-center">
                            <div>
                              <img
                                src="assets/images/Ellipse 2.png"
                                className="rounded"
                                alt=""
                                width="40"
                                height="40"
                              />
                            </div>
                            <div className="ml-1">
                              <h5 className="mb-0">Kittiya Yuthasastrkosol</h5>
                              <span>1 day ago</span>
                            </div>
                          </div>
                          <h3 className="mt-2">
                            Doctors without borders in the future
                          </h3>
                          <p className="desc mb-3">
                            Lorem Ipsum is simply dummy text of the printing and
                            typesetting industry. Lorem Ipsum has been the
                            industry's standard dummy text ever since the 1500s,
                            when an unknown printer took a galley of type and
                            scrambled it to make a type specimen book. It has
                            survived not only five centuries, but also the leap
                            into electronic typesetting, remaining essentially
                            unchanged. It was popularised in the 1960s with the
                            release of Letraset sheets containing Lorem Ipsum
                            passages, and more recently with desktop publishing
                            software like Aldus PageMaker including versions of
                            Lorem Ipsum.
                          </p>
                          <div className="specialiry sp-bg mb-3">
                            <ul>
                              <li>
                                <a href="" className="">
                                  Cardiology
                                </a>
                              </li>
                              <li>
                                <a href="" className="">
                                  Oncology
                                </a>
                              </li>
                            </ul>
                          </div>
                          <div className="slide-gallery my-3">
                            <div className="d-flex column-list">
                              <div className="column">
                                <img
                                  className="demo cursor w-100"
                                  src="assets/images/image 92.png"
                                  alt=""
                                />
                              </div>
                              <div className="column">
                                <img
                                  className="demo cursor w-100"
                                  src="assets/images/image 92.png"
                                  alt=""
                                />
                              </div>
                              <div className="column">
                                <img
                                  className="demo cursor w-100"
                                  src="assets/images/image 92.png"
                                  alt=""
                                />
                              </div>
                              <div className="column">
                                <img
                                  className="demo cursor w-100"
                                  src="assets/images/image 92.png"
                                  alt=""
                                />
                              </div>
                              <div className="column">
                                <img
                                  className="demo cursor w-100"
                                  src="assets/images/image 92.png"
                                  alt=""
                                />
                              </div>
                              <div className="column">
                                <img
                                  className="demo cursor w-100"
                                  src="assets/images/image 92.png"
                                  alt=""
                                />
                                <div className="overlay">
                                  <span className="image-count">+20</span>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="pt-3 mt-3 mb-4 d-flex align-items-center justify-content-between">
                            <div>
                              <ul className="d-flex m-0 p-0 image-list">
                                <li>
                                  <a href="">
                                    <img
                                      src="assets/images/avatar (1).png"
                                      className="rounded"
                                      alt=""
                                      width="35"
                                      height="35"
                                    />
                                  </a>
                                </li>
                                <li>
                                  <a href="">
                                    <img
                                      src="assets/images/avatar (2).png"
                                      className="rounded"
                                      alt=""
                                      width="35"
                                      height="35"
                                    />
                                  </a>
                                </li>
                                <li>
                                  <a href="">
                                    <img
                                      src="assets/images/avatar (1).png"
                                      className="rounded"
                                      alt=""
                                      width="35"
                                      height="35"
                                    />
                                  </a>
                                </li>
                                <li>
                                  <a href="">
                                    <img
                                      src="assets/images/avatar2.png"
                                      className="rounded"
                                      alt=""
                                      width="35"
                                      height="35"
                                    />
                                    <span className="image-count">+2</span>
                                  </a>
                                </li>
                              </ul>
                            </div>
                            <div>
                              <a
                                href="javascript:void(0)"
                                className="btn-dl like-btn"
                              >
                                <img
                                  src="assets/images/like.png"
                                  alt=""
                                  width=""
                                  height=""
                                />
                                Like
                              </a>
                              {/* <!-- <a href="javascript:void(0)" className="btn-dl dislike-btn">
                                                        <img src="assets/images/dislike.png" alt="" width="" height="" />
                                                        Like
                                                    </a> --> */}
                            </div>
                          </div>
                          <div className="comment-section pt-4">
                            <h4 className="title mb-3">Comments(2)</h4>
                            <div className="d-flex">
                              <div>
                                <img
                                  src="assets/images/Ellipse 2.png"
                                  className="rounded"
                                  alt=""
                                  width="40"
                                  height="40"
                                />
                              </div>
                              <div className="ml-1">
                                <h5 className="mb-1">
                                  Kittiya Yuthasastrkosol
                                </h5>
                                <p className="desc mb-2">
                                  Lorem Ipsum is simply dummy text of the
                                  printing and typesetting industry.{" "}
                                </p>
                                <span>1 day ago</span>
                                <span>
                                  <a href="" className="text-b">
                                    Like
                                  </a>
                                </span>
                                <span>
                                  <a href="" className="text-b">
                                    Reply
                                  </a>
                                </span>
                              </div>
                            </div>
                            <div className="reply-blocks pl-6 mt-3">
                              <div className="">
                                <h5 className="mb-1">Surasak Jaikum</h5>
                                <p className="desc mb-2">
                                  <a href="">@Kittiya</a> Lorem Ipsum is simply
                                  dummy text of the printing and typesetting
                                  industry.{" "}
                                </p>
                                <div className="d-flex align-items-center justify-content-between">
                                  <div>
                                    <span>1 day ago</span>
                                    <span>
                                      <a
                                        href="javascript:void(0)"
                                        className="text-b"
                                      >
                                        Like
                                      </a>
                                    </span>
                                    <span>
                                      <a href="" className="text-b">
                                        Reply
                                      </a>
                                    </span>
                                  </div>
                                  <div>
                                    <strong>+1</strong>{" "}
                                    <img
                                      src="assets/images/like.png"
                                      className=""
                                      alt=""
                                      width=""
                                      height=""
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="mt-3 pl-55">
                              <h5 className="mb-1">Kittiya Yuthasastrkosol</h5>
                              <p className="desc mb-2">
                                Lorem Ipsum is simply dummy text of the printing
                                and typesetting industry.{" "}
                              </p>
                              <div className="d-flex align-items-center justify-content-between">
                                <div>
                                  <span>1 day ago</span>
                                  <span>
                                    <a
                                      href="javascript:void(0)"
                                      className="text-r"
                                    >
                                      Like
                                    </a>
                                  </span>
                                  <span>
                                    <a href="" className="text-b">
                                      Reply
                                    </a>
                                  </span>
                                </div>
                                <div>
                                  <strong>+1</strong>{" "}
                                  <img
                                    src="assets/images/like.png"
                                    className=""
                                    alt=""
                                    width=""
                                    height=""
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="comment-message mb-3">
                        <div className="d-flex align-items-center justify-content-between">
                          <div>
                            <img
                              src="assets/images/Ellipse 2.png"
                              className="rounded"
                              alt=""
                              width="40"
                              height="40"
                            />
                          </div>
                          <div className="w-100">
                            <form>
                              <div className="form-group">
                                <input
                                  type="text"
                                  className="form-control"
                                  placeholder="write a comment..."
                                />
                              </div>
                            </form>
                          </div>
                          <div className="d-none">
                            <img
                              src="assets/images/768/send.png"
                              className="send"
                              alt=""
                              width=""
                              height=""
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-2 d-m-none">
                      <div className="img-block mb-3">
                        <img
                          src="assets/images/image 83.png"
                          className="img-fluid"
                          alt=""
                          width=""
                          height=""
                        />
                      </div>
                      <div className="img-block mb-3">
                        <img
                          src="assets/images/image 110.png"
                          className="img-fluid"
                          alt=""
                          width=""
                          height=""
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* <!-- Blog Detail End --> */}
      <Footer />
    </>
  );
}
