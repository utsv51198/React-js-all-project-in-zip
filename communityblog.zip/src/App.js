import React from "react";
import { Routes, Route } from "react-router-dom";
import Blog from "./pages/Blog";
import BlogDetalis from "./pages/BlogDetalis";

function App() {
  return (
    <>
      <Routes>
        <Route path="/" exact element={<Blog />} />
        <Route exact path="/blog-detalis" element={<BlogDetalis />} />
      </Routes>
    </>
  );
}

export default App;
