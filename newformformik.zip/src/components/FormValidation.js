import { Field, Form, Formik ,ErrorMessage } from "formik";
import React, { Fragment } from "react";
import * as yup from "yup";


const FormValidation = () => {
  const defualtValue = {
    name: "",
    email: "",
    password: "",
    gender: "",
    termAndCond : false
  };
  const ValidationSchema = yup.object().shape({
    name : yup.string().required("Name is Required!"),
    email : yup.string().required("Email is Required!").email("Please Enter Valid Email"),
    password : yup.string().required("Password is Required!").matches(
      "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?=.{8,})",
      "Password Not Valid!"
    ),
    gender : yup.string().required("Gender Is Required!"),
    termAndCond:yup.boolean().oneOf([true],"Please Select Term And Conditions")

  })
  const handleSubmit = (value) =>{
    console.log("value",value);
  }
  return (
    <Fragment>
      <div className="container">
        <div className="col-md-12 text-center mt-5">
          <h1 className="my-4">VALIDATION FORM</h1>
          <Formik
            initialValues={defualtValue}
            validationSchema={ValidationSchema}
            onSubmit={handleSubmit}
          >
            <Form>
              <div className="col-md-12 mt-4">
                <Field
                  name="name"
                  type="text"
                  placeholder="Enter Your Name"
                  className="form-control"
                />
                <p className="text-danger">
                  <ErrorMessage name="name" />
                </p>
              </div>
              <div className="col-md-12 mt-4">
                <Field
                  name="email"
                  type="text"
                  placeholder="Enter Your Email"
                  className="form-control"
                />
                <p className="text-danger">
                  <ErrorMessage name="email" />
                </p>
              </div>
              <div className=" col-md-12 mt-4">
                <Field
                  name="password"
                  type="password"
                  placeholder="Enter Your Password"
                  className="form-control"
                />
                <p className="text-danger">
                  <ErrorMessage name="password" />
                </p>
              </div>
              <div className=" col-md-12 mt-4">
                <Field
                  component="select"
                  name="gender"
                  placeholder="Gender"
                  className="form-control"
                >
                  <option value="" disable="true">
                    Select Your Gender
                  </option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                </Field>
                <p className="text-danger">
                  <ErrorMessage name="gender" />
                </p>
              </div>
              <div className="col-md-12 mt-4">
                <label className= "form-inline">
                     <Field type = "checkbox" name = "termAndCond"></Field>
                      I ACCEPT TERM AND CONDITIONS
                </label>
                <p className="text-danger">
                  <ErrorMessage name="termAndCond"/>
                </p>
              </div>
              <button className="btn btn-primary my-3" type="submit">
                Submit
              </button>
            </Form>
          </Formik>
        </div>
      </div>
    </Fragment>
  );
};

export default FormValidation;
